"use strict";
(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["src_app_pages_coleta_coleta_module_ts"],{

/***/ 56349:
/*!*******************************************************!*\
  !*** ./src/app/pages/coleta/coleta-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetaPageRoutingModule": () => (/* binding */ ColetaPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _coleta_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./coleta.page */ 61372);




const routes = [
    {
        path: '',
        component: _coleta_page__WEBPACK_IMPORTED_MODULE_0__.ColetaPage
    }
];
let ColetaPageRoutingModule = class ColetaPageRoutingModule {
};
ColetaPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ColetaPageRoutingModule);



/***/ }),

/***/ 19941:
/*!***********************************************!*\
  !*** ./src/app/pages/coleta/coleta.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetaPageModule": () => (/* binding */ ColetaPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _coleta_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./coleta-routing.module */ 56349);
/* harmony import */ var _coleta_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./coleta.page */ 61372);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/shared.module */ 40950);








let ColetaPageModule = class ColetaPageModule {
};
ColetaPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _coleta_routing_module__WEBPACK_IMPORTED_MODULE_0__.ColetaPageRoutingModule,
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule
        ],
        declarations: [_coleta_page__WEBPACK_IMPORTED_MODULE_1__.ColetaPage]
    })
], ColetaPageModule);



/***/ }),

/***/ 61372:
/*!*********************************************!*\
  !*** ./src/app/pages/coleta/coleta.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetaPage": () => (/* binding */ ColetaPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_coleta_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./coleta.page.html */ 62585);
/* harmony import */ var _coleta_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./coleta.page.scss */ 55613);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 37556);
/* harmony import */ var src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/coleta.service */ 35738);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/message.service */ 42684);
/* harmony import */ var _shared_modal_clinicas_modal_clinicas_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared/modal-clinicas/modal-clinicas.component */ 79538);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage */ 54357);










let ColetaPage = class ColetaPage {
    constructor(navCtrl, alertCtrl, modalCtrl, storage, authService, service, message) {
        this.navCtrl = navCtrl;
        this.alertCtrl = alertCtrl;
        this.modalCtrl = modalCtrl;
        this.storage = storage;
        this.authService = authService;
        this.service = service;
        this.message = message;
        this.user = {};
        this.clinica = {};
        this.dados = {};
        this.filterSolicitacoes = { status: 'AGUARDANDO_PORTADOR' };
        this.solicitacoes = [];
        this.devolucoes = [];
        this.storage.create();
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const session = yield this.authService.getSession();
            console.log(session);
            console.log('funcionando?');
            this.user = session.user;
            this.filterSolicitacoes.portador_id = this.user.uuid;
            // this.getSolicitacoes();
        });
    }
    ionViewDidEnter() {
        this.getSolicitacoes();
    }
    searchClinicas() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _shared_modal_clinicas_modal_clinicas_component__WEBPACK_IMPORTED_MODULE_5__.ModalClinicasComponent,
                componentProps: {
                    roteiro: true
                }
            });
            yield modal.present();
            modal.onDidDismiss().then(res => {
                console.log(res);
                if (res.data) {
                    this.clinica = res.data;
                }
            });
        });
    }
    startQrCodeScan() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const code = yield this.message.readQRCode();
            if (code != false) {
                this.coletaForm(code);
            }
        });
    }
    codeQRManual() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                // header: 'Prompt!',
                message: 'Informe o código do QR Code manualmente.',
                backdropDismiss: false,
                mode: 'ios',
                inputs: [
                    {
                        name: 'code',
                        type: 'tel',
                        placeholder: 'Informe o código do QR Code.'
                    }
                ],
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary'
                    }, {
                        text: 'Confirmar',
                        handler: (data) => {
                            if (data.code == "") {
                                return this.message.toastError('Informe o código...');
                            }
                            this.coletaForm(data.code);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    coletaForm(code) {
        this.message.load_present();
        this.service.createColeta({ code_qr: code, clinica_id: this.clinica.uuid }).then((res) => {
            this.navCtrl.navigateForward(`/coleta-form/${res.data.uuid}`);
        }).finally(() => this.message.load_dismiss());
    }
    coletaEmpty() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                header: 'Atenção!',
                mode: 'ios',
                message: `Visita sem coleta ?`,
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary'
                    }, {
                        text: 'Confirmar',
                        handler: () => {
                            this.dados = { portador_id: this.user.uuid, clinica_id: this.clinica.uuid, clinica: this.clinica.description, sem_coleta: 1 };
                            this.message.load_present();
                            this.service.createColeta(this.dados).then(() => {
                                this.navCtrl.navigateRoot('/home');
                            }).catch(err => {
                                this.storageColeta();
                            }).finally(() => this.message.load_dismiss());
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    storageColeta() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                header: 'Aviso!',
                mode: 'ios',
                message: 'Sua coleta foi armazenada no dispositivo por falta de internet... \n Será enviado quando a mesma for restaurada.',
                buttons: ['OK']
            });
            yield alert.present();
            this.storage.get('coletas').then(res => {
                if (res && res != null) { //temos coletas
                    let coletas = res;
                    coletas.push(this.dados);
                    this.setColetas(coletas);
                }
                else { //sem coletas
                    let coletas = [];
                    coletas.push(this.dados);
                    this.setColetas(coletas);
                }
            }).catch(err => {
                this.message.toastError('Falha ao verificar coletas no dispositivo.');
                console.log(err);
            });
        });
    }
    setColetas(coletas) {
        this.storage.set('coletas', coletas).then(() => {
            this.navCtrl.navigateRoot('/home');
        }).catch(err => {
            this.message.toastError('Falha ao salvar coleta no dispositivo.');
            console.log(err);
        });
    }
    getSolicitacoes() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            this.message.load_present();
            yield this.service.getSolicitacoes(this.filterSolicitacoes).then(res => {
                this.solicitacoes = res;
            }).finally(() => this.message.load_dismiss());
            this.getDevolucoes();
        });
    }
    getDevolucoes() {
        this.message.load_present();
        this.service.getDevolucoes(this.filterSolicitacoes).then(res => {
            this.devolucoes = res;
        }).finally(() => this.message.load_dismiss());
    }
};
ColetaPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__.Storage },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_3__.ColetaService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__.MessageService }
];
ColetaPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-coleta',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_coleta_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_coleta_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ColetaPage);



/***/ }),

/***/ 62585:
/*!**************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coleta/coleta.page.html ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n\n    <ion-title>Coletas</ion-title>\n    \n  </ion-toolbar>\n</ion-header>\n\n<ion-content color=\"primary\">\n\n  <div class=\"ion-padding\" align=\"center\">\n    <strong class=\"font-md\">Cadastro de Coleta</strong>\n  </div>\n\n  <ion-card class=\"ion-margin-top\" mode=\"ios\" *ngIf=\"solicitacoes.length > 0\" button [routerLink]=\"[ '/solicitacoes' ]\">\n    <div class=\"ion-padding\" align=\"center\">\n      <strong class=\"font-md\">{{solicitacoes.length}}</strong>\n      <div>\n        <strong class=\"\">Solicitações</strong>\n      </div>\n    </div>\n  </ion-card>\n\n  <ion-card class=\"ion-margin-top\" mode=\"ios\" *ngIf=\"devolucoes.length > 0\" button [routerLink]=\"[ '/devolucoes' ]\">\n    <div class=\"ion-padding\" align=\"center\">\n      <strong class=\"font-md\">{{devolucoes.length}}</strong>\n      <div>\n        <strong class=\"\">Devoluções</strong>\n      </div>\n    </div>\n  </ion-card>\n\n  <ion-card class=\"ion-margin-top\" mode=\"ios\" (click)=\"searchClinicas()\">\n\n    <ion-item lines=\"none\" button detail>\n      <ion-icon name=\"location-outline\" color=\"primary\" slot=\"start\"></ion-icon>\n      <ion-label class=\"ion-text-wrap\" color=\"primary\" *ngIf=\"!clinica.uuid\">\n        <h2>Informe a clínica ou local</h2>\n      </ion-label>\n      <ion-label class=\"ion-text-wrap\" color=\"primary\" *ngIf=\"clinica.uuid\">\n        <h2>{{ clinica.description | titlecase }}</h2>\n        <p>{{clinica.logradouro}}, Nº {{clinica.numero}}, {{clinica.complemento}}, {{clinica.bairro}},\n          {{clinica.cidade}}</p>\n      </ion-label>\n    </ion-item>\n\n  </ion-card>\n\n  <div class=\"ion-padding\">\n    <ion-row class=\"ion-margin-top\" *ngIf=\"clinica.uuid\">\n\n      <ion-col size=\"12\">\n        <ion-button expand=\"block\" color=\"tertiary\" (click)=\"startQrCodeScan()\">\n          <ion-icon name=\"qr-code-outline\" slot=\"start\"></ion-icon>\n          Ler QR Code\n        </ion-button>\n      </ion-col>\n\n      <ion-col size=\"12\">\n        <ion-button expand=\"block\" color=\"medium\" (click)=\"codeQRManual()\">\n          <ion-icon name=\"create-outline\" slot=\"start\"></ion-icon>\n          Manual\n        </ion-button>\n      </ion-col>\n\n      <ion-col size=\"12\">\n        <ion-button expand=\"block\" color=\"light\" (click)=\"coletaEmpty()\">\n          <!-- <ion-icon name=\"create-outline\" slot=\"start\"></ion-icon> -->\n          Sem Coleta\n        </ion-button>\n      </ion-col>\n\n    </ion-row>\n  </div>\n\n\n\n</ion-content>\n");

/***/ }),

/***/ 55613:
/*!***********************************************!*\
  !*** ./src/app/pages/coleta/coleta.page.scss ***!
  \***********************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjb2xldGEucGFnZS5zY3NzIn0= */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_coleta_coleta_module_ts.js.map