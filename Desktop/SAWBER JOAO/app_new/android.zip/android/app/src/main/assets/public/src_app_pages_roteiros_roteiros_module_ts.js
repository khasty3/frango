"use strict";
(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["src_app_pages_roteiros_roteiros_module_ts"],{

/***/ 30668:
/*!***********************************************************!*\
  !*** ./src/app/pages/roteiros/roteiros-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RoteirosPageRoutingModule": () => (/* binding */ RoteirosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _roteiros_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./roteiros.page */ 68155);




const routes = [
    {
        path: '',
        component: _roteiros_page__WEBPACK_IMPORTED_MODULE_0__.RoteirosPage
    }
];
let RoteirosPageRoutingModule = class RoteirosPageRoutingModule {
};
RoteirosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RoteirosPageRoutingModule);



/***/ }),

/***/ 18788:
/*!***************************************************!*\
  !*** ./src/app/pages/roteiros/roteiros.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RoteirosPageModule": () => (/* binding */ RoteirosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _roteiros_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./roteiros-routing.module */ 30668);
/* harmony import */ var _roteiros_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./roteiros.page */ 68155);







let RoteirosPageModule = class RoteirosPageModule {
};
RoteirosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _roteiros_routing_module__WEBPACK_IMPORTED_MODULE_0__.RoteirosPageRoutingModule
        ],
        declarations: [_roteiros_page__WEBPACK_IMPORTED_MODULE_1__.RoteirosPage]
    })
], RoteirosPageModule);



/***/ }),

/***/ 68155:
/*!*************************************************!*\
  !*** ./src/app/pages/roteiros/roteiros.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RoteirosPage": () => (/* binding */ RoteirosPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_roteiros_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./roteiros.page.html */ 17263);
/* harmony import */ var _roteiros_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./roteiros.page.scss */ 31732);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 37556);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/message.service */ 42684);
/* harmony import */ var src_app_services_roteiro_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/roteiro.service */ 32614);
/* harmony import */ var _shared_modal_clinicas_modal_clinicas_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared/modal-clinicas/modal-clinicas.component */ 79538);









let RoteirosPage = class RoteirosPage {
    //let obj = {};
    //sscurrentFood = undefined;
    constructor(actionSheetController, modalCtrl, alertCtrl, authService, service, message) {
        this.actionSheetController = actionSheetController;
        this.modalCtrl = modalCtrl;
        this.alertCtrl = alertCtrl;
        this.authService = authService;
        this.service = service;
        this.message = message;
        this.dataSource = [];
        this.filters = {};
        this.user = {};
        this.cucumber = [];
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const session = yield this.authService.getSession();
            this.filters.user_id = session.user.uuid;
        });
    }
    updateCucumber() {
        //console.log(this.cucumber);
        let js = JSON.stringify(this.cucumber).replace(/"/g, "").split('[').join("").split(']').join("");
        this.filters.dias = js;
        console.log(js);
        if (js == '') {
            this.filters.dias = null;
        }
        this.getClinicas();
    }
    /*  async selectRoteiro() {
         //this.getClinicas();
        const alert  = await this.alertCtrl.create({
          // header: 'Albums',
          // cssClass: 'my-custom-class',
          
          mode: 'ios',
        inputs:[
          {
            type:'checkbox',
            name:'segunda',
            label:'Segunda',
            checked : false,
            value: 1,
            handler: (segunda) => {
              if(segunda.checked){
                this.data0 = 'segunda';
                segunda.checked;
            }else{
              this.data0 = '';
            }
           }
          },
           {
            type:'checkbox',
            name:'terca',
            label:'terca',
            checked : false,
            value: 2,
            handler: (terca) => {
              if(terca.checked){
                this.data1 = 'terça';
                terca.checked;
            }else{
              this.data1 = '';
            }
           }
            
           },
           {
            type:'checkbox',
            name:'quarta',
            label:'quarta',
            checked : false,
            value: 3,
            handler: (quarta) => {
              if(quarta.checked){
                this.data2 = 'Quarta';
                quarta.checked;
            }else{
              this.data2 = '';
            }
           }
            
           },
           {
            type:'checkbox',
            name:'quinta',
            label:'quinta',
            checked : false,
            value: 4,
           
           },
           {
            type:'checkbox',
            name:'sexta',
            label:'sexta',
            checked : false,
            value: 5,
           }
        ],
          buttons: [
            {
              text: 'Filtrar dias',
              // role: 'destructive',
              // icon: 'trash',
              
              handler: (data) => {
               if(data[0] == null){
                  data[0] = '';
                }
                if(data[1] == null){
                  data[1] = '';
                }
                if(data[2] == null){
                  data[2] = '';
                }
                if(data[3] == null){
                  data[3] = '';
                }
                if(data[4] == null){
                  data[4] = '';
                }
                console.log(data[0]);
                //console.log(data[0],data[1],data[2],data[3],data[4]);
               this.filters.tipo = 1;
                this.filters.dias = this.cucumber;
                this.getClinicas();
              }
            },
            
            {
              text: 'Segunda, Quarta e Sexta',
              // role: 'destructive',
              // icon: 'trash',
              
              handler: () => {
                this.filters.tipo = 1;
                this.filters.dias = '1,3,5';
                this.getClinicas();
              }
            },
             {
              text: 'Terça e Quinta',
              // icon: 'share',
              handler: () => {
                this.filters.tipo = 2;
                this.filters.dias = '2,4';
                this.getClinicas();
              }
            }
          ]
        });
        await alert.present();
      }
    */
    getClinicas() {
        this.message.load_present();
        this.service.getClinicas(this.filters).then(res => {
            this.dataSource = res;
        }).finally(() => this.message.load_dismiss());
    }
    confirmeRemove(item) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                header: 'Atenção!',
                mode: 'ios',
                message: `Remover a clinica/local: <b>${item.description}</b> deste roteiro ?`,
                buttons: [
                    {
                        text: 'Não',
                        cssClass: 'secondary'
                    }, {
                        text: 'Sim',
                        handler: () => {
                            this.removeClinica(item);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    removeClinica(item) {
        const request = {
            dias: this.filters.dias,
            user_id: this.filters.user_id,
            clinica_id: item.uuid
        };
        this.message.load_present();
        this.service.removeClinica(request).then(() => {
            this.getClinicas();
        }).finally(() => this.message.load_dismiss());
    }
    openClinicas() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _shared_modal_clinicas_modal_clinicas_component__WEBPACK_IMPORTED_MODULE_5__.ModalClinicasComponent,
            });
            yield modal.present();
            modal.onDidDismiss().then(res => {
                if (res.data) {
                    this.addClinicaConfirm(res.data);
                }
            });
        });
    }
    addClinicaConfirm(dados) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                header: 'Atenção!',
                mode: 'ios',
                message: `Adicionar a clinica/local: <b>${dados.description}</b> neste roteiro ?`,
                buttons: [
                    {
                        text: 'Não',
                        cssClass: 'secondary'
                    }, {
                        text: 'Sim',
                        handler: () => {
                            this.addClinica(dados);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    addClinica(dados) {
        const request = {
            dias: this.filters.dias,
            user_id: this.filters.user_id,
            clinica_id: dados.uuid
        };
        this.message.load_present();
        this.service.setClinica(request).then(() => {
            this.getClinicas();
        }).finally(() => this.message.load_dismiss());
    }
};
RoteirosPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ActionSheetController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: src_app_services_roteiro_service__WEBPACK_IMPORTED_MODULE_4__.RoteiroService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_3__.MessageService }
];
RoteirosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-roteiros',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_roteiros_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_roteiros_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], RoteirosPage);



/***/ }),

/***/ 32614:
/*!*********************************************!*\
  !*** ./src/app/services/roteiro.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RoteiroService": () => (/* binding */ RoteiroService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let RoteiroService = class RoteiroService {
    constructor(http) {
        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url;
    }
    getClinicas(queryParams) {
        return this.http.get(`${this.url}/app/roteiro/getClinicas`, { params: queryParams }).toPromise();
    }
    setClinica(data) {
        return this.http.post(`${this.url}/app/roteiro/setClinica`, data).toPromise();
    }
    removeClinica(data) {
        return this.http.post(`${this.url}/app/roteiro/removeClinica`, data).toPromise();
    }
};
RoteiroService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
RoteiroService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], RoteiroService);



/***/ }),

/***/ 17263:
/*!******************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/roteiros/roteiros.page.html ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n\n    <ion-title>Roteiros</ion-title>\n  </ion-toolbar>\n  <!-- <ion-toolbar color=\"primary\">\n    <ion-searchbar debounce=\"500\"></ion-searchbar>\n  </ion-toolbar> -->\n</ion-header>\n\n<ion-content>\n  <ion-col size=\"6\">\n\n    <ion-item>\n      <ion-label position=\"floating\">Selecione os dias:</ion-label>\n      <ion-select [(ngModel)]=\"cucumber\"  (ionChange)=\"updateCucumber()\" multiple=\"true\" okText=\"ok\" cancelText=\"voltar\" mode=\"ios\">\n        <ion-select-option value=\"1\">Segunda</ion-select-option>\n        <ion-select-option value=\"2\">Terça</ion-select-option>\n        <ion-select-option value=\"3\">Quarta</ion-select-option>\n        <ion-select-option value=\"4\">Quinta</ion-select-option>\n        <ion-select-option value=\"5\">Sexta</ion-select-option>\n        <ion-select-option value=\"6\">Sábado</ion-select-option>\n        <ion-select-option value=\"0\">Domingo</ion-select-option>\n        <!-- <ion-select-option value=\"3\">Anual</ion-select-option> -->\n      </ion-select>\n    </ion-item>\n  </ion-col>\n <!-- <ion-card>\n    <ion-item lines=\"none\" mode=\"ios\" (click)=\"selectRoteiro()\" detail>\n      <ion-label *ngIf=\"!filters.tipo ==1\">\n        Selecione o dia do roteiro\n      </ion-label>\n      <ion-label *ngIf=\"filters.tipo\"class=\"ion-text-wrap\">\n        {{data0}}\n        {{data1}}\n        {{data2}}\n        {{data3}}\n        {{data4}} \n       \n      </ion-label>\n   \n    </ion-item>\n  </ion-card>-->\n\n  <ion-list>\n    <ion-item lines=\"full\" *ngFor=\"let item of dataSource\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2>{{ item.description | titlecase }}</h2>\n        <p>{{item.logradouro}}, Nº {{item.numero}}, {{item.complemento}}, {{item.bairro}}, {{item.cidade}}</p>\n      </ion-label>\n      <ion-button slot=\"end\" fill=\"clear\" (click)=\"confirmeRemove(item)\">\n        <ion-icon name=\"close-circle-outline\" color=\"danger\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-item>\n  </ion-list>\n\n  <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\" *ngIf=\"filters.dias\">\n    <ion-fab-button color=\"primary\" (click)=\"openClinicas()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n</ion-content>\n");

/***/ }),

/***/ 31732:
/*!***************************************************!*\
  !*** ./src/app/pages/roteiros/roteiros.page.scss ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyb3RlaXJvcy5wYWdlLnNjc3MifQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_roteiros_roteiros_module_ts.js.map