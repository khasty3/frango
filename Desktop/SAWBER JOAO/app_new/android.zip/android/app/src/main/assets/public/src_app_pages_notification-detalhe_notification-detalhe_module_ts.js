"use strict";
(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["src_app_pages_notification-detalhe_notification-detalhe_module_ts"],{

/***/ 64437:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/notification-detalhe/notification-detalhe-routing.module.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationDetalhePageRoutingModule": () => (/* binding */ NotificationDetalhePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _notification_detalhe_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./notification-detalhe.page */ 24281);




const routes = [
    {
        path: '',
        component: _notification_detalhe_page__WEBPACK_IMPORTED_MODULE_0__.NotificationDetalhePage
    }
];
let NotificationDetalhePageRoutingModule = class NotificationDetalhePageRoutingModule {
};
NotificationDetalhePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NotificationDetalhePageRoutingModule);



/***/ }),

/***/ 9063:
/*!***************************************************************************!*\
  !*** ./src/app/pages/notification-detalhe/notification-detalhe.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationDetalhePageModule": () => (/* binding */ NotificationDetalhePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _notification_detalhe_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./notification-detalhe-routing.module */ 64437);
/* harmony import */ var _notification_detalhe_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./notification-detalhe.page */ 24281);







let NotificationDetalhePageModule = class NotificationDetalhePageModule {
};
NotificationDetalhePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _notification_detalhe_routing_module__WEBPACK_IMPORTED_MODULE_0__.NotificationDetalhePageRoutingModule
        ],
        declarations: [_notification_detalhe_page__WEBPACK_IMPORTED_MODULE_1__.NotificationDetalhePage]
    })
], NotificationDetalhePageModule);



/***/ }),

/***/ 24281:
/*!*************************************************************************!*\
  !*** ./src/app/pages/notification-detalhe/notification-detalhe.page.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationDetalhePage": () => (/* binding */ NotificationDetalhePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_notification_detalhe_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./notification-detalhe.page.html */ 73901);
/* harmony import */ var _notification_detalhe_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./notification-detalhe.page.scss */ 15167);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/message.service */ 42684);
/* harmony import */ var src_app_services_motoboy_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/motoboy.service */ 3756);







let NotificationDetalhePage = class NotificationDetalhePage {
    constructor(routerActive, service, message) {
        this.routerActive = routerActive;
        this.service = service;
        this.message = message;
        this.coleta = { clinica: {}, medicos: [] };
    }
    ngOnInit() {
        this.routerActive.params.subscribe(params => {
            console.log(params);
            if (params.coleta_id) {
                this.getDados(params.coleta_id);
            }
        }).unsubscribe();
    }
    getDados(uuid) {
        this.message.load_present();
        this.service.getColeta(uuid).then(res => {
            this.coleta = res;
        }).finally(() => this.message.load_dismiss());
    }
};
NotificationDetalhePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute },
    { type: src_app_services_motoboy_service__WEBPACK_IMPORTED_MODULE_3__.MotoboyService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_2__.MessageService }
];
NotificationDetalhePage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-notification-detalhe',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_notification_detalhe_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_notification_detalhe_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], NotificationDetalhePage);



/***/ }),

/***/ 73901:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/notification-detalhe/notification-detalhe.page.html ***!
  \******************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n\n    <ion-title>Detalhe da Ocorrência</ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-card mode=\"ios\">\n    <ion-item lines=\"none\">\n      <ion-label class=\"ion-text-wrap\">\n        <span>Clinica: {{coleta.clinica.description}}</span>\n        <p>Data da coleta: {{ coleta.created_at | date:'dd/MM/yyyy' }}</p>\n\n        <!-- <ion-badge color=\"medium\" *ngIf=\"coleta.status == 1\">Pendente</ion-badge>\n        <ion-badge color=\"warning\" *ngIf=\"coleta.status == 5\">Ocorrência</ion-badge>\n        <ion-badge color=\"success\" *ngIf=\"coleta.status == 10\">Verificado</ion-badge> -->\n      </ion-label>\n    </ion-item>\n  </ion-card>\n\n  <ion-list *ngFor=\"let medico of coleta.medicos\">\n    <ion-list-header color=\"primary\">\n      <ion-label>{{medico.nome}}</ion-label>\n    </ion-list-header>\n\n    <ion-item lines=\"full\" *ngFor=\"let item of medico.itens\">\n      <ion-thumbnail slot=\"start\">\n        <img [src]=\"item.foto\">\n      </ion-thumbnail>\n      <ion-label class=\"ion-text-wrap\">\n        <h2>Exame: {{item.tipo_exame}}</h2>\n        <p>Ocorrência: {{item.description}}</p>\n      </ion-label>\n    </ion-item>\n\n  </ion-list>\n\n</ion-content>\n");

/***/ }),

/***/ 15167:
/*!***************************************************************************!*\
  !*** ./src/app/pages/notification-detalhe/notification-detalhe.page.scss ***!
  \***************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJub3RpZmljYXRpb24tZGV0YWxoZS5wYWdlLnNjc3MifQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_notification-detalhe_notification-detalhe_module_ts.js.map