"use strict";
(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["src_app_pages_coletas-check_coletas-check_module_ts"],{

/***/ 90498:
/*!*********************************************************************!*\
  !*** ./src/app/pages/coletas-check/coletas-check-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetasCheckPageRoutingModule": () => (/* binding */ ColetasCheckPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _coletas_check_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./coletas-check.page */ 97376);




const routes = [
    {
        path: '',
        component: _coletas_check_page__WEBPACK_IMPORTED_MODULE_0__.ColetasCheckPage
    }
];
let ColetasCheckPageRoutingModule = class ColetasCheckPageRoutingModule {
};
ColetasCheckPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ColetasCheckPageRoutingModule);



/***/ }),

/***/ 61137:
/*!*************************************************************!*\
  !*** ./src/app/pages/coletas-check/coletas-check.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetasCheckPageModule": () => (/* binding */ ColetasCheckPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _coletas_check_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./coletas-check-routing.module */ 90498);
/* harmony import */ var _coletas_check_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./coletas-check.page */ 97376);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/shared.module */ 40950);








let ColetasCheckPageModule = class ColetasCheckPageModule {
};
ColetasCheckPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _coletas_check_routing_module__WEBPACK_IMPORTED_MODULE_0__.ColetasCheckPageRoutingModule,
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule
        ],
        declarations: [_coletas_check_page__WEBPACK_IMPORTED_MODULE_1__.ColetasCheckPage]
    })
], ColetasCheckPageModule);



/***/ }),

/***/ 97376:
/*!***********************************************************!*\
  !*** ./src/app/pages/coletas-check/coletas-check.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetasCheckPage": () => (/* binding */ ColetasCheckPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_coletas_check_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./coletas-check.page.html */ 36962);
/* harmony import */ var _coletas_check_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./coletas-check.page.scss */ 4057);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_app_pages_shared_modal_motoboy_modal_motoboy_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/pages/shared/modal-motoboy/modal-motoboy.page */ 16447);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/message.service */ 42684);
/* harmony import */ var src_app_services_motoboy_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/motoboy.service */ 3756);








let ColetasCheckPage = class ColetasCheckPage {
    constructor(alertCtrl, actionSheetController, navCtrl, modalCtrl, service, message) {
        this.alertCtrl = alertCtrl;
        this.actionSheetController = actionSheetController;
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.service = service;
        this.message = message;
        this.portador = {};
        this.coletas = [];
    }
    ngOnInit() {
    }
    doRefresh(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            yield this.getColetas();
            event.target.complete();
        });
    }
    ionViewWillEnter() {
        this.getColetas();
    }
    searchPortador() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: src_app_pages_shared_modal_motoboy_modal_motoboy_page__WEBPACK_IMPORTED_MODULE_2__.ModalMotoboyPage,
                componentProps: {
                // roteiro: true
                }
            });
            yield modal.present();
            modal.onDidDismiss().then(res => {
                console.log(res);
                if (res.data) {
                    this.portador = res.data;
                    this.getColetas();
                }
            });
        });
    }
    getColetas() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            if (!this.portador.uuid) {
                return;
            }
            this.message.load_present();
            yield this.service.getColetas({ portador_id: this.portador.uuid }).then(res => {
                this.coletas = res;
            }).finally(() => this.message.load_dismiss());
        });
    }
    optionSearch() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                header: 'Buscar Coleta',
                // cssClass: 'my-custom-class',
                mode: 'ios',
                buttons: [
                    {
                        text: 'Manual',
                        icon: 'create-outline',
                        handler: () => {
                            // console.log('Share clicked');
                            this.codeQRManual();
                        }
                    },
                    {
                        text: 'Ler QR Code',
                        icon: 'qr-code-outline',
                        handler: () => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                            const code = yield this.message.readQRCode();
                            if (code != false) {
                                this.getColeta(code);
                            }
                        })
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    codeQRManual() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                // cssClass: 'my-custom-class',
                // header: 'Prompt!',
                message: 'Informe o código do QR Code manualmente.',
                backdropDismiss: false,
                mode: 'ios',
                inputs: [
                    {
                        name: 'code',
                        type: 'text',
                        placeholder: 'Informe o código do QR Code.'
                    }
                ],
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary'
                    }, {
                        text: 'Confirmar',
                        handler: (data) => {
                            if (data.code == "") {
                                return this.message.toastError('Informe o código...');
                            }
                            this.getColeta(data.code);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    getColeta(code) {
        this.message.load_present();
        this.service.getColeta(code).then((res) => {
            // console.log(res);
            this.message.load_dismiss();
            this.navCtrl.navigateForward('/coletas-check-detail/' + res.uuid);
            // this.getListing();
        }).catch(() => this.message.load_dismiss());
    }
};
ColetasCheckPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ActionSheetController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: src_app_services_motoboy_service__WEBPACK_IMPORTED_MODULE_4__.MotoboyService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_3__.MessageService }
];
ColetasCheckPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-coletas-check',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_coletas_check_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_coletas_check_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ColetasCheckPage);



/***/ }),

/***/ 36962:
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coletas-check/coletas-check.page.html ***!
  \****************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n\n    <ion-title>Lista de Coletas</ion-title>\n\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"optionSearch()\">\n        <ion-icon slot=\"icon-only\" name=\"search-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <ion-card class=\"ion-margin-top\" mode=\"ios\" (click)=\"searchPortador()\">\n\n    <ion-item lines=\"none\" button detail>\n      <ion-icon name=\"person-outline\" color=\"primary\" slot=\"start\"></ion-icon>\n      <ion-label class=\"ion-text-wrap\" *ngIf=\"!portador.uuid\">\n        <h2>Informe o Motoboy</h2>\n      </ion-label>\n      <ion-label class=\"ion-text-wrap\" *ngIf=\"portador.uuid\">\n        <p>Portador:</p>\n        <h2>{{ portador.nome | titlecase }}</h2>\n      </ion-label>\n    </ion-item>\n\n  </ion-card>\n\n  <ion-list>\n\n    <ion-item *ngFor=\"let coleta of coletas; let i = index\" button lines=\"full\"\n      [routerLink]=\"[ '/coletas-check-detail/'+coleta.uuid ]\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2>Código: {{coleta.code_qr}}</h2>\n        <p>\n          Endereço: {{coleta.clinica.logradouro}}, {{coleta.clinica.numero}}, {{coleta.clinica.complemento}},\n          {{coleta.clinica.bairro}}, {{coleta.clinica.cidade}}\n        </p>\n        <span>\n          Status:\n          <ion-badge color=\"medium\" *ngIf=\"coleta.status == 2\">Pendente</ion-badge>\n          <ion-badge color=\"warning\" *ngIf=\"coleta.status == 5\">Ocorrência</ion-badge>\n          <ion-badge color=\"success\" *ngIf=\"coleta.status == 10\">Verificado</ion-badge>\n        </span>\n      </ion-label>\n    </ion-item>\n\n  </ion-list>\n\n</ion-content>\n");

/***/ }),

/***/ 4057:
/*!*************************************************************!*\
  !*** ./src/app/pages/coletas-check/coletas-check.page.scss ***!
  \*************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjb2xldGFzLWNoZWNrLnBhZ2Uuc2NzcyJ9 */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_coletas-check_coletas-check_module_ts.js.map