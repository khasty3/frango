(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["main"],{

/***/ 98255:
/*!*******************************************************!*\
  !*** ./$_lazy_route_resources/ lazy namespace object ***!
  \*******************************************************/
/***/ ((module) => {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(() => {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = () => ([]);
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 98255;
module.exports = webpackEmptyAsyncContext;

/***/ }),

/***/ 90158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./guards/auth.guard */ 95107);




const routes = [
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    {
        path: 'folder/:id', canActivate: [_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard],
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_folder_folder_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./folder/folder.module */ 3412)).then(m => m.FolderPageModule)
    },
    {
        path: 'auth',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_auth_auth_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/auth/auth.module */ 6621)).then(m => m.AuthPageModule)
    },
    {
        path: 'home', canActivate: [_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard],
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_home_home_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/home/home.module */ 57994)).then(m => m.HomePageModule)
    },
    {
        path: 'coleta', canActivate: [_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard],
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_coleta_coleta_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/coleta/coleta.module */ 19941)).then(m => m.ColetaPageModule)
    },
    {
        path: 'coleta-form/:coleta_id', canActivate: [_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard],
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_camera_service_ts"), __webpack_require__.e("default-src_app_pages_coleta-medico-form_coleta-medico-form_page_ts"), __webpack_require__.e("src_app_pages_coleta-form_coleta-form_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/coleta-form/coleta-form.module */ 93762)).then(m => m.ColetaFormPageModule)
    },
    {
        path: 'coleta-medico-form', canActivate: [_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard],
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_camera_service_ts"), __webpack_require__.e("default-src_app_pages_coleta-medico-form_coleta-medico-form_page_ts"), __webpack_require__.e("src_app_pages_coleta-medico-form_coleta-medico-form_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/coleta-medico-form/coleta-medico-form.module */ 70269)).then(m => m.ColetaMedicoFormPageModule)
    },
    {
        path: 'coleta-medico-item-form', canActivate: [_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard],
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_camera_service_ts"), __webpack_require__.e("src_app_pages_coleta-medico-item-form_coleta-medico-item-form_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/coleta-medico-item-form/coleta-medico-item-form.module */ 47442)).then(m => m.ColetaMedicoItemFormPageModule)
    },
    {
        path: 'roteiros', canActivate: [_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard],
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_roteiros_roteiros_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/roteiros/roteiros.module */ 18788)).then(m => m.RoteirosPageModule)
    },
    {
        path: 'coletas-pending', canActivate: [_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard],
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_coletas-pending_coletas-pending_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/coletas-pending/coletas-pending.module */ 71878)).then(m => m.ColetasPendingPageModule)
    },
    {
        path: 'coletas-check', canActivate: [_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard],
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_coletas-check_coletas-check_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/coletas-check/coletas-check.module */ 61137)).then(m => m.ColetasCheckPageModule)
    },
    {
        path: 'coletas-check-detail/:coleta_id', canActivate: [_guards_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard],
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_coletas-check-detail_coletas-check-detail_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/coletas-check-detail/coletas-check-detail.module */ 35241)).then(m => m.ColetasCheckDetailPageModule)
    },
    {
        path: 'notifications',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_notifications_notifications_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/notifications/notifications.module */ 44558)).then(m => m.NotificationsPageModule)
    },
    {
        path: 'notification-detalhe/:coleta_id',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_notification-detalhe_notification-detalhe_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/notification-detalhe/notification-detalhe.module */ 9063)).then(m => m.NotificationDetalhePageModule)
    },
    {
        path: 'malotes',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_malotes_malotes_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/malotes/malotes.module */ 59980)).then(m => m.MalotesPageModule)
    },
    {
        path: 'malote-form/:clinica_id/:code_qr',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_camera_service_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_malote-form_malote-form_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/malote-form/malote-form.module */ 24862)).then(m => m.MaloteFormPageModule)
    },
    {
        path: 'entregas',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_entregas_entregas_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/entregas/entregas.module */ 57105)).then(m => m.EntregasPageModule)
    },
    {
        path: 'entrega-detalhe/:entrega_id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_camera_service_ts"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_entrega-detalhe_entrega-detalhe_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/entrega-detalhe/entrega-detalhe.module */ 54593)).then(m => m.EntregaDetalhePageModule)
    },
    {
        path: 'malote-report',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_malote-report_malote-report_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/malote-report/malote-report.module */ 76287)).then(m => m.MaloteReportPageModule)
    },
    {
        path: 'entrega-report',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_entrega-report_entrega-report_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/entrega-report/entrega-report.module */ 62182)).then(m => m.EntregaReportPageModule)
    },
    {
        path: 'solicitacoes',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_solicitacoes_solicitacoes_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/solicitacoes/solicitacoes.module */ 25138)).then(m => m.SolicitacoesPageModule)
    },
    {
        path: 'devolucoes',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_devolucoes_devolucoes_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/devolucoes/devolucoes.module */ 58489)).then(m => m.DevolucoesPageModule)
    }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_3__.PreloadAllModules })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 55041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_app_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./app.component.html */ 75158);
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss */ 53040);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/auth.service */ 37556);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/storage */ 54357);
/* harmony import */ var _services_message_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./services/message.service */ 42684);
/* harmony import */ var _services_coleta_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./services/coleta.service */ 35738);
/* harmony import */ var _services_app_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./services/app.service */ 66475);
/* harmony import */ var _ionic_native_onesignal_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/onesignal/ngx */ 95795);
/* harmony import */ var _awesome_cordova_plugins_geolocation_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @awesome-cordova-plugins/geolocation/ngx */ 61171);
/* harmony import */ var _awesome_cordova_plugins_background_geolocation_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @awesome-cordova-plugins/background-geolocation/ngx */ 98528);





// import { SplashScreen } from '@ionic-native/splash-screen/ngx';
// import { StatusBar } from '@ionic-native/status-bar/ngx';




// import OneSignal from 'onesignal-cordova-plugin';




let AppComponent = class AppComponent {
    constructor(modalCtrl, storage, platform, 
    // private statusBar: StatusBar,
    // private splashScreen: SplashScreen,
    authService, coletaService, message, navCtrl, oneSignal, appService, geolocation, backgroundGeolocation
    // private notificationService: NotificationService,
    ) {
        this.modalCtrl = modalCtrl;
        this.storage = storage;
        this.platform = platform;
        this.authService = authService;
        this.coletaService = coletaService;
        this.message = message;
        this.navCtrl = navCtrl;
        this.oneSignal = oneSignal;
        this.appService = appService;
        this.geolocation = geolocation;
        this.backgroundGeolocation = backgroundGeolocation;
        this.appPages = [];
        this.notifications = [];
        this.intervalColetas = null;
        this.sending = false;
        this.coletas = [];
        this.user = {};
        // console.log('app component');
        this.initializeApp();
        this.appService.loginObserver.subscribe((data) => {
            console.log('appService', data);
            if (data == "sessionStart") {
                this.getUser();
            }
        });
    }
    initializeApp() {
        // this.platform.ready().then(() => {
        // this.statusBar.overlaysWebView(false);
        // this.statusBar.backgroundColorByHexString('#e46e06');
        console.log(this.platform.platforms());
        if (!this.platform.is('mobileweb') && this.platform.is('mobile')) {
            this.startOnSignal();
        }
        this.getUser();
        // this.getColetas();
        // this.setIntervalColetas();
        // this.splashScreen.hide();
        // });
    }
    getUser() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            const session = yield this.authService.getSession();
            //console.log('session', session);
            if (session) {
                this.user = session.user;
                if (session != null) {
                    setInterval(() => {
                        this.geolocation.getCurrentPosition().then((resp) => {
                            console.log(resp.coords.latitude);
                            console.log(resp.coords.longitude);
                            this.user.longitude = resp.coords.longitude;
                            this.user.latitude = resp.coords.latitude;
                            this.authService.updateUser(this.user, this.user.uuid).then(() => {
                                // console.log('addOneSignalID success');
                            });
                        }).catch((error) => {
                            console.log('Error getting location', error);
                        });
                    }, 40000);
                }
                if (session.user.tipo == 0) {
                    this.appPages = [
                        { title: 'Início', url: '/home', icon: 'mail' },
                        { title: 'Roteiros', url: '/roteiros', icon: 'mail', },
                        // { title: 'Envios Pendentes', url: '/coletas-pending', icon: 'mail', },
                        { title: 'Relatório Malotes', url: '/malote-report', icon: 'mail', },
                        { title: 'Relatório Entregas', url: '/entrega-report', icon: 'mail', },
                    ];
                    // this.getNotifications({ portador_id: this.user.uuid });
                }
                else {
                    this.appPages = [
                        { title: 'Início', url: '/home', icon: 'mail' }
                    ];
                }
                this.addOneSignalID();
            }
        });
    }
    getColetas() {
        this.storage.get('coletas').then(res => {
            console.log('coletas', res);
            if (res && res != null) { //temos coletas
                this.coletas = res;
            }
        }).catch(err => {
            this.message.toastError('Falha ao verificar coletas no dispositivo.');
            console.log(err);
        });
    }
    setIntervalColetas() {
        this.intervalColetas = setInterval(() => {
            if (this.sending == false) {
                this.sendColetas();
            }
            else {
                console.log('sending', this.sending);
            }
        }, 5000);
    }
    sendColetas() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            this.sending = true;
            console.log('sendColetas');
            if (this.coletas.length == 0) {
                setTimeout(() => {
                    this.getColetas();
                    this.sending = false;
                }, 30000);
                return;
            }
            for (let i = 0; i < this.coletas.length; i++) {
                yield this.coletaService.createColeta(this.coletas[i]).then(res => {
                    // this.coletas[i].cStatus = 10;
                    this.coletas.splice(i, 1);
                }).catch(err => {
                    // this.coletas[i].cStatus = 0;
                    this.coletas[i].status = err.error.message;
                });
            }
            console.log(this.coletas);
            this.storage.set('coletas', this.coletas).then(() => {
                // this.navCtrl.navigateRoot('/home');
                this.sending = false;
            }).catch(err => {
                console.log('Falha ao atualizar coletas no dispositivo. ', err);
            });
            // setTimeout(() => {
            //   this.sending = false;
            // }, 12000);
        });
    }
    logout() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.remove('sessionSawber');
            yield this.storage.remove('nameAuditor');
            this.navCtrl.navigateRoot('/auth');
        });
    }
    startOnSignal() {
        console.log('startOnSignal');
        this.oneSignal.startInit('6594fac1-f555-4f3c-8bec-33dc561fc423', '114897601718');
        this.oneSignal.inFocusDisplaying(this.oneSignal.OSInFocusDisplayOption.InAppAlert);
        this.oneSignal.handleNotificationReceived().subscribe((jsonData) => {
            // do something when notification is received
            console.log('handleNotificationReceived', jsonData);
            // let dados = jsonData.payload.additionalData;
            // if (dados) {
            //   if (dados.solicitacao && dados.solicitacao.prioridade == 'URGENTE') {
            //     this.openModalConfirme(dados);
            //   }
            //   if (dados.devolucao && dados.devolucao.prioridade == 'URGENTE') {
            //     this.openModalConfirme(dados);
            //   }
            // }
        });
        this.oneSignal.handleNotificationOpened().subscribe((jsonData) => {
            // do something when a notification is opened
            console.log('handleNotificationOpened', jsonData);
            let dados = jsonData.notification.payload.additionalData;
            if (dados) {
                if (dados.solicitacao && dados.solicitacao.prioridade == 'URGENTE') {
                    this.message.openModalConfirme(dados);
                }
                if (dados.devolucao && dados.devolucao.prioridade == 'URGENTE') {
                    this.message.openModalConfirme(dados);
                }
            }
        });
        this.oneSignal.endInit();
        // NOTE: Update the setAppId value below with your OneSignal AppId.
        // OneSignal.setAppId("6594fac1-f555-4f3c-8bec-33dc561fc423");
        // OneSignal.setNotificationOpenedHandler((jsonData) => {
        //   console.log('notificationOpenedCallback: ', jsonData);
        //   if (jsonData.notification.additionalData) {
        //     let data: any = jsonData.notification.additionalData;
        //     if (data.solicitacao && data.solicitacao.prioridade == 'URGENTE') {
        //       this.openModalConfirme(data);
        //     }
        //     if (data.devolucao && data.devolucao.prioridade == 'URGENTE') {
        //       this.openModalConfirme(data);
        //     }
        //   }
        // });
        // // iOS - Prompts the user for notification permissions.
        // //    * Since this shows a generic native prompt, we recommend instead using an In-App Message to prompt for notification permission (See step 6) to better communicate to your users what notifications they will get.
        // OneSignal.promptForPushNotificationsWithUserResponse((accepted) => {
        //   console.log("User accepted notifications: ", accepted);
        // });
    }
    addOneSignalID() {
        if (this.platform.is('mobileweb') || !this.platform.is('mobile')) {
            return;
        }
        this.oneSignal.getIds().then(res => {
            console.log('addOneSignalID', res);
            this.authService.updateUser({ one_signal_id: res.userId }, this.user.uuid).then(() => {
                console.log('addOneSignalID success');
            });
        });
        // OneSignal.getDeviceState(res => {
        //   console.log('addOneSignalID', res);
        //   this.authService.updateUser({ one_signal_id: res.userId }, this.user.uuid).then(() => {
        //     console.log('addOneSignalID success');
        //   });
        // })
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.ModalController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_3__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.Platform },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: _services_coleta_service__WEBPACK_IMPORTED_MODULE_5__.ColetaService },
    { type: _services_message_service__WEBPACK_IMPORTED_MODULE_4__.MessageService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.NavController },
    { type: _ionic_native_onesignal_ngx__WEBPACK_IMPORTED_MODULE_7__.OneSignal },
    { type: _services_app_service__WEBPACK_IMPORTED_MODULE_6__.AppService },
    { type: _awesome_cordova_plugins_geolocation_ngx__WEBPACK_IMPORTED_MODULE_8__.Geolocation },
    { type: _awesome_cordova_plugins_background_geolocation_ngx__WEBPACK_IMPORTED_MODULE_9__.BackgroundGeolocation }
];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Component)({
        selector: 'app-root',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_app_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], AppComponent);



/***/ }),

/***/ 36747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/platform-browser */ 71570);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/storage */ 54357);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ionic/storage-angular */ 90516);
/* harmony import */ var localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! localforage-cordovasqlitedriver */ 82340);
/* harmony import */ var localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component */ 55041);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-routing.module */ 90158);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var _services_intercept_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./services/intercept.service */ 89054);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_common_locales_pt__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/locales/pt */ 84611);
/* harmony import */ var _angular_common_locales_pt__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_angular_common_locales_pt__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _angular_common_locales_extra_pt__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/locales/extra/pt */ 1501);
/* harmony import */ var _angular_common_locales_extra_pt__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_angular_common_locales_extra_pt__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/barcode-scanner/ngx */ 10926);
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ 81288);
/* harmony import */ var _pages_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./pages/shared/shared.module */ 40950);
/* harmony import */ var _ionic_native_onesignal_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/onesignal/ngx */ 95795);
/* harmony import */ var _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/background-mode/ngx */ 25998);
/* harmony import */ var _ionic_native_foreground_service_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/foreground-service/ngx */ 24677);
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ 52034);
/* harmony import */ var _awesome_cordova_plugins_geolocation_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @awesome-cordova-plugins/geolocation/ngx */ 61171);
/* harmony import */ var _awesome_cordova_plugins_background_geolocation_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @awesome-cordova-plugins/background-geolocation/ngx */ 98528);

















// import { StatusBar } from '@ionic-native/status-bar/ngx';
// import { SplashScreen } from '@ionic-native/splash-screen/ngx';



// import { Camera } from '@awesome-cordova-plugins/camera/ngx';





(0,_angular_common__WEBPACK_IMPORTED_MODULE_15__.registerLocaleData)((_angular_common_locales_pt__WEBPACK_IMPORTED_MODULE_5___default()), 'br', (_angular_common_locales_extra_pt__WEBPACK_IMPORTED_MODULE_6___default()));
let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_18__.BrowserModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonicModule.forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_3__.AppRoutingModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_20__.HttpClientModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_21__.FormsModule,
            _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_22__.IonicStorageModule.forRoot({
                name: '__mySawber',
                driverOrder: [localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_1__._driver, _ionic_storage__WEBPACK_IMPORTED_MODULE_0__.Drivers.IndexedDB, _ionic_storage__WEBPACK_IMPORTED_MODULE_0__.Drivers.LocalStorage]
            }),
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_23__.NgbModule,
            _pages_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__.SharedModule,
        ],
        providers: [
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_24__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonicRouteStrategy },
            { provide: _angular_core__WEBPACK_IMPORTED_MODULE_17__.LOCALE_ID, useValue: 'br' },
            { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_20__.HTTP_INTERCEPTORS, useClass: _services_intercept_service__WEBPACK_IMPORTED_MODULE_4__.InterceptService, multi: true },
            // StatusBar,
            // SplashScreen,
            _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_7__.BarcodeScanner,
            // Camera,
            _awesome_cordova_plugins_geolocation_ngx__WEBPACK_IMPORTED_MODULE_13__.Geolocation,
            _awesome_cordova_plugins_background_geolocation_ngx__WEBPACK_IMPORTED_MODULE_14__.BackgroundGeolocation,
            _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_10__.BackgroundMode,
            _ionic_native_foreground_service_ngx__WEBPACK_IMPORTED_MODULE_11__.ForegroundService,
            _ionic_native_onesignal_ngx__WEBPACK_IMPORTED_MODULE_9__.OneSignal,
            _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_12__.ScreenOrientation
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 95107:
/*!**************************************!*\
  !*** ./src/app/guards/auth.guard.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthGuard": () => (/* binding */ AuthGuard)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/storage */ 54357);




let AuthGuard = class AuthGuard {
    constructor(storage, router) {
        this.storage = storage;
        this.router = router;
    }
    canActivate(route, state) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.create();
            const session = yield this.storage.get('sessionSawber');
            // console.log(session);
            if (!session) {
                return this.router.navigateRoot('/auth');
            }
            return true;
        });
    }
};
AuthGuard.ctorParameters = () => [
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_0__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
AuthGuard = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], AuthGuard);



/***/ }),

/***/ 81470:
/*!*****************************************************************!*\
  !*** ./src/app/pages/medico-form/medico-form-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MedicoFormPageRoutingModule": () => (/* binding */ MedicoFormPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _medico_form_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./medico-form.page */ 83973);




const routes = [
    {
        path: '',
        component: _medico_form_page__WEBPACK_IMPORTED_MODULE_0__.MedicoFormPage
    }
];
let MedicoFormPageRoutingModule = class MedicoFormPageRoutingModule {
};
MedicoFormPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MedicoFormPageRoutingModule);



/***/ }),

/***/ 12132:
/*!*********************************************************!*\
  !*** ./src/app/pages/medico-form/medico-form.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MedicoFormPageModule": () => (/* binding */ MedicoFormPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _medico_form_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./medico-form-routing.module */ 81470);
/* harmony import */ var _medico_form_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./medico-form.page */ 83973);







let MedicoFormPageModule = class MedicoFormPageModule {
};
MedicoFormPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _medico_form_routing_module__WEBPACK_IMPORTED_MODULE_0__.MedicoFormPageRoutingModule
        ],
        declarations: [_medico_form_page__WEBPACK_IMPORTED_MODULE_1__.MedicoFormPage]
    })
], MedicoFormPageModule);



/***/ }),

/***/ 83973:
/*!*******************************************************!*\
  !*** ./src/app/pages/medico-form/medico-form.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MedicoFormPage": () => (/* binding */ MedicoFormPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_medico_form_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./medico-form.page.html */ 48130);
/* harmony import */ var _medico_form_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./medico-form.page.scss */ 96098);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_app_services_medico_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/medico.service */ 74633);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/message.service */ 42684);







let MedicoFormPage = class MedicoFormPage {
    constructor(modalCtrl, service, message) {
        this.modalCtrl = modalCtrl;
        this.service = service;
        this.message = message;
        this.dados = {};
    }
    ngOnInit() {
    }
    close(params = undefined) {
        this.modalCtrl.dismiss(params);
    }
    submit(form) {
        if (!form.valid) {
            return this.message.toastError('Todos os campos são obrigatórios.');
        }
        console.log(this.dados);
        this.create();
    }
    create() {
        this.message.load_present();
        this.service.createMedico(this.dados).then(res => {
            this.close(res);
        }).finally(() => this.message.load_dismiss());
    }
};
MedicoFormPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController },
    { type: src_app_services_medico_service__WEBPACK_IMPORTED_MODULE_2__.MedicoService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_3__.MessageService }
];
MedicoFormPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-medico-form',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_medico_form_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_medico_form_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], MedicoFormPage);



/***/ }),

/***/ 79538:
/*!*************************************************************************!*\
  !*** ./src/app/pages/shared/modal-clinicas/modal-clinicas.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalClinicasComponent": () => (/* binding */ ModalClinicasComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_modal_clinicas_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./modal-clinicas.component.html */ 86767);
/* harmony import */ var _modal_clinicas_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal-clinicas.component.scss */ 62601);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 37556);
/* harmony import */ var src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/coleta.service */ 35738);







let ModalClinicasComponent = class ModalClinicasComponent {
    constructor(modalCtrl, service, authService) {
        this.modalCtrl = modalCtrl;
        this.service = service;
        this.authService = authService;
        this.filters = { termo: '' };
        this.dataSource = [];
        this.loading = false;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const session = yield this.authService.getSession();
            console.log(session);
            this.filters.user_id = session.user.uuid;
            if (this.roteiro) {
                this.filters.dia = new Date().getDay();
            }
            this.search();
        });
    }
    close(params = undefined) {
        this.modalCtrl.dismiss(params);
    }
    getDay() {
        const day = new Date().getDay();
        const days = ['', 'Segunda Feira', 'Terça Feira', 'Quarta Feira', 'Quinta Feira', 'Sexta Feira', 'Sábado', 'Domingo'];
        return days[day];
    }
    doRefresh(event) {
        this.search();
        event.target.complete();
    }
    search() {
        this.loading = true;
        this.service.getClinicas(this.filters).then(res => {
            this.dataSource = res;
        }).finally(() => this.loading = false);
    }
    changeItem(item) {
        this.close(item);
    }
};
ModalClinicasComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController },
    { type: src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_3__.ColetaService },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService }
];
ModalClinicasComponent.propDecorators = {
    roteiro: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input }]
};
ModalClinicasComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-modal-clinicas',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_modal_clinicas_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_modal_clinicas_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ModalClinicasComponent);



/***/ }),

/***/ 58201:
/*!***************************************************************************************************!*\
  !*** ./src/app/pages/shared/modal-confirme-notification/modal-confirme-notification.component.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalConfirmeNotificationComponent": () => (/* binding */ ModalConfirmeNotificationComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_modal_confirme_notification_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./modal-confirme-notification.component.html */ 83240);
/* harmony import */ var _modal_confirme_notification_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal-confirme-notification.component.scss */ 16829);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/coleta.service */ 35738);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/message.service */ 42684);







let ModalConfirmeNotificationComponent = class ModalConfirmeNotificationComponent {
    constructor(modalCtrl, navCtrl, service, message) {
        this.modalCtrl = modalCtrl;
        this.navCtrl = navCtrl;
        this.service = service;
        this.message = message;
        this.dados = { itens: [] };
    }
    ngOnInit() {
        console.log('confirme', this.data);
        if (this.data.solicitacao) {
            this.getDadoSolicitacao(this.data.solicitacao.uuid);
        }
        if (this.data.devolucao) {
            this.getDadoDevolucao(this.data.devolucao.uuid);
        }
    }
    closeModal(params = undefined) {
        this.modalCtrl.dismiss(params);
    }
    getTitle() {
        if (this.data.solicitacao) {
            return 'Solicitação';
        }
        if (this.data.devolucao) {
            return 'Devolução';
        }
        return 'Notificação';
    }
    getDadoSolicitacao(id) {
        this.message.load_present();
        this.service.getSolicitacao(id).then(res => {
            this.dados = res;
        }).finally(() => this.message.load_dismiss());
    }
    getDadoDevolucao(id) {
        this.message.load_present();
        this.service.getDevolucao(id).then(res => {
            this.dados = res;
        }).finally(() => this.message.load_dismiss());
    }
    acceptSolicitacao(value) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            this.message.load_present();
            this.service.updateSolicitacao(this.dados.uuid, { origin: 'app', portador_accepted: value }).then(res => {
                if (value == 0) {
                    window.location.reload();
                }
                else if (value == 1) {
                    //this.navCtrl.back();
                    window.location.reload();
                    //this.modalCtrl.dismiss();
                }
                // window.location.reload();
            }).finally(() => this.message.load_dismiss());
        });
    }
    acceptDevolucao(value) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            this.message.load_present();
            this.service.updateDevolucao(this.dados.uuid, { origin: 'app', portador_accepted: value }).then(res => {
                if (value == 0) {
                    window.location.reload();
                }
                else if (value == 1) {
                    //this.navCtrl.back();
                    window.location.reload();
                    // this.modalCtrl.dismiss();
                }
                // window.location.reload();
            }).finally(() => this.message.load_dismiss());
        });
    }
    finish(value) {
        if (this.data.solicitacao) {
            this.acceptSolicitacao(value);
        }
        if (this.data.devolucao) {
            this.acceptDevolucao(value);
        }
    }
};
ModalConfirmeNotificationComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController },
    { type: src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_2__.ColetaService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_3__.MessageService }
];
ModalConfirmeNotificationComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input }]
};
ModalConfirmeNotificationComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-modal-confirme-notification',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_modal_confirme_notification_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_modal_confirme_notification_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ModalConfirmeNotificationComponent);



/***/ }),

/***/ 52390:
/*!****************************************************************************!*\
  !*** ./src/app/pages/shared/modal-medicos/modal-medicos-routing.module.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalMedicosPageRoutingModule": () => (/* binding */ ModalMedicosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _modal_medicos_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modal-medicos.page */ 80428);




const routes = [
    {
        path: '',
        component: _modal_medicos_page__WEBPACK_IMPORTED_MODULE_0__.ModalMedicosPage
    }
];
let ModalMedicosPageRoutingModule = class ModalMedicosPageRoutingModule {
};
ModalMedicosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ModalMedicosPageRoutingModule);



/***/ }),

/***/ 63511:
/*!********************************************************************!*\
  !*** ./src/app/pages/shared/modal-medicos/modal-medicos.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalMedicosPageModule": () => (/* binding */ ModalMedicosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _modal_medicos_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modal-medicos-routing.module */ 52390);
/* harmony import */ var _modal_medicos_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal-medicos.page */ 80428);







let ModalMedicosPageModule = class ModalMedicosPageModule {
};
ModalMedicosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _modal_medicos_routing_module__WEBPACK_IMPORTED_MODULE_0__.ModalMedicosPageRoutingModule
        ],
        declarations: [_modal_medicos_page__WEBPACK_IMPORTED_MODULE_1__.ModalMedicosPage]
    })
], ModalMedicosPageModule);



/***/ }),

/***/ 80428:
/*!******************************************************************!*\
  !*** ./src/app/pages/shared/modal-medicos/modal-medicos.page.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalMedicosPage": () => (/* binding */ ModalMedicosPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_modal_medicos_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./modal-medicos.page.html */ 79178);
/* harmony import */ var _modal_medicos_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal-medicos.page.scss */ 50590);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 37556);
/* harmony import */ var src_app_services_medico_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/medico.service */ 74633);
/* harmony import */ var _medico_form_medico_form_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../medico-form/medico-form.page */ 83973);








let ModalMedicosPage = class ModalMedicosPage {
    constructor(modalCtrl, service, authService) {
        this.modalCtrl = modalCtrl;
        this.service = service;
        this.authService = authService;
        this.filters = { termo: '' };
        this.dataSource = [];
        this.loading = false;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            // const session = await this.authService.getSession();
            // console.log(session);
            // this.filters.user_id = session.user.uuid;
            this.search();
        });
    }
    close(params = undefined) {
        this.modalCtrl.dismiss(params);
    }
    doRefresh(event) {
        this.search();
        event.target.complete();
    }
    search() {
        this.loading = true;
        this.service.getMedicos(this.filters).then(res => {
            this.dataSource = res;
        }).finally(() => this.loading = false);
    }
    changeItem(item) {
        this.close(item);
    }
    addMedico() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _medico_form_medico_form_page__WEBPACK_IMPORTED_MODULE_4__.MedicoFormPage
            });
            yield modal.present();
            modal.onDidDismiss().then(res => {
                this.search();
            });
        });
    }
};
ModalMedicosPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: src_app_services_medico_service__WEBPACK_IMPORTED_MODULE_3__.MedicoService },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService }
];
ModalMedicosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-modal-medicos',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_modal_medicos_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_modal_medicos_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ModalMedicosPage);



/***/ }),

/***/ 52507:
/*!****************************************************************************!*\
  !*** ./src/app/pages/shared/modal-motoboy/modal-motoboy-routing.module.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalMotoboyPageRoutingModule": () => (/* binding */ ModalMotoboyPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _modal_motoboy_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modal-motoboy.page */ 16447);




const routes = [
    {
        path: '',
        component: _modal_motoboy_page__WEBPACK_IMPORTED_MODULE_0__.ModalMotoboyPage
    }
];
let ModalMotoboyPageRoutingModule = class ModalMotoboyPageRoutingModule {
};
ModalMotoboyPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ModalMotoboyPageRoutingModule);



/***/ }),

/***/ 73011:
/*!********************************************************************!*\
  !*** ./src/app/pages/shared/modal-motoboy/modal-motoboy.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalMotoboyPageModule": () => (/* binding */ ModalMotoboyPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _modal_motoboy_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modal-motoboy-routing.module */ 52507);
/* harmony import */ var _modal_motoboy_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal-motoboy.page */ 16447);







let ModalMotoboyPageModule = class ModalMotoboyPageModule {
};
ModalMotoboyPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _modal_motoboy_routing_module__WEBPACK_IMPORTED_MODULE_0__.ModalMotoboyPageRoutingModule
        ],
        declarations: [_modal_motoboy_page__WEBPACK_IMPORTED_MODULE_1__.ModalMotoboyPage]
    })
], ModalMotoboyPageModule);



/***/ }),

/***/ 16447:
/*!******************************************************************!*\
  !*** ./src/app/pages/shared/modal-motoboy/modal-motoboy.page.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalMotoboyPage": () => (/* binding */ ModalMotoboyPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_modal_motoboy_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./modal-motoboy.page.html */ 75280);
/* harmony import */ var _modal_motoboy_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal-motoboy.page.scss */ 84573);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_app_services_motoboy_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/motoboy.service */ 3756);






let ModalMotoboyPage = class ModalMotoboyPage {
    constructor(modalCtrl, service) {
        this.modalCtrl = modalCtrl;
        this.service = service;
        this.filters = { termo: '' };
        this.dataSource = [];
        this.loading = false;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            // const session = await this.authService.getSession();
            // console.log(session);
            // this.filters.user_id = session.user.uuid;
            this.search();
        });
    }
    close(params = undefined) {
        this.modalCtrl.dismiss(params);
    }
    doRefresh(event) {
        this.search();
        event.target.complete();
    }
    search() {
        this.loading = true;
        this.service.getListing(this.filters).then(res => {
            this.dataSource = res;
        }).finally(() => this.loading = false);
    }
    changeItem(item) {
        this.close(item);
    }
};
ModalMotoboyPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController },
    { type: src_app_services_motoboy_service__WEBPACK_IMPORTED_MODULE_2__.MotoboyService }
];
ModalMotoboyPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-modal-motoboy',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_modal_motoboy_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_modal_motoboy_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ModalMotoboyPage);



/***/ }),

/***/ 2891:
/*!***************************************************************************!*\
  !*** ./src/app/pages/shared/modal-signature/modal-signature.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalSignatureComponent": () => (/* binding */ ModalSignatureComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_modal_signature_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./modal-signature.component.html */ 25238);
/* harmony import */ var _modal_signature_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal-signature.component.scss */ 65516);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/screen-orientation/ngx */ 52034);
/* harmony import */ var signature_pad__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! signature_pad */ 35734);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/message.service */ 42684);








let ModalSignatureComponent = class ModalSignatureComponent {
    constructor(modalCtrl, elementRef, screenOrientation, messageService) {
        this.modalCtrl = modalCtrl;
        this.elementRef = elementRef;
        this.screenOrientation = screenOrientation;
        this.messageService = messageService;
    }
    closeModal(params = undefined) {
        this.modalCtrl.dismiss(params);
    }
    ngOnInit() {
        console.log();
        if (this.screenOrientation.type == this.screenOrientation.ORIENTATIONS.PORTRAIT_PRIMARY) {
            this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.LANDSCAPE);
        }
        this.init();
    }
    ngOnDestroy() {
        this.screenOrientation.unlock();
    }
    onResize(event) {
        this.init();
    }
    init() {
        const canvas = this.elementRef.nativeElement.querySelector('canvas');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight - 60;
        if (this.signaturePad) {
            this.signaturePad.clear(); // Clear the pad on init
        }
    }
    ngAfterViewInit() {
        this.signaturePad = new signature_pad__WEBPACK_IMPORTED_MODULE_3__.default(this.signaturePadElement.nativeElement);
        this.signaturePad.clear();
        this.signaturePad.penColor = 'rgb(56,128,255)';
    }
    save() {
        const sign = this.signaturePad.toDataURL();
        console.log('save sign', sign.length);
        if (sign.length < 8000) {
            return this.messageService.toastError('Assinatura muito curta');
        }
        this.closeModal(sign);
    }
    clear() {
        this.signaturePad.clear();
    }
};
ModalSignatureComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ElementRef },
    { type: _ionic_native_screen_orientation_ngx__WEBPACK_IMPORTED_MODULE_2__.ScreenOrientation },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__.MessageService }
];
ModalSignatureComponent.propDecorators = {
    signaturePadElement: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['canvas', { static: true },] }],
    onResize: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.HostListener, args: ['window:resize', ['$event'],] }]
};
ModalSignatureComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-modal-signature',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_modal_signature_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_modal_signature_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ModalSignatureComponent);



/***/ }),

/***/ 40950:
/*!***********************************************!*\
  !*** ./src/app/pages/shared/shared.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SharedModule": () => (/* binding */ SharedModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _modal_clinicas_modal_clinicas_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modal-clinicas/modal-clinicas.component */ 79538);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _modal_motoboy_modal_motoboy_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal-motoboy/modal-motoboy.module */ 73011);
/* harmony import */ var _modal_medicos_modal_medicos_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modal-medicos/modal-medicos.module */ 63511);
/* harmony import */ var _medico_form_medico_form_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../medico-form/medico-form.module */ 12132);
/* harmony import */ var _modal_confirme_notification_modal_confirme_notification_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./modal-confirme-notification/modal-confirme-notification.component */ 58201);
/* harmony import */ var _modal_signature_modal_signature_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./modal-signature/modal-signature.component */ 2891);











let SharedModule = class SharedModule {
};
SharedModule = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule)({
        declarations: [
            _modal_clinicas_modal_clinicas_component__WEBPACK_IMPORTED_MODULE_0__.ModalClinicasComponent,
            _modal_confirme_notification_modal_confirme_notification_component__WEBPACK_IMPORTED_MODULE_4__.ModalConfirmeNotificationComponent,
            _modal_signature_modal_signature_component__WEBPACK_IMPORTED_MODULE_5__.ModalSignatureComponent
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_8__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonicModule,
            _modal_motoboy_modal_motoboy_module__WEBPACK_IMPORTED_MODULE_1__.ModalMotoboyPageModule,
            _modal_medicos_modal_medicos_module__WEBPACK_IMPORTED_MODULE_2__.ModalMedicosPageModule,
            _medico_form_medico_form_module__WEBPACK_IMPORTED_MODULE_3__.MedicoFormPageModule,
        ],
        exports: [
            _modal_signature_modal_signature_component__WEBPACK_IMPORTED_MODULE_5__.ModalSignatureComponent
        ]
    })
], SharedModule);



/***/ }),

/***/ 66475:
/*!*****************************************!*\
  !*** ./src/app/services/app.service.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppService": () => (/* binding */ AppService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 79441);



let AppService = class AppService {
    constructor() {
        this.loginObserver = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
    }
    passValue(data) {
        //passing the data as the next observable
        this.loginObserver.next(data);
    }
};
AppService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], AppService);



/***/ }),

/***/ 37556:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/storage */ 54357);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ 92340);





let AuthService = class AuthService {
    constructor(http, storage) {
        this.http = http;
        this.storage = storage;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.url;
    }
    getSession() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.create();
            const session = yield this.storage.get('sessionSawber');
            return session;
        });
    }
    getExameTypes() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.create();
            const dados = yield this.storage.get('ExameTypeSawber');
            return dados;
        });
    }
    login(data) {
        return this.http.post(`${this.url}/auth/login`, data).toPromise();
    }
    updateUser(data, id) {
        return this.http.put(`${this.url}/app/users/${id}`, data).toPromise();
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_0__.Storage }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 35738:
/*!********************************************!*\
  !*** ./src/app/services/coleta.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetaService": () => (/* binding */ ColetaService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let ColetaService = class ColetaService {
    constructor(http) {
        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url;
    }
    createColeta(data) {
        return this.http.post(`${this.url}/app/coleta`, data).toPromise();
    }
    getColeta(id) {
        return this.http.get(`${this.url}/app/coleta/${id}`).toPromise();
    }
    updateColeta(data, id) {
        return this.http.put(`${this.url}/app/coleta/${id}`, data).toPromise();
    }
    createItemColeta(data) {
        return this.http.post(`${this.url}/app/coleta/item`, data).toPromise();
    }
    removeItemColeta(id) {
        return this.http.delete(`${this.url}/app/coleta/item/${id}`).toPromise();
    }
    getClinicas(queryParams) {
        return this.http.get(`${this.url}/app/coleta/getClinicas`, { params: queryParams }).toPromise();
    }
    getCustom(endpoint, queryParams = {}) {
        return this.http.get(`${this.url}/${'web/motoboy/available'}`, { params: queryParams }).toPromise();
    }
    getClinica(id) {
        return this.http.get(`${this.url}/app/coleta/getClinica/${id}`).toPromise();
    }
    checkColetaCode(code) {
        return this.http.get(`${this.url}/app/coleta/checkColetaCode/${code}`).toPromise();
    }
    getExameTypes() {
        return this.http.get(`${this.url}/app/coleta/getExameTypes`).toPromise();
    }
    setExameTypes(data) {
        return this.http.post(`${this.url}/app/coleta/setExameTypes`, data).toPromise();
    }
    getSolicitacoes(queryParams = {}) {
        return this.http.get(`${this.url}/app/solicitacoes`, { params: queryParams }).toPromise();
    }
    getSolicitacao(id) {
        return this.http.get(`${this.url}/app/solicitacoes/${id}`).toPromise();
    }
    updateSolicitacao(id, dados) {
        return this.http.put(`${this.url}/app/solicitacoes/${id}`, dados).toPromise();
    }
    getDevolucoes(queryParams = {}) {
        return this.http.get(`${this.url}/app/devolucoes`, { params: queryParams }).toPromise();
    }
    getDevolucao(id) {
        return this.http.get(`${this.url}/app/devolucoes/${id}`).toPromise();
    }
    updateDevolucao(id, dados) {
        return this.http.put(`${this.url}/app/devolucoes/${id}`, dados).toPromise();
    }
};
ColetaService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
ColetaService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], ColetaService);



/***/ }),

/***/ 89054:
/*!***********************************************!*\
  !*** ./src/app/services/intercept.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InterceptService": () => (/* binding */ InterceptService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _message_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./message.service */ 42684);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 98636);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 54357);









// import { Store } from "@ngrx/store";
// import { AppState } from "../core/reducers";
// import { Logout } from "../core/actions/auth.action";
let InterceptService = class InterceptService {
    constructor(
    // private store: Store<AppState>,
    storage, router, message, redirect) {
        this.storage = storage;
        this.router = router;
        this.message = message;
        this.redirect = redirect;
        this.router.events.subscribe(event => {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_3__.NavigationEnd) {
                this.returnUrl = event.url;
            }
        });
        this.storage.create();
    }
    // intercept request and add token
    intercept(request, next) {
        // tslint:disable-next-line:no-debugger
        // modify request
        request = request.clone({
            setHeaders: {
                Authorization: `Bearer ${localStorage.getItem(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.authTokenKey)}`
            }
        });
        // console.log('----request----');
        // console.log(request);
        // console.log('--- end of request---');
        return next.handle(request).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.tap)(event => {
            if (event instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpResponse) {
                console.log('event intercept', event);
                if (event.status == 201) {
                    this.message.toastSuccess(event.body.message);
                }
            }
        }, (error) => (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            if (error.status == 0) {
                // this.message.alertNet();
            }
            else if (error.status == 401) {
                this.message.toastError('Faça login novamente para continuar');
                // this.modalCtrl.dismissAll();
                // this.store.dispatch(new Logout());
                yield this.storage.remove('sessionSawber');
                localStorage.removeItem(src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.authTokenKey);
                this.redirect.navigateRoot(['/auth']);
            }
            else {
                let message = "";
                if (Array.isArray(error.error.erros)) {
                    for (let err of error.error.erros) {
                        message += `${err} \n`;
                    }
                }
                else {
                    message = error.error.message;
                }
                this.message.toastError(message);
            }
            console.log('error intercept', error);
        })));
    }
};
InterceptService.ctorParameters = () => [
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _message_service__WEBPACK_IMPORTED_MODULE_1__.MessageService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController }
];
InterceptService = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Injectable)({
        providedIn: 'root'
    })
], InterceptService);



/***/ }),

/***/ 74633:
/*!********************************************!*\
  !*** ./src/app/services/medico.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MedicoService": () => (/* binding */ MedicoService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let MedicoService = class MedicoService {
    constructor(http) {
        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url;
    }
    getMedicos(queryParams) {
        return this.http.get(`${this.url}/app/medico`, { params: queryParams }).toPromise();
    }
    createMedico(data) {
        return this.http.post(`${this.url}/app/medico`, data).toPromise();
    }
    setMedicoClinica(dados) {
        return this.http.post(`${this.url}/app/medico/setMedicoClinica`, dados).toPromise();
    }
};
MedicoService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
MedicoService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], MedicoService);



/***/ }),

/***/ 42684:
/*!*********************************************!*\
  !*** ./src/app/services/message.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MessageService": () => (/* binding */ MessageService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic-native/barcode-scanner/ngx */ 10926);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _pages_shared_modal_confirme_notification_modal_confirme_notification_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../pages/shared/modal-confirme-notification/modal-confirme-notification.component */ 58201);





let MessageService = class MessageService {
    constructor(toastController, loadingController, alertController, modalCtrl, barcodeScanner) {
        this.toastController = toastController;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.modalCtrl = modalCtrl;
        this.barcodeScanner = barcodeScanner;
        this.isLoading = false;
    }
    presentToast(msg = '') {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                mode: 'ios',
                message: msg,
                duration: 2500,
            });
            toast.present();
        });
    }
    toastSuccess(msg = '') {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                cssClass: 'toast-success',
                mode: 'ios',
                buttons: ['ok'],
                message: msg,
                duration: 2500,
            });
            toast.present();
        });
    }
    toastError(msg = '') {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                cssClass: 'toast-danger',
                mode: 'ios',
                buttons: ['ok'],
                message: msg,
                duration: 4000,
            });
            toast.present();
        });
    }
    presentToastWithOptions() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                header: 'Toast header',
                message: 'Click to Close',
                position: 'top',
                buttons: [
                    {
                        side: 'start',
                        icon: 'star',
                        text: 'Favorite',
                        handler: () => {
                            console.log('Favorite clicked');
                        },
                    },
                    {
                        text: 'Done',
                        role: 'cancel',
                        handler: () => {
                            console.log('Cancel clicked');
                        },
                    },
                ],
            });
            toast.present();
        });
    }
    load_present() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingController
                .create({
                mode: 'ios',
                // duration: 5000,
                backdropDismiss: true,
            })
                .then((a) => {
                a.present().then(() => {
                    // console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss();
                    }
                });
            });
        });
    }
    load_dismiss() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingController.dismiss();
        });
    }
    alertError(msg = '', title = 'Ops!') {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'alert-error-class',
                header: title,
                mode: 'ios',
                //   subHeader: 'Subtitle',
                message: msg,
                buttons: ['OK'],
            });
            yield alert.present();
        });
    }
    alertSuccess(msg = '', title = '') {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'alert-success-class',
                header: title,
                mode: 'ios',
                //   subHeader: 'Subtitle',
                message: msg,
                buttons: ['OK'],
            });
            yield alert.present();
        });
    }
    loginFail() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: 'Ops',
                mode: 'ios',
                //   subHeader: 'Subtitle',
                message: 'Não conseguimos recuperar seus dados de login, por favor efetue o login por segurança!',
                buttons: ['OK'],
            });
            yield alert.present();
        });
    }
    readQRCode() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const result = yield this.barcodeScanner
                .scan({ formats: 'QR_CODE' })
                // .then(barcodeData => {
                //   console.log('Barcode data', barcodeData);
                // if (barcodeData.cancelled == false && barcodeData.format == "QR_CODE") {
                //   this.entregaForm(barcodeData.text);
                // }
                // })
                .catch((err) => {
                console.log('Error', err);
            });
            if (result.cancelled == false && result.format == 'QR_CODE') {
                return result.text;
                // this.entregaForm(result.text);
            }
            // else {
            // console.log('result Read QR Code', result);
            return false;
            // }
        });
    }
    openModalConfirme(dados) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _pages_shared_modal_confirme_notification_modal_confirme_notification_component__WEBPACK_IMPORTED_MODULE_1__.ModalConfirmeNotificationComponent,
                componentProps: { data: dados },
                cssClass: 'my-custom-class',
            });
            yield modal.present();
            return yield modal.onDidDismiss();
        });
    }
};
MessageService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController },
    { type: _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_0__.BarcodeScanner }
];
MessageService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root',
    })
], MessageService);



/***/ }),

/***/ 3756:
/*!*********************************************!*\
  !*** ./src/app/services/motoboy.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MotoboyService": () => (/* binding */ MotoboyService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 53882);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);




let MotoboyService = class MotoboyService {
    constructor(http) {
        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url;
    }
    getListing(queryParams) {
        return this.http.get(`${this.url}/app/motoboy`, { params: queryParams }).toPromise();
    }
    getColetas(queryParams) {
        return this.http.get(`${this.url}/app/motoboy/coletas`, { params: queryParams }).toPromise();
    }
    getColeta(uuid) {
        return this.http.get(`${this.url}/app/motoboy/coleta/${uuid}`).toPromise();
    }
    updateColeta(uuid, dados) {
        return this.http.put(`${this.url}/app/motoboy/coleta/${uuid}`, dados).toPromise();
    }
    getColetaItens(queryParams) {
        return this.http.get(`${this.url}/app/motoboy/coleta/item`, { params: queryParams }).toPromise();
    }
    //itens check
    updateItem(uuid, dados) {
        return this.http.put(`${this.url}/app/motoboy/coleta/item/${uuid}`, dados).toPromise();
    }
};
MotoboyService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
MotoboyService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], MotoboyService);



/***/ }),

/***/ 92340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    authTokenKey: 'sawber_token',
    // url: 'http://localhost:8000/api',
    // url: 'https://painel.sawber.com.br/api',
    // url: 'http://192.168.0.120:8000',
    //url: 'http://sawber.devio.codes/api',
    url: 'https://painel.sawber.com.br/api',
    coletasTemp: 'coletasTemp'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 14431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 61882);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 36747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 92340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 50863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		83750,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		90733,
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		20985,
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		93899,
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		5121,
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		52960,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		45473,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		57951,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		19787,
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		66165,
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		69569,
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		35119,
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		90799,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		68918,
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		94028,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		98107,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		72178,
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		20123,
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		18706,
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		12099,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		84868,
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		54377,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		15678,
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		16735,
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		42322,
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		57754,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		87686,
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		48555,
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		30568,
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		6231,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		45772,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		14977,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		42886,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		54990,
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		13810,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		2446,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		47619,
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		28393,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		56281,
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		35932,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		57970,
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		80298,
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		71006,
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		74783,
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		62749,
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		55404,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		39043,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 50863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 75158:
/*!***************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/app.component.html ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\n  <ion-split-pane contentId=\"main-content\">\n    <ion-menu contentId=\"main-content\" type=\"overlay\">\n\n      <ion-header>\n        <ion-toolbar color=\"primary\">\n          <ion-buttons slot=\"start\">\n            <ion-menu-button></ion-menu-button>\n          </ion-buttons>\n\n          <ion-title slot=\"end\">\n            <img src=\"assets/media/logo.png\">\n          </ion-title>\n        </ion-toolbar>\n      </ion-header>\n\n      <ion-content color=\"primary\">\n\n        <ion-list id=\"inbox-list\">\n          <!-- <ion-list-header>Usuário:</ion-list-header>\n          <ion-note>{{ user.nome | titlecase }}</ion-note> -->\n\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages; let i = index\">\n            <ion-item routerDirection=\"root\" [routerLink]=\"[p.url]\" lines=\"none\" detail=\"false\"\n              routerLinkActive=\"selected\" class=\"primary\">\n              <!-- <ion-icon slot=\"start\" [ios]=\"p.icon + '-outline'\" [md]=\"p.icon + '-sharp'\"></ion-icon> -->\n              <ion-label>{{ p.title }}</ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n\n          <!-- <ion-menu-toggle auto-hide=\"false\">\n            <ion-item (click)=\"logout()\" lines=\"none\" detail=\"false\" class=\"primary\">\n              <ion-badge slot=\"start\" color=\"warning\" *ngIf=\"notifications.length > 0\">{{notifications.length}}\n              </ion-badge>\n              <ion-label>Ocorrências</ion-label>\n            </ion-item>\n          </ion-menu-toggle> -->\n\n          <ion-menu-toggle auto-hide=\"false\">\n            <ion-item (click)=\"logout()\" lines=\"none\" detail=\"false\" class=\"primary\">\n              <!-- <ion-icon slot=\"start\" [ios]=\"p.icon + '-outline'\" [md]=\"p.icon + '-sharp'\"></ion-icon> -->\n              <ion-label>Sair</ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n\n      </ion-content>\n    </ion-menu>\n    <ion-router-outlet id=\"main-content\"></ion-router-outlet>\n  </ion-split-pane>\n</ion-app>\n");

/***/ }),

/***/ 48130:
/*!************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/medico-form/medico-form.page.html ***!
  \************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"close()\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-title>\n      Cadastrar Médico\n    </ion-title>\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n\n\n  <form #form=\"ngForm\" (ngSubmit)=\"submit(form)\">\n\n    <ion-item class=\"ion-margin-top\">\n      <ion-label position=\"floating\">Nome do Médico:</ion-label>\n      <ion-input type=\"text\" required [(ngModel)]=\"dados.nome\" name=\"nome\"></ion-input>\n    </ion-item>\n\n    <ion-item class=\"ion-margin-top\">\n      <ion-label position=\"floating\">CRM do Médico:</ion-label>\n      <ion-input type=\"tel\" required [(ngModel)]=\"dados.crm\" name=\"nome\"></ion-input>\n    </ion-item>\n\n    <div class=\"ion-margin-top\">\n      <ion-button expand=\"block\" color=\"tertiary\" type=\"submit\">Cadastrar</ion-button>\n    </div>\n\n  </form>\n\n</ion-content>\n");

/***/ }),

/***/ 86767:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/shared/modal-clinicas/modal-clinicas.component.html ***!
  \******************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"close()\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-title *ngIf=\"roteiro\">\n      Roteiro {{getDay()}}\n    </ion-title>\n    <ion-title *ngIf=\"!roteiro\">\n      Clinicas/Locais\n    </ion-title>\n  </ion-toolbar>\n\n  <ion-toolbar color=\"primary\">\n    <ion-searchbar placeholder=\"Pesquisa...\" debounce=\"600\" (ionChange)=\"search()\" [(ngModel)]=\"filters.termo\">\n    </ion-searchbar>\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <div *ngIf=\"!loading\">\n    <ion-list class=\"bg-transprante ion-margin-top\">\n      <ion-item *ngFor=\"let item of dataSource\" (click)=\"changeItem(item)\">\n        <ion-label class=\"ion-text-wrap\">\n          <h2>{{ item.description | titlecase }}</h2>\n          <p>{{item.logradouro}}, Nº {{item.numero}}, {{item.complemento}}, {{item.bairro}}, {{item.cidade}}</p>\n        </ion-label>\n      </ion-item>\n    </ion-list>\n  </div>\n\n\n\n\n  <div *ngIf=\"loading\">\n    <ion-list class=\"bg-transprante\">\n\n      <ion-item>\n        <ion-label>\n          <h3>\n            <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n          </h3>\n          <p>\n            <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n          </p>\n        </ion-label>\n      </ion-item>\n\n      <ion-item>\n        <ion-label>\n          <h3>\n            <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n          </h3>\n          <p>\n            <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n          </p>\n        </ion-label>\n      </ion-item>\n\n      <ion-item>\n        <ion-label>\n          <h3>\n            <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n          </h3>\n          <p>\n            <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n          </p>\n        </ion-label>\n      </ion-item>\n\n      <ion-item>\n        <ion-label>\n          <h3>\n            <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n          </h3>\n          <p>\n            <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n          </p>\n        </ion-label>\n      </ion-item>\n\n    </ion-list>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ 83240:
/*!********************************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/shared/modal-confirme-notification/modal-confirme-notification.component.html ***!
  \********************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"closeModal()\">\n        <ion-icon name=\"arrow-back-outline\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-title>{{getTitle()}}</ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-card mode=\"ios\">\n    <ion-item lines=\"none\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2>Clínica: <strong *ngIf=\"dados.clinica\">{{dados.clinica.full_address}}</strong></h2>\n      </ion-label>\n    </ion-item>\n  </ion-card>\n\n  <ion-card mode=\"ios\">\n    <ion-item lines=\"none\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2>Médico: <strong *ngIf=\"dados.medico\">{{dados.medico.nome}}</strong></h2>\n      </ion-label>\n    </ion-item>\n  </ion-card>\n\n  <ion-card mode=\"ios\" *ngIf=\"data.solicitacao\">\n    <ion-item lines=\"none\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2>Tipo de Solicitação: <strong>{{dados.type == 'ENTREGA' ? 'Entrega de KIT' : 'Coleta de Material'}}</strong>\n        </h2>\n      </ion-label>\n    </ion-item>\n  </ion-card>\n\n  <ion-list *ngIf=\"data.solicitacao && dados.itens.length > 0\">\n    <ion-list-header color=\"primary\">Itens</ion-list-header>\n    <ion-item lines=\"full\" *ngFor=\"let item of dados.itens; let i = index\">\n      <ion-label class=\"ion-text-wrap\">\n        {{item.material}} - {{item.quantidade | number}}\n      </ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list *ngIf=\"data.devolucao && dados.itens.length > 0\">\n    <ion-list-header color=\"primary\">Itens</ion-list-header>\n    <ion-item lines=\"full\" *ngFor=\"let item of dados.itens; let i = index\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2>Material: <strong>{{item.exame_type}}</strong></h2>\n        <h2>Paciente: <strong>{{item.paciente}}</strong></h2>\n        <span>Motivo: {{item.motivo}}</span>\n      </ion-label>\n    </ion-item>\n  </ion-list>\n\n  <div class=\"ion-padding\">\n    <ion-row>\n      <ion-col>\n        <ion-button color=\"tertiary\" fill=\"outline\" expand=\"block\" (click)=\"finish(0)\">\n          Recusar\n        </ion-button>\n      </ion-col>\n      <ion-col>\n        <ion-button color=\"tertiary\" expand=\"block\" (click)=\"finish(1)\">\n          Aceitar\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ 79178:
/*!***********************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/shared/modal-medicos/modal-medicos.page.html ***!
  \***********************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"close()\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-title>\n      Médicos\n    </ion-title>\n  </ion-toolbar>\n\n  <ion-toolbar color=\"primary\">\n    <ion-searchbar placeholder=\"Pesquisa...\" debounce=\"600\" (ionChange)=\"search()\" [(ngModel)]=\"filters.termo\">\n    </ion-searchbar>\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <div *ngIf=\"!loading\">\n    <ion-list class=\"bg-transprante ion-margin-top\">\n      <ion-item lines=\"full\" *ngFor=\"let item of dataSource\" (click)=\"changeItem(item)\">\n        <ion-label class=\"ion-text-wrap\">\n          <h2>{{ item.nome | titlecase }}</h2>\n          <p>CRM: {{item.crm}}</p>\n        </ion-label>\n      </ion-item>\n    </ion-list>\n  </div>\n\n\n  <div *ngIf=\"loading\">\n    <ion-list class=\"bg-transprante\">\n\n      <ion-item>\n        <ion-label>\n          <h3>\n            <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n          </h3>\n          <p>\n            <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n          </p>\n        </ion-label>\n      </ion-item>\n\n      <ion-item>\n        <ion-label>\n          <h3>\n            <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n          </h3>\n          <p>\n            <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n          </p>\n        </ion-label>\n      </ion-item>\n\n      <ion-item>\n        <ion-label>\n          <h3>\n            <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n          </h3>\n          <p>\n            <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n          </p>\n        </ion-label>\n      </ion-item>\n\n      <ion-item>\n        <ion-label>\n          <h3>\n            <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n          </h3>\n          <p>\n            <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n          </p>\n        </ion-label>\n      </ion-item>\n\n    </ion-list>\n  </div>\n\n  <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button color=\"primary\" (click)=\"addMedico()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n</ion-content>\n");

/***/ }),

/***/ 75280:
/*!***********************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/shared/modal-motoboy/modal-motoboy.page.html ***!
  \***********************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"close()\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-title>\n      Pesquisar Motoboy\n    </ion-title>\n  </ion-toolbar>\n\n  <ion-toolbar color=\"primary\">\n    <ion-searchbar placeholder=\"Pesquisa...\" debounce=\"600\" (ionChange)=\"search()\" [(ngModel)]=\"filters.termo\">\n    </ion-searchbar>\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <div *ngIf=\"!loading\">\n    <ion-list class=\"bg-transprante ion-margin-top\">\n      <ion-item lines=\"full\" *ngFor=\"let item of dataSource\" (click)=\"changeItem(item)\">\n        <ion-label class=\"ion-text-wrap\">\n          <h2>{{ item.nome | titlecase }}</h2>\n          <!-- <p>CRM: {{item.crm}}</p> -->\n        </ion-label>\n      </ion-item>\n    </ion-list>\n  </div>\n\n\n  <div *ngIf=\"loading\">\n    <ion-list class=\"bg-transprante\">\n\n      <ion-item>\n        <ion-label>\n          <h3>\n            <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n          </h3>\n          <p>\n            <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n          </p>\n        </ion-label>\n      </ion-item>\n\n      <ion-item>\n        <ion-label>\n          <h3>\n            <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n          </h3>\n          <p>\n            <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n          </p>\n        </ion-label>\n      </ion-item>\n\n      <ion-item>\n        <ion-label>\n          <h3>\n            <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n          </h3>\n          <p>\n            <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n          </p>\n        </ion-label>\n      </ion-item>\n\n      <ion-item>\n        <ion-label>\n          <h3>\n            <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n          </h3>\n          <p>\n            <ion-skeleton-text animated style=\"width: 80%\"></ion-skeleton-text>\n          </p>\n        </ion-label>\n      </ion-item>\n\n    </ion-list>\n  </div>\n\n  <!-- <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button color=\"primary\" (click)=\"addMedico()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab> -->\n\n</ion-content>\n");

/***/ }),

/***/ 25238:
/*!********************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/shared/modal-signature/modal-signature.component.html ***!
  \********************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header id=\"header-signature\">\n  <ion-toolbar color=\"primary\">\n\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"closeModal()\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-title>\n      Assinatura\n    </ion-title>\n\n    <ion-buttons slot=\"end\">\n      <ion-button color=\"light\" expand=\"full\" (click)=\"clear()\"> Limpar</ion-button>\n      <ion-button color=\"light\" expand=\"full\" (click)=\"save()\"> Confirmar</ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n\n</ion-header>\n\n\n<ion-content>\n  <canvas class=\"signature-pad-canvas\" #canvas width=\"900\" height=\"400\" style=\"touch-action: none;\"></canvas>\n</ion-content>\n");

/***/ }),

/***/ 53040:
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = "ion-menu ion-content {\n  --background: var(--ion-item-background, var(--ion-background-color, #fff));\n}\n\nion-menu.md ion-content {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  --padding-top: 20px;\n  --padding-bottom: 20px;\n}\n\nion-menu.md ion-list {\n  padding: 20px 0;\n}\n\nion-menu.md ion-note {\n  margin-bottom: 30px;\n}\n\nion-menu.md ion-list-header,\nion-menu.md ion-note {\n  padding-left: 10px;\n}\n\nion-menu.md ion-list#inbox-list {\n  border-bottom: 1px solid var(--ion-color-step-150, #d7d8da);\n}\n\nion-menu.md ion-list#inbox-list ion-list-header {\n  font-size: 22px;\n  font-weight: 600;\n  min-height: 20px;\n}\n\nion-menu.md ion-list#labels-list ion-list-header {\n  font-size: 16px;\n  margin-bottom: 18px;\n  color: #757575;\n  min-height: 26px;\n}\n\nion-menu.md ion-item {\n  --padding-start: 10px;\n  --padding-end: 10px;\n  border-radius: 4px;\n}\n\n.primary {\n  --background: var(--ion-color-primary-rgb);\n  --color: white;\n}\n\nion-item.selected {\n  --background: rgba(var(--ion-color-light-rgb), 0.25) !important;\n}\n\nion-menu.md ion-item ion-icon {\n  color: #616e7e;\n}\n\nion-menu.md ion-item ion-label {\n  font-weight: 500;\n}\n\nion-menu.ios ion-content {\n  --padding-bottom: 20px;\n}\n\nion-menu.ios ion-list {\n  padding: 20px 0 0 0;\n}\n\nion-menu.ios ion-note {\n  line-height: 24px;\n  margin-bottom: 20px;\n}\n\nion-menu.ios ion-item {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --min-height: 50px;\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #73849a;\n}\n\nion-menu.ios ion-list#labels-list ion-list-header {\n  margin-bottom: 8px;\n}\n\nion-menu.ios ion-list-header,\nion-menu.ios ion-note {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\nion-menu.ios ion-note {\n  margin-bottom: 8px;\n}\n\nion-note {\n  display: inline-block;\n  font-size: 16px;\n  color: var(--ion-color-light-shade);\n}\n\nion-item.selected {\n  --color: var(--ion-color-light);\n}\n\n#inbox-list {\n  background: transparent;\n  border: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDJFQUFBO0FBQ0Y7O0FBRUE7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7QUFDRjs7QUFFQTs7RUFFRSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsMkRBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUVBLGdCQUFBO0FBQUY7O0FBR0E7RUFDRSxlQUFBO0VBRUEsbUJBQUE7RUFFQSxjQUFBO0VBRUEsZ0JBQUE7QUFIRjs7QUFNQTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUhGOztBQU1BO0VBQ0UsMENBQUE7RUFDQSxjQUFBO0FBSEY7O0FBT0E7RUFDRSwrREFBQTtBQUpGOztBQVdBO0VBQ0UsY0FBQTtBQVJGOztBQVdBO0VBQ0UsZ0JBQUE7QUFSRjs7QUFXQTtFQUNFLHNCQUFBO0FBUkY7O0FBV0E7RUFDRSxtQkFBQTtBQVJGOztBQVdBO0VBQ0UsaUJBQUE7RUFDQSxtQkFBQTtBQVJGOztBQVdBO0VBQ0UscUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBUkY7O0FBZUE7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQVpGOztBQWVBO0VBQ0Usa0JBQUE7QUFaRjs7QUFlQTs7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBWkY7O0FBZUE7RUFDRSxrQkFBQTtBQVpGOztBQWVBO0VBQ0UscUJBQUE7RUFDQSxlQUFBO0VBRUEsbUNBQUE7QUFiRjs7QUFnQkE7RUFDRSwrQkFBQTtBQWJGOztBQWdCQTtFQUNFLHVCQUFBO0VBQ0EsWUFBQTtBQWJGIiwiZmlsZSI6ImFwcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1tZW51IGlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24taXRlbS1iYWNrZ3JvdW5kLCB2YXIoLS1pb24tYmFja2dyb3VuZC1jb2xvciwgI2ZmZikpO1xufVxuXG5pb24tbWVudS5tZCBpb24tY29udGVudCB7XG4gIC0tcGFkZGluZy1zdGFydDogOHB4O1xuICAtLXBhZGRpbmctZW5kOiA4cHg7XG4gIC0tcGFkZGluZy10b3A6IDIwcHg7XG4gIC0tcGFkZGluZy1ib3R0b206IDIwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0IHtcbiAgcGFkZGluZzogMjBweCAwO1xufVxuXG5pb24tbWVudS5tZCBpb24tbm90ZSB7XG4gIG1hcmdpbi1ib3R0b206IDMwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0LWhlYWRlcixcbmlvbi1tZW51Lm1kIGlvbi1ub3RlIHtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdCNpbmJveC1saXN0IHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zdGVwLTE1MCwgI2Q3ZDhkYSk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0I2luYm94LWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgZm9udC1zaXplOiAyMnB4O1xuICBmb250LXdlaWdodDogNjAwO1xuXG4gIG1pbi1oZWlnaHQ6IDIwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0I2xhYmVscy1saXN0IGlvbi1saXN0LWhlYWRlciB7XG4gIGZvbnQtc2l6ZTogMTZweDtcblxuICBtYXJnaW4tYm90dG9tOiAxOHB4O1xuXG4gIGNvbG9yOiAjNzU3NTc1O1xuXG4gIG1pbi1oZWlnaHQ6IDI2cHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xuICAtLXBhZGRpbmctZW5kOiAxMHB4O1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG59XG5cbi5wcmltYXJ5IHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1yZ2IpO1xuICAtLWNvbG9yOiB3aGl0ZTtcbn1cblxuLy8gaW9uLW1lbnUubWRcbmlvbi1pdGVtLnNlbGVjdGVkIHtcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKHZhcigtLWlvbi1jb2xvci1saWdodC1yZ2IpLCAwLjI1KSAhaW1wb3J0YW50O1xufVxuXG4vLyBpb24tbWVudS5tZCBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XG4vLyAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4vLyB9XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1pY29uIHtcbiAgY29sb3I6ICM2MTZlN2U7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1sYWJlbCB7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tY29udGVudCB7XG4gIC0tcGFkZGluZy1ib3R0b206IDIwcHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdCB7XG4gIHBhZGRpbmc6IDIwcHggMCAwIDA7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWl0ZW0ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDE2cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDE2cHg7XG4gIC0tbWluLWhlaWdodDogNTBweDtcbn1cblxuLy8gaW9uLW1lbnUuaW9zIGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1pY29uIHtcbi8vICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbi8vIH1cblxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyNHB4O1xuICBjb2xvcjogIzczODQ5YTtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1saXN0I2xhYmVscy1saXN0IGlvbi1saXN0LWhlYWRlciB7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1saXN0LWhlYWRlcixcbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIHBhZGRpbmctbGVmdDogMTZweDtcbiAgcGFkZGluZy1yaWdodDogMTZweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1ub3RlIHtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xufVxuXG5pb24tbm90ZSB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgZm9udC1zaXplOiAxNnB4O1xuXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUpO1xufVxuXG5pb24taXRlbS5zZWxlY3RlZCB7XG4gIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XG59XG5cbiNpbmJveC1saXN0IHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIGJvcmRlcjogbm9uZTtcbn1cbiJdfQ== */";

/***/ }),

/***/ 96098:
/*!*********************************************************!*\
  !*** ./src/app/pages/medico-form/medico-form.page.scss ***!
  \*********************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtZWRpY28tZm9ybS5wYWdlLnNjc3MifQ== */";

/***/ }),

/***/ 62601:
/*!***************************************************************************!*\
  !*** ./src/app/pages/shared/modal-clinicas/modal-clinicas.component.scss ***!
  \***************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtb2RhbC1jbGluaWNhcy5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 16829:
/*!*****************************************************************************************************!*\
  !*** ./src/app/pages/shared/modal-confirme-notification/modal-confirme-notification.component.scss ***!
  \*****************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtb2RhbC1jb25maXJtZS1ub3RpZmljYXRpb24uY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 50590:
/*!********************************************************************!*\
  !*** ./src/app/pages/shared/modal-medicos/modal-medicos.page.scss ***!
  \********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtb2RhbC1tZWRpY29zLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 84573:
/*!********************************************************************!*\
  !*** ./src/app/pages/shared/modal-motoboy/modal-motoboy.page.scss ***!
  \********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtb2RhbC1tb3RvYm95LnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 65516:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/shared/modal-signature/modal-signature.component.scss ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtb2RhbC1zaWduYXR1cmUuY29tcG9uZW50LnNjc3MifQ== */";

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(14431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map