"use strict";
(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["src_app_pages_entrega-report_entrega-report_module_ts"],{

/***/ 24453:
/*!***********************************************************************!*\
  !*** ./src/app/pages/entrega-report/entrega-report-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EntregaReportPageRoutingModule": () => (/* binding */ EntregaReportPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _entrega_report_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./entrega-report.page */ 72569);




const routes = [
    {
        path: '',
        component: _entrega_report_page__WEBPACK_IMPORTED_MODULE_0__.EntregaReportPage
    }
];
let EntregaReportPageRoutingModule = class EntregaReportPageRoutingModule {
};
EntregaReportPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], EntregaReportPageRoutingModule);



/***/ }),

/***/ 62182:
/*!***************************************************************!*\
  !*** ./src/app/pages/entrega-report/entrega-report.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EntregaReportPageModule": () => (/* binding */ EntregaReportPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _entrega_report_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./entrega-report-routing.module */ 24453);
/* harmony import */ var _entrega_report_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./entrega-report.page */ 72569);







let EntregaReportPageModule = class EntregaReportPageModule {
};
EntregaReportPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _entrega_report_routing_module__WEBPACK_IMPORTED_MODULE_0__.EntregaReportPageRoutingModule
        ],
        declarations: [_entrega_report_page__WEBPACK_IMPORTED_MODULE_1__.EntregaReportPage]
    })
], EntregaReportPageModule);



/***/ }),

/***/ 72569:
/*!*************************************************************!*\
  !*** ./src/app/pages/entrega-report/entrega-report.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EntregaReportPage": () => (/* binding */ EntregaReportPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_entrega_report_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./entrega-report.page.html */ 98642);
/* harmony import */ var _entrega_report_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./entrega-report.page.scss */ 78589);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 37556);
/* harmony import */ var src_app_services_entrega_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/entrega.service */ 96932);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/message.service */ 42684);







let EntregaReportPage = class EntregaReportPage {
    constructor(
    // private storage: Storage,
    authService, service, message) {
        this.authService = authService;
        this.service = service;
        this.message = message;
        this.reporte = [];
        this.user = {};
        this.filters = { tipo: '2', status: 10, data_ini: this.getTEmp(), data_fim: this.getTEmp(1) };
        this.total = 0;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const session = yield this.authService.getSession();
            console.log(session);
            this.user = session.user;
            this.filters.portador_id = this.user.uuid;
            // this.getReport();
        });
    }
    getReport() {
        this.message.load_present();
        this.service.getReporte(this.filters).then((res) => {
            this.reporte = res;
            this.getTotal();
        }).finally(() => this.message.load_dismiss());
    }
    getTEmp(type = 0) {
        let date = new Date();
        if (type == 0) {
            return new Date(date.getFullYear(), date.getMonth(), 1);
        }
        return new Date(date.getFullYear(), date.getMonth() + 1, 0);
    }
    getTotal() {
        let total = 0;
        this.reporte.forEach(rep => {
            total += parseFloat(rep.taxa_entrega);
        });
        this.total = total;
    }
};
EntregaReportPage.ctorParameters = () => [
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: src_app_services_entrega_service__WEBPACK_IMPORTED_MODULE_3__.EntregaService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__.MessageService }
];
EntregaReportPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-entrega-report',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_entrega_report_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_entrega_report_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], EntregaReportPage);



/***/ }),

/***/ 98642:
/*!******************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/entrega-report/entrega-report.page.html ***!
  \******************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n\n    <ion-buttons slot=\"start\">\n      <!-- <ion-back-button></ion-back-button> -->\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n\n    <ion-title>Relatório de entregas</ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-row class=\"ion-margin-top\">\n\n    <ion-col size=\"6\">\n\n      <ion-item>\n        <ion-label position=\"floating\">Tipo:</ion-label>\n        <ion-select [(ngModel)]=\"filters.tipo\" value=\"1\" okText=\"ok\" cancelText=\"voltar\" mode=\"ios\">\n          <ion-select-option value=\"1\">Diário</ion-select-option>\n          <ion-select-option value=\"2\">Período</ion-select-option>\n          <!-- <ion-select-option value=\"3\">Anual</ion-select-option> -->\n        </ion-select>\n      </ion-item>\n\n    </ion-col>\n\n    <!-- <ion-col size=\"6\">\n\n      <ion-item>\n        <ion-label position=\"floating\">status:</ion-label>\n        <ion-select [(ngModel)]=\"filters.status\" value=\"10\" okText=\"ok\" cancelText=\"voltar\" mode=\"ios\">\n          <ion-select-option value=\"1\">Pendentes</ion-select-option>\n          <ion-select-option value=\"10\">Entregues</ion-select-option>\n        </ion-select>\n      </ion-item>\n\n    </ion-col> -->\n\n    <ion-col size=\"6\">\n\n      <ion-item>\n        <ion-label position=\"stacked\">{{filters.tipo == 1 ? 'Data' : 'Data inicial'}}:</ion-label>\n        <ion-input [type]=\"filters.tipo != 3 ? 'date' : 'number'\" [(ngModel)]=\"filters.data_ini\"></ion-input>\n      </ion-item>\n\n    </ion-col>\n\n    <ion-col size=\"6\" *ngIf=\"filters.tipo == 2\">\n\n      <ion-item>\n        <ion-label position=\"stacked\">'Data final:</ion-label>\n        <ion-input type=\"date\" [(ngModel)]=\"filters.data_fim\"></ion-input>\n      </ion-item>\n\n    </ion-col>\n\n    <ion-col size=\"12\" class=\"ion-margin-top\">\n\n      <ion-button expand=\"block\" shape=\"round\" color=\"tertiary\" (click)=\"getReport()\">Filtrar</ion-button>\n\n    </ion-col>\n\n  </ion-row>\n\n\n  <ion-row class=\"ion-margin-top\">\n\n    <ion-col size=\"12\">\n\n      Quantidade: <strong>{{reporte.length}}</strong>\n\n    </ion-col>\n\n    <ion-col size=\"12\">\n\n      Total de Entregas: <strong>{{total | currency: 'R$'}}</strong>\n\n    </ion-col>\n\n  </ion-row>\n\n\n</ion-content>\n");

/***/ }),

/***/ 78589:
/*!***************************************************************!*\
  !*** ./src/app/pages/entrega-report/entrega-report.page.scss ***!
  \***************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlbnRyZWdhLXJlcG9ydC5wYWdlLnNjc3MifQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_entrega-report_entrega-report_module_ts.js.map