"use strict";
(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["src_app_pages_coletas-check-detail_coletas-check-detail_module_ts"],{

/***/ 56676:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/coletas-check-detail/coletas-check-detail-routing.module.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetasCheckDetailPageRoutingModule": () => (/* binding */ ColetasCheckDetailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _coletas_check_detail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./coletas-check-detail.page */ 10823);




const routes = [
    {
        path: '',
        component: _coletas_check_detail_page__WEBPACK_IMPORTED_MODULE_0__.ColetasCheckDetailPage
    }
];
let ColetasCheckDetailPageRoutingModule = class ColetasCheckDetailPageRoutingModule {
};
ColetasCheckDetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ColetasCheckDetailPageRoutingModule);



/***/ }),

/***/ 35241:
/*!***************************************************************************!*\
  !*** ./src/app/pages/coletas-check-detail/coletas-check-detail.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetasCheckDetailPageModule": () => (/* binding */ ColetasCheckDetailPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _coletas_check_detail_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./coletas-check-detail-routing.module */ 56676);
/* harmony import */ var _coletas_check_detail_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./coletas-check-detail.page */ 10823);
/* harmony import */ var _coletas_check_item_coletas_check_item_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../coletas-check-item/coletas-check-item.module */ 46023);








let ColetasCheckDetailPageModule = class ColetasCheckDetailPageModule {
};
ColetasCheckDetailPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _coletas_check_detail_routing_module__WEBPACK_IMPORTED_MODULE_0__.ColetasCheckDetailPageRoutingModule,
            _coletas_check_item_coletas_check_item_module__WEBPACK_IMPORTED_MODULE_2__.ColetasCheckItemPageModule
        ],
        declarations: [_coletas_check_detail_page__WEBPACK_IMPORTED_MODULE_1__.ColetasCheckDetailPage]
    })
], ColetasCheckDetailPageModule);



/***/ }),

/***/ 10823:
/*!*************************************************************************!*\
  !*** ./src/app/pages/coletas-check-detail/coletas-check-detail.page.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetasCheckDetailPage": () => (/* binding */ ColetasCheckDetailPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_coletas_check_detail_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./coletas-check-detail.page.html */ 81478);
/* harmony import */ var _coletas_check_detail_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./coletas-check-detail.page.scss */ 99385);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage-angular */ 54357);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/message.service */ 42684);
/* harmony import */ var src_app_services_motoboy_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/motoboy.service */ 3756);
/* harmony import */ var _coletas_check_item_coletas_check_item_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../coletas-check-item/coletas-check-item.page */ 46612);










let ColetasCheckDetailPage = class ColetasCheckDetailPage {
    constructor(storage, navCtrl, modalCtrl, alertCtrl, routerActive, service, message) {
        this.storage = storage;
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.alertCtrl = alertCtrl;
        this.routerActive = routerActive;
        this.service = service;
        this.message = message;
        this.coleta = { clinica: {}, medicos: [], warning: { itens: [] } };
        this.storage.create();
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            this.routerActive.params
                .subscribe((params) => {
                console.log(params);
                if (params.coleta_id) {
                    this.getDados(params.coleta_id);
                }
            })
                .unsubscribe();
            // this.auditor = await this.storage.get('nameAuditor');
            this.auditor = sessionStorage.getItem('nameAuditor');
        });
    }
    getNomeAuditor() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                // header: 'Prompt!',
                message: 'Informe seu nome.',
                backdropDismiss: false,
                mode: 'ios',
                inputs: [
                    {
                        name: 'nome',
                        type: 'text',
                        // placeholder: 'Informe o código do QR Code.'
                    },
                ],
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary',
                        handler: () => {
                            this.navCtrl.pop();
                        },
                    },
                    {
                        text: 'Confirmar',
                        handler: (data) => {
                            if (data.nome == '') {
                                this.getNomeAuditor();
                                return this.message.toastError('Informe o código...');
                            }
                            // this.coleta.auditor = data.nome;
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
    getDados(uuid) {
        this.message.load_present();
        this.service
            .getColeta(uuid)
            .then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            this.coleta = res;
            if (this.coleta.status != 10) {
                // this.getNomeAuditor();
                this.coleta.medicos.forEach((medico) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                    medico.itens.forEach((item) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                        item.auditor = this.auditor;
                    }));
                }));
                // this.coleta.auditor = await this.storage.get('nameAuditor')
            }
            console.log(this.coleta);
        }))
            .finally(() => this.message.load_dismiss());
    }
    openItens(item = undefined) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _coletas_check_item_coletas_check_item_page__WEBPACK_IMPORTED_MODULE_4__.ColetasCheckItemPage,
                componentProps: {
                    data: item,
                    auditor: this.coleta.auditor,
                },
            });
            yield modal.present();
            modal.onDidDismiss().then((res) => {
                if (res.data) {
                    this.getDados(this.coleta.uuid);
                }
            });
        });
    }
    getItensTotal() {
        let total = 0;
        this.coleta.medicos.forEach((medico) => {
            if (medico.itens) {
                total += medico.itens.length;
            }
        });
        return total;
    }
    checkOccurrence() {
        let find = false;
        for (let medico of this.coleta.medicos) {
            for (let item of medico.itens) {
                if (item.status == 5) {
                    find = true;
                }
            }
        }
        return find;
    }
    checkSuccess() {
        let find = true;
        for (let medico of this.coleta.medicos) {
            for (let item of medico.itens) {
                // if (item.status == 5 || item.status == 1) {
                if (item.status == 5) {
                    find = false;
                }
            }
        }
        return find;
    }
    setColetaSuccess() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                mode: 'ios',
                header: 'Atenção!',
                message: 'Tudo certo com esta coleta ?',
                buttons: [
                    {
                        text: 'Não',
                        cssClass: 'secondary',
                    },
                    {
                        text: 'Sim',
                        handler: () => {
                            this.updateColetaStatus({ status: 10, auditor: this.auditor });
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
    setColetaOccurrence() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                mode: 'ios',
                header: 'Atenção!',
                message: 'Gerar ocorrência para esta coleta ?',
                buttons: [
                    {
                        text: 'Não',
                        cssClass: 'secondary',
                    },
                    {
                        text: 'Sim',
                        handler: () => {
                            this.updateColetaStatus({ status: 5, auditor: this.auditor });
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
    updateColetaStatus(dados) {
        this.message.load_present();
        this.service
            .updateColeta(this.coleta.uuid, dados)
            .then((res) => {
            // this.getDados(this.coleta.uuid);
            this.navCtrl.pop();
        })
            .finally(() => this.message.load_dismiss());
    }
};
ColetasCheckDetailPage.ctorParameters = () => [
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_6__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute },
    { type: src_app_services_motoboy_service__WEBPACK_IMPORTED_MODULE_3__.MotoboyService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_2__.MessageService }
];
ColetasCheckDetailPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-coletas-check-detail',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_coletas_check_detail_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_coletas_check_detail_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ColetasCheckDetailPage);



/***/ }),

/***/ 78206:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/coletas-check-item/coletas-check-item-routing.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetasCheckItemPageRoutingModule": () => (/* binding */ ColetasCheckItemPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _coletas_check_item_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./coletas-check-item.page */ 46612);




const routes = [
    {
        path: '',
        component: _coletas_check_item_page__WEBPACK_IMPORTED_MODULE_0__.ColetasCheckItemPage
    }
];
let ColetasCheckItemPageRoutingModule = class ColetasCheckItemPageRoutingModule {
};
ColetasCheckItemPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ColetasCheckItemPageRoutingModule);



/***/ }),

/***/ 46023:
/*!***********************************************************************!*\
  !*** ./src/app/pages/coletas-check-item/coletas-check-item.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetasCheckItemPageModule": () => (/* binding */ ColetasCheckItemPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _coletas_check_item_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./coletas-check-item-routing.module */ 78206);
/* harmony import */ var _coletas_check_item_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./coletas-check-item.page */ 46612);







let ColetasCheckItemPageModule = class ColetasCheckItemPageModule {
};
ColetasCheckItemPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _coletas_check_item_routing_module__WEBPACK_IMPORTED_MODULE_0__.ColetasCheckItemPageRoutingModule
        ],
        declarations: [_coletas_check_item_page__WEBPACK_IMPORTED_MODULE_1__.ColetasCheckItemPage]
    })
], ColetasCheckItemPageModule);



/***/ }),

/***/ 46612:
/*!*********************************************************************!*\
  !*** ./src/app/pages/coletas-check-item/coletas-check-item.page.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetasCheckItemPage": () => (/* binding */ ColetasCheckItemPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_coletas_check_item_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./coletas-check-item.page.html */ 58666);
/* harmony import */ var _coletas_check_item_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./coletas-check-item.page.scss */ 13090);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/message.service */ 42684);
/* harmony import */ var src_app_services_motoboy_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/motoboy.service */ 3756);







let ColetasCheckItemPage = class ColetasCheckItemPage {
    constructor(ref, modalCtrl, alertCtrl, service, message) {
        this.ref = ref;
        this.modalCtrl = modalCtrl;
        this.alertCtrl = alertCtrl;
        this.service = service;
        this.message = message;
        this.dados = { itens: [] };
        this.changes = undefined;
    }
    ngOnInit() {
        console.log(this.data);
        if (this.data) {
            this.dados = this.data;
        }
    }
    close(params) {
        this.modalCtrl.dismiss(params);
    }
    checkSuccess(item, index) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                mode: 'ios',
                header: 'Atenção!',
                message: 'Tudo certo com este item ?',
                buttons: [
                    {
                        text: 'Não',
                        cssClass: 'secondary'
                    }, {
                        text: 'Sim',
                        handler: () => {
                            this.updateItem(item, index, { status: 10, auditor: this.auditor });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    updateItem(item, index, dados) {
        this.message.load_present();
        this.service.updateItem(item.uuid, dados).then(res => {
            console.log('item', res);
            this.dados.itens[index] = res;
            // this.ref.detectChanges();
            this.changes = true;
        }).finally(() => this.message.load_dismiss());
    }
    genOcorrencia(item, index) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-alert-full',
                mode: 'ios',
                header: 'Ocorrência',
                inputs: [
                    {
                        name: 'description',
                        type: 'textarea',
                        attributes: {
                            rows: 5
                        },
                        placeholder: 'Informe a ocorrência.'
                    }
                ],
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary'
                    }, {
                        text: 'Confirme',
                        handler: (data) => {
                            if (data.description == "") {
                                return this.message.toastError('Informe a ocorrência');
                            }
                            this.updateItem(item, index, { status: 5, description: data.description });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
ColetasCheckItemPage.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ChangeDetectorRef },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: src_app_services_motoboy_service__WEBPACK_IMPORTED_MODULE_3__.MotoboyService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_2__.MessageService }
];
ColetasCheckItemPage.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input }],
    auditor: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input }]
};
ColetasCheckItemPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-coletas-check-item',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_coletas_check_item_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_coletas_check_item_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ColetasCheckItemPage);



/***/ }),

/***/ 81478:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coletas-check-detail/coletas-check-detail.page.html ***!
  \******************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n\n    <ion-title>Coleta: {{coleta.code_qr}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-card class=\"ion-margin-top\" mode=\"ios\">\n\n    <ion-item lines=\"none\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2>{{coleta.clinica.description}}</h2>\n        <p>\n          Endereço: {{coleta.clinica.logradouro}}, {{coleta.clinica.numero}}, {{coleta.clinica.complemento}},\n          {{coleta.clinica.bairro}}, {{coleta.clinica.cidade}}\n        </p>\n        <!-- <span>\n          Status:\n          <ion-badge color=\"medium\" *ngIf=\"coleta.status == 1\">Pendente</ion-badge>\n          <ion-badge color=\"warning\" *ngIf=\"coleta.status == 5\">Ocorrência</ion-badge>\n          <ion-badge color=\"success\" *ngIf=\"coleta.status == 10\">Verificado</ion-badge>\n        </span> -->\n      </ion-label>\n    </ion-item>\n\n  </ion-card>\n\n  <ion-list>\n    <ion-list-header color=\"primary\">\n      <ion-label>Médicos da Coleta</ion-label>\n    </ion-list-header>\n\n    <!-- <ion-item *ngFor=\"let medico of coleta.medicos\" button lines=\"full\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2>{{medico.nome}}</h2>\n        <p>\n          Itens Coletados: {{medico.itens.length}}\n        </p>\n      </ion-label>\n    </ion-item> -->\n\n  </ion-list>\n\n  <ion-card *ngFor=\"let medico of coleta.medicos\" mode=\"ios\" (click)=\"openItens(medico)\">\n    <ion-item lines=\"none\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2>{{medico.nome}}</h2>\n        <p>\n          Itens Coletados: {{medico.itens.length}}\n        </p>\n      </ion-label>\n    </ion-item>\n  </ion-card>\n\n  <ion-card *ngIf=\"coleta.warning\" mode=\"ios\" (click)=\"openItens(coleta.warning)\">\n    <ion-item lines=\"none\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2>Ocorrências</h2>\n        <p>\n          Itens Coletados: {{coleta.warning.itens.length}}\n        </p>\n      </ion-label>\n    </ion-item>\n  </ion-card>\n\n  <div align=\"center\">\n    Total de itens coletados: {{getItensTotal()}}\n  </div>\n\n  <div class=\"ion-padding\">\n\n    <ion-button expand=\"block\" shape=\"round\" color=\"success\" (click)=\"setColetaSuccess()\"\n      *ngIf=\"coleta.status == 2 || coleta.status == 5\">\n      <ion-icon name=\"checkmark-circle-outline\" slot=\"start\"></ion-icon>\n      Verificar\n    </ion-button>\n\n    <ion-button expand=\"block\" shape=\"round\" color=\"warning\" (click)=\"setColetaOccurrence()\"\n      *ngIf=\"checkOccurrence() && coleta.status == 2\">\n      <ion-icon name=\"alert-circle-outline\" slot=\"start\"></ion-icon>\n      Gerar Ocorrência\n    </ion-button>\n\n    <div align=\"center\" class=\"ion-margin-top\">\n      <ion-badge color=\"medium\" *ngIf=\"coleta.status == 2\">Não verificado</ion-badge>\n      <ion-badge color=\"warning\" *ngIf=\"coleta.status == 5\">Com ocorrência</ion-badge>\n      <ion-badge color=\"success\" *ngIf=\"coleta.status == 10\">Verificado</ion-badge>\n    </div>\n\n  </div>\n</ion-content>\n");

/***/ }),

/***/ 58666:
/*!**************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coletas-check-item/coletas-check-item.page.html ***!
  \**************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"close(changes)\">\n        <ion-icon name=\"arrow-back-outline\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-title>Itens Coletados</ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-card class=\"ion-margin-top\" mode=\"ios\">\n\n    <ion-item lines=\"none\">\n      <ion-label class=\"ion-text-wrap\" *ngIf=\"dados.nome\">\n        <p>Médico:</p>\n        <h2>{{dados.nome}}</h2>\n      </ion-label>\n      <ion-label class=\"ion-text-wrap\" *ngIf=\"!dados.nome\">\n        <h2>Ocorrências</h2>\n      </ion-label>\n    </ion-item>\n\n  </ion-card>\n\n  <ion-card class=\"ion-margin-top\" *ngFor=\"let item of dados.itens; let i = index\" mode=\"ios\">\n    <img [src]=\"item.foto\">\n    <ion-card-header *ngIf=\"item.tipo_exame\">\n      <ion-card-subtitle>Tipo: {{ item.tipo_exame.nome | titlecase }}</ion-card-subtitle>\n\n      <ion-badge color=\"medium\" *ngIf=\"item.status == 1\">Pendente</ion-badge>\n      <ion-badge color=\"warning\" *ngIf=\"item.status == 5\">Ocorrência</ion-badge>\n      <ion-badge color=\"success\" *ngIf=\"item.status == 10\">Verificado</ion-badge>\n\n      <p><strong>Ocorrência:</strong> {{item.description}}</p>\n\n    </ion-card-header>\n\n    <ion-row *ngIf=\"item.status != 10\">\n      <ion-col>\n        <ion-button color=\"success\" expand=\"block\" (click)=\"checkSuccess(item, i)\">\n          <ion-icon slot=\"icon-only\" name=\"checkmark-circle-outline\"></ion-icon>\n        </ion-button>\n      </ion-col>\n      <ion-col *ngIf=\"item.status == 1\">\n        <ion-button color=\"warning\" expand=\"block\" (click)=\"genOcorrencia(item, i)\">\n          <ion-icon slot=\"icon-only\" name=\"alert-circle-outline\"></ion-icon>\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-card>\n\n</ion-content>\n");

/***/ }),

/***/ 99385:
/*!***************************************************************************!*\
  !*** ./src/app/pages/coletas-check-detail/coletas-check-detail.page.scss ***!
  \***************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjb2xldGFzLWNoZWNrLWRldGFpbC5wYWdlLnNjc3MifQ== */";

/***/ }),

/***/ 13090:
/*!***********************************************************************!*\
  !*** ./src/app/pages/coletas-check-item/coletas-check-item.page.scss ***!
  \***********************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjb2xldGFzLWNoZWNrLWl0ZW0ucGFnZS5zY3NzIn0= */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_coletas-check-detail_coletas-check-detail_module_ts.js.map