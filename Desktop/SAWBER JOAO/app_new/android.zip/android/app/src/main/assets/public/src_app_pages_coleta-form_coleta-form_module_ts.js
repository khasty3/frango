"use strict";
(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["src_app_pages_coleta-form_coleta-form_module_ts"],{

/***/ 57639:
/*!*****************************************************************!*\
  !*** ./src/app/pages/coleta-form/coleta-form-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetaFormPageRoutingModule": () => (/* binding */ ColetaFormPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _coleta_form_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./coleta-form.page */ 63994);




const routes = [
    {
        path: '',
        component: _coleta_form_page__WEBPACK_IMPORTED_MODULE_0__.ColetaFormPage
    }
];
let ColetaFormPageRoutingModule = class ColetaFormPageRoutingModule {
};
ColetaFormPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ColetaFormPageRoutingModule);



/***/ }),

/***/ 93762:
/*!*********************************************************!*\
  !*** ./src/app/pages/coleta-form/coleta-form.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetaFormPageModule": () => (/* binding */ ColetaFormPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _coleta_form_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./coleta-form-routing.module */ 57639);
/* harmony import */ var _coleta_form_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./coleta-form.page */ 63994);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/shared.module */ 40950);








let ColetaFormPageModule = class ColetaFormPageModule {
};
ColetaFormPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _coleta_form_routing_module__WEBPACK_IMPORTED_MODULE_0__.ColetaFormPageRoutingModule,
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule
        ],
        declarations: [_coleta_form_page__WEBPACK_IMPORTED_MODULE_1__.ColetaFormPage]
    })
], ColetaFormPageModule);



/***/ }),

/***/ 63994:
/*!*******************************************************!*\
  !*** ./src/app/pages/coleta-form/coleta-form.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetaFormPage": () => (/* binding */ ColetaFormPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_coleta_form_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./coleta-form.page.html */ 45459);
/* harmony import */ var _coleta_form_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./coleta-form.page.scss */ 14841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/background-mode/ngx */ 25998);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/storage */ 54357);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/auth.service */ 37556);
/* harmony import */ var src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/coleta.service */ 35738);
/* harmony import */ var src_app_services_medico_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/medico.service */ 74633);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/message.service */ 42684);
/* harmony import */ var _coleta_medico_form_coleta_medico_form_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../coleta-medico-form/coleta-medico-form.page */ 31762);
/* harmony import */ var _shared_modal_medicos_modal_medicos_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../shared/modal-medicos/modal-medicos.page */ 80428);














let ColetaFormPage = class ColetaFormPage {
    constructor(navCtrl, routerActive, alertCtrl, modalCtrl, storage, medicoService, authService, service, message, backgroundMode) {
        this.navCtrl = navCtrl;
        this.routerActive = routerActive;
        this.alertCtrl = alertCtrl;
        this.modalCtrl = modalCtrl;
        this.storage = storage;
        this.medicoService = medicoService;
        this.authService = authService;
        this.service = service;
        this.message = message;
        this.backgroundMode = backgroundMode;
        this.clinica = {};
        this.dados = { clinica: {}, medicos: [], warning: { itens: [] } };
        this.solicitacao = {};
        this.user = {};
        this.storage.create();
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            // this.backgroundMode.enable();
            // this.backgroundMode.on("activate").subscribe(() => {
            //   this.backgroundMode.disableWebViewOptimizations();
            //   this.backgroundMode.disableBatteryOptimizations();
            //   console.log("background activate !!!!");
            // });
            // setTimeout(() => {
            //   this.backgroundMode.disable();
            // }, 5000);
            const session = yield this.authService.getSession();
            this.user = session.user;
            this.dados.portador_id = this.user.uuid;
            this.routerActive.params.subscribe(params => {
                console.log(params);
                if (params.coleta_id) {
                    this.getColeta(params.coleta_id);
                }
            }).unsubscribe();
            this.routerActive.queryParams.subscribe(res => {
                if (res.solicitacao_id) {
                    this.getDadosSolicitacao(res.solicitacao_id);
                }
            }).unsubscribe();
        });
    }
    getColeta(id) {
        this.message.load_present();
        this.service.getColeta(id).then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            this.dados = res.data;
            yield this.getDadosClinica(this.dados.clinica_id);
            // this.getColetaTempStorage(this.dados.code_qr);
        })).finally(() => this.message.load_dismiss());
    }
    getDadosClinica(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            yield this.service.getClinica(id).then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
                this.clinica = res;
            }));
        });
    }
    getDadosSolicitacao(id) {
        this.service.getSolicitacao(id).then(res => {
            this.solicitacao = res;
            this.dados.solicitacao_id = res.uuid;
        });
    }
    // getColetaTempStorage(code_qr) {
    //   console.log('getColetaTempStorage');
    //   let coletasTempList: any[] = [];
    //   this.storage.get(environment.coletasTemp).then((coletasTemp: any[]) => {
    //     if (coletasTemp) {//se existir recebe os dados
    //       coletasTempList = coletasTemp;
    //     }
    //     let findIndexColeta = coletasTempList.findIndex(coleta => coleta.code_qr == code_qr);
    //     if (findIndexColeta >= 0) {
    //       this.dados = coletasTempList[findIndexColeta];
    //     } else {
    //       coletasTempList.push(this.dados);
    //       this.storage.set(environment.coletasTemp, coletasTempList);
    //     }
    //   });
    // }
    // updateColetaTempStorage(code_qr) {
    //   console.log('updateColetaTempStorage');
    //   let coletasTempList: any[] = [];
    //   this.storage.get(environment.coletasTemp).then((coletasTemp: any[]) => {
    //     if (coletasTemp) {//se existir recebe os dados
    //       coletasTempList = coletasTemp;
    //     }
    //     let findIndexColeta = coletasTempList.findIndex(coleta => coleta.code_qr == code_qr);
    //     if (findIndexColeta >= 0) {
    //       coletasTempList[findIndexColeta] = this.dados;
    //     } else {
    //       coletasTempList.push(this.dados);
    //     }
    //     this.storage.set(environment.coletasTemp, coletasTempList);
    //   });
    // }
    usedMedical(medico) {
        let show = true;
        for (let item of this.dados.medicos) {
            if (item.uuid == medico.uuid) {
                show = false;
            }
        }
        return show;
    }
    openColeta(item = undefined, i = undefined) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _coleta_medico_form_coleta_medico_form_page__WEBPACK_IMPORTED_MODULE_8__.ColetaMedicoFormPage,
                componentProps: {
                    'data': item,
                    'coleta_id': this.dados.uuid
                }
            });
            yield modal.present();
            modal.onDidDismiss().then(res => {
                console.log(res);
                if (res.data) {
                    this.getColeta(this.dados.uuid);
                    // if (item && item.uuid) {
                    //   if (i >= 0) {
                    //     this.dados.medicos[i] = res.data;
                    //   } else {
                    //     this.dados.medicos.push(res.data);
                    //   }
                    // } else {//ocorrências
                    //   if (i >= 0) {
                    //     this.dados.warning[i] = res.data;
                    //   } else {
                    //     this.dados.warning.push(res.data);
                    //   }
                    // }
                    // this.updateColetaTempStorage(this.dados.code_qr);
                }
            });
        });
    }
    saveColeta() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                header: 'Atenção!',
                mode: 'ios',
                message: `Finalizar visita ?`,
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary'
                    }, {
                        text: 'Confirmar',
                        handler: () => {
                            console.log('medicos', this.dados.medicos);
                            console.log('warning', this.dados.warning);
                            if (this.dados.medicos.length == 0 && this.dados.warning.itens.length == 0) {
                                return this.message.toastError('Sem itens coletados..');
                            }
                            this.sendColeta();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    sendColeta() {
        this.message.load_present();
        this.service.updateColeta({ status: 2 }, this.dados.uuid).then(() => {
            this.navCtrl.navigateRoot('/home');
        }).catch(err => {
            // this.storageColeta();
        }).finally(() => this.message.load_dismiss());
    }
    // async coletaEmpty() {
    //   const alert = await this.alertCtrl.create({
    //     cssClass: 'my-custom-class',
    //     header: 'Atenção!',
    //     mode: 'ios',
    //     message: `Visita sem coleta ?`,
    //     buttons: [
    //       {
    //         text: 'Voltar',
    //         cssClass: 'secondary'
    //       }, {
    //         text: 'Confirmar',
    //         handler: () => {
    //           this.dados.sem_coleta = 1;
    //           this.sendColeta();
    //         }
    //       }
    //     ]
    //   });
    //   await alert.present();
    // }
    storageColeta() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                header: 'Aviso!',
                mode: 'ios',
                message: 'Sua coleta foi armazenada no dispositivo por falta de internet... \n Será enviado quando a mesma for restaurada.',
                buttons: ['OK']
            });
            yield alert.present();
            this.storage.get('coletas').then(res => {
                if (res && res != null) { //temos coletas
                    let coletas = res;
                    coletas.push(this.dados);
                    this.setColetas(coletas);
                }
                else { //sem coletas
                    let coletas = [];
                    coletas.push(this.dados);
                    this.setColetas(coletas);
                }
            }).catch(err => {
                this.message.toastError('Falha ao verificar coletas no dispositivo.');
                console.log(err);
            });
        });
    }
    setColetas(coletas) {
        this.storage.set('coletas', coletas).then(() => {
            this.navCtrl.navigateRoot('/home');
        }).catch(err => {
            this.message.toastError('Falha ao salvar coleta no dispositivo.');
            console.log(err);
        });
    }
    confirmRemove(item, i) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            let message = `Deseja remover a coleta do médico: <b>${item.nome}</b> ?`;
            if (!item.nome) {
                message = `Deseja remover as ocorrências ?`;
            }
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                header: 'Atenção!',
                mode: 'ios',
                message: message,
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary'
                    }, {
                        text: 'Confirmar',
                        handler: () => {
                            this.dados.medicos.splice(i, 1);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    openMedicoSearch() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _shared_modal_medicos_modal_medicos_page__WEBPACK_IMPORTED_MODULE_9__.ModalMedicosPage
            });
            yield modal.present();
            modal.onDidDismiss().then(res => {
                // console.log(res);
                if (res.data) {
                    this.addMedicoConfirme(res.data);
                }
                else {
                    // this.getDadosClinica(this.clinica.uuid);
                }
            });
        });
    }
    addMedicoConfirme(item) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                header: 'Atenção!',
                mode: 'ios',
                message: `Adicionar o medico: <b>${item.nome}</b> a esta clinica/local ?`,
                buttons: [
                    {
                        text: 'Não',
                        cssClass: 'secondary'
                    }, {
                        text: 'Sim',
                        handler: () => {
                            this.addMedico(item.uuid);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    addMedico(medico_id) {
        const request = {
            medico_id: medico_id,
            clinica_id: this.clinica.uuid
        };
        this.message.load_present();
        this.medicoService.setMedicoClinica(request).then(res => {
            // this.getDadosClinica(this.clinica.uuid);
        }).finally(() => this.message.load_dismiss());
    }
};
ColetaFormPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.NavController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.ModalController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_3__.Storage },
    { type: src_app_services_medico_service__WEBPACK_IMPORTED_MODULE_6__.MedicoService },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_4__.AuthService },
    { type: src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_5__.ColetaService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_7__.MessageService },
    { type: _ionic_native_background_mode_ngx__WEBPACK_IMPORTED_MODULE_2__.BackgroundMode }
];
ColetaFormPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
        selector: 'app-coleta-form',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_coleta_form_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_coleta_form_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ColetaFormPage);



/***/ }),

/***/ 45459:
/*!************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coleta-form/coleta-form.page.html ***!
  \************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n\n    <ion-title>Coleta Nº: {{dados.code_qr}}</ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-card mode=\"ios\">\n    <ion-item lines=\"none\">\n      <ion-label class=\"ion-text-wrap\">\n        <strong>{{ clinica.description | titlecase }}</strong>\n        <p>{{clinica.logradouro}}, Nº {{clinica.numero}}, {{clinica.complemento}}, {{clinica.bairro}},\n          {{clinica.cidade}}</p>\n      </ion-label>\n    </ion-item>\n  </ion-card>\n\n  <ion-card mode=\"ios\" *ngIf=\"solicitacao.medico\">\n    <ion-item lines=\"none\">\n      <ion-label class=\"ion-text-wrap\">\n        <strong>Médico da solicitação:</strong>\n        <p>{{solicitacao.medico.nome}}</p>\n      </ion-label>\n    </ion-item>\n  </ion-card>\n\n  <ion-list>\n    <ion-list-header color=\"primary\">\n      <ion-label>Médicos</ion-label>\n      <!-- <ion-button color=\"dark\">Clear</ion-button> -->\n      <ion-button (click)=\"openMedicoSearch()\">\n        <ion-icon name=\"add-circle-outline\" color=\"light\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-list-header>\n\n    <div *ngFor=\"let medico of clinica.medicos\">\n      <ion-item lines=\"full\" (click)=\"openColeta(medico)\" *ngIf=\"usedMedical(medico)\">\n        <ion-label>\n          <h2>{{ medico.nome | titlecase }}</h2>\n          <p>CRM: {{medico.crm}}</p>\n        </ion-label>\n      </ion-item>\n    </div>\n  </ion-list>\n\n  <ion-list *ngIf=\"dados.medicos.length > 0\">\n    <ion-list-header color=\"primary\">\n      <ion-label>Coletas</ion-label>\n    </ion-list-header>\n\n    <ion-item lines=\"full\" *ngFor=\"let coleta of dados.medicos; let i = index\">\n      <ion-label (click)=\"openColeta(coleta, i)\">\n        <h2>{{ coleta.nome | titlecase }}</h2>\n        <p>CRM: {{coleta.crm}}</p>\n        <p>Itens Coletados: {{coleta.itens.length}}</p>\n      </ion-label>\n      <!-- <ion-button slot=\"end\" fill=\"clear\" (click)=\"confirmRemove(coleta, i)\">\n        <ion-icon name=\"trash\" color=\"danger\" slot=\"icon-only\"></ion-icon>\n      </ion-button> -->\n    </ion-item>\n  </ion-list>\n\n  <ion-list>\n    <ion-list-header color=\"primary\">\n      <ion-label>Ocorrências</ion-label>\n      <ion-button (click)=\"openColeta()\">\n        <ion-icon name=\"add-circle-outline\" color=\"light\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-list-header>\n\n    <ion-item lines=\"full\" *ngIf=\"dados.warning\">\n      <ion-label (click)=\"openColeta(dados.warning)\">\n        <h2>Itens com ocorrência</h2>\n        <p>Itens Coletados: {{dados.warning.itens.length}}</p>\n      </ion-label>\n    <!--<ion-button slot=\"end\" fill=\"clear\" (click)=\"confirmRemove(dados.warning)\">\n        <ion-icon name=\"trash\" color=\"danger\" slot=\"icon-only\"></ion-icon>\n      </ion-button> -->\n    </ion-item>\n  </ion-list>\n\n  <div class=\"ion-padding\">\n    <ion-button expand=\"block\" color=\"tertiary\" (click)=\"saveColeta()\">\n      Finalizar Coleta\n    </ion-button>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ 14841:
/*!*********************************************************!*\
  !*** ./src/app/pages/coleta-form/coleta-form.page.scss ***!
  \*********************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjb2xldGEtZm9ybS5wYWdlLnNjc3MifQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_coleta-form_coleta-form_module_ts.js.map