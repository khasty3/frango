"use strict";
(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["src_app_pages_entregas_entregas_module_ts"],{

/***/ 5837:
/*!***********************************************************!*\
  !*** ./src/app/pages/entregas/entregas-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EntregasPageRoutingModule": () => (/* binding */ EntregasPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _entregas_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./entregas.page */ 56252);




const routes = [
    {
        path: '',
        component: _entregas_page__WEBPACK_IMPORTED_MODULE_0__.EntregasPage
    }
];
let EntregasPageRoutingModule = class EntregasPageRoutingModule {
};
EntregasPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], EntregasPageRoutingModule);



/***/ }),

/***/ 57105:
/*!***************************************************!*\
  !*** ./src/app/pages/entregas/entregas.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EntregasPageModule": () => (/* binding */ EntregasPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _entregas_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./entregas-routing.module */ 5837);
/* harmony import */ var _entregas_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./entregas.page */ 56252);







let EntregasPageModule = class EntregasPageModule {
};
EntregasPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _entregas_routing_module__WEBPACK_IMPORTED_MODULE_0__.EntregasPageRoutingModule
        ],
        declarations: [_entregas_page__WEBPACK_IMPORTED_MODULE_1__.EntregasPage]
    })
], EntregasPageModule);



/***/ }),

/***/ 56252:
/*!*************************************************!*\
  !*** ./src/app/pages/entregas/entregas.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EntregasPage": () => (/* binding */ EntregasPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_entregas_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./entregas.page.html */ 74605);
/* harmony import */ var _entregas_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./entregas.page.scss */ 51731);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 54357);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 37556);
/* harmony import */ var src_app_services_entrega_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/entrega.service */ 96932);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/message.service */ 42684);









let EntregasPage = class EntregasPage {
    constructor(actionSheetCtrl, navCtrl, alertCtrl, modalCtrl, storage, authService, service, message) {
        this.actionSheetCtrl = actionSheetCtrl;
        this.navCtrl = navCtrl;
        this.alertCtrl = alertCtrl;
        this.modalCtrl = modalCtrl;
        this.storage = storage;
        this.authService = authService;
        this.service = service;
        this.message = message;
        this.user = {};
        this.entregas = [];
        this.code = '';
        this.storage.create();
    }
    ngOnInit() {
    }
    doRefresh(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            yield this.getListing();
            event.target.complete();
        });
    }
    ionViewWillEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const session = yield this.authService.getSession();
            console.log(session);
            this.user = session.user;
            this.getListing();
        });
    }
    getListing() {
        this.message.load_present();
        this.service.listing({ portador_id: this.user.uuid }).then((res) => {
            this.entregas = res;
        }).finally(() => this.message.load_dismiss());
    }
    getAddress(entrega) {
        let label = '';
        if (entrega.exame) {
            const exame = entrega.exame;
            label = `${exame.logradouro}, ${exame.complemento}, ${exame.bairro} - ${exame.cidade}/${exame.uf}`;
            // label = `${exame.exame_endereco}, ${exame.exame_complemento}, ${exame.exame_bairro} - ${exame.exame_cidade}/${exame.exame_estado}`;
        }
        return label;
    }
    openOptions() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetCtrl.create({
                header: 'Adicionar Entrega',
                cssClass: 'my-custom-class',
                mode: 'ios',
                buttons: [
                    {
                        text: 'Ler QR Code',
                        icon: 'qr-code',
                        handler: () => {
                            this.startQrCodeScan();
                        }
                    }, {
                        text: 'Manual',
                        icon: 'create',
                        handler: () => {
                            this.codeQRManual();
                        }
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    getEntrega() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const code = yield this.message.readQRCode();
            if (code != false) {
                this.message.load_present();
                this.service.getByCode(this.user.uuid, { code: code }).then((res) => {
                    // console.log(res);
                    this.message.load_dismiss();
                    this.navCtrl.navigateForward(`/entrega-detalhe/${res.uuid}`);
                    // this.getListing();
                }).catch(() => this.message.load_dismiss());
            }
        });
    }
    startQrCodeScan() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const code = yield this.message.readQRCode();
            if (code != false) {
                this.entregaForm(code);
            }
        });
    }
    codeQRManual() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                // header: 'Prompt!',
                message: 'Informe o código do QR Code manualmente.',
                backdropDismiss: false,
                mode: 'ios',
                inputs: [
                    {
                        name: 'code',
                        type: 'tel',
                        placeholder: 'Informe o código do QR Code.'
                    }
                ],
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary'
                    }, {
                        text: 'Confirmar',
                        handler: (data) => {
                            if (data.code == "") {
                                return this.message.toastError('Informe o código...');
                            }
                            this.entregaForm(data.code);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    entregaForm(code) {
        const dados = {
            portador_id: this.user.uuid,
            exame_id: code
        };
        this.message.load_present();
        this.service.create(code, dados).then((res) => {
            // console.log(res);
            // this.navCtrl.navigateForward(`/entrega-form/${res.exame_id}`);
            this.message.load_dismiss();
            this.getListing();
        }).catch(() => this.message.load_dismiss());
    }
    searchCode() {
        this.message.load_present();
        this.service.getByCode(this.user.uuid, { code: this.code }).then((res) => {
            // console.log(res);
            this.message.load_dismiss();
            this.navCtrl.navigateForward(`/entrega-detalhe/${res.uuid}`);
            // this.getListing();
        }).catch(() => this.message.load_dismiss());
    }
};
EntregasPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ActionSheetController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: src_app_services_entrega_service__WEBPACK_IMPORTED_MODULE_4__.EntregaService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_5__.MessageService }
];
EntregasPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-entregas',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_entregas_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_entregas_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], EntregasPage);



/***/ }),

/***/ 74605:
/*!******************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/entregas/entregas.page.html ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n\n    <ion-title>Entregas</ion-title>\n\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"getEntrega()\">\n        <ion-icon slot=\"icon-only\" name=\"qr-code\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <ion-row class=\"ion-margin-top\">\n\n    <ion-col size=\"12\">\n      <ion-item>\n        <!-- <ion-label position=\"floating\">Pesquisa:</ion-label> -->\n        <ion-input [(ngModel)]=\"code\" placeholder=\"Informe o código do exame:\"></ion-input>\n        <ion-button fill=\"clear\" (click)=\"searchCode()\">\n          <ion-icon slot=\"icon-only\" color=\"primary\" name=\"search-outline\"></ion-icon>\n        </ion-button>\n      </ion-item>\n    </ion-col>\n\n    <!-- <ion-col size=\"2\">\n      <div align=\"center\" button (click)=\"searchCode()\">\n        <ion-icon name=\"search-circle-outline\" color=\"primary\" style=\"font-size: 2.5rem;\"></ion-icon>\n      </div>\n    </ion-col> -->\n\n  </ion-row>\n\n  <ion-list class=\"ion-margin-top\">\n\n    <ion-item mode=\"ios\" lines=\"full\" detail=\"none\" button [routerLink]=\"[ '/entrega-detalhe/'+entrega.uuid ]\"\n      *ngFor=\"let entrega of entregas\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2>Entrega: {{entrega.exame_id}}</h2>\n        <p>{{getAddress(entrega)}}</p>\n      </ion-label>\n    </ion-item>\n\n  </ion-list>\n\n  <div class=\"ion-padding\" align=\"center\" *ngIf=\"entregas.length == 0\">\n    Sem entregas\n  </div>\n\n  <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button (click)=\"openOptions()\" color=\"primary\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n</ion-content>\n");

/***/ }),

/***/ 51731:
/*!***************************************************!*\
  !*** ./src/app/pages/entregas/entregas.page.scss ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlbnRyZWdhcy5wYWdlLnNjc3MifQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_entregas_entregas_module_ts.js.map