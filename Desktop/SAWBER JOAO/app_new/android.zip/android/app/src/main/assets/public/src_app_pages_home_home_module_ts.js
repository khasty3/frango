"use strict";
(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["src_app_pages_home_home_module_ts"],{

/***/ 96610:
/*!***************************************************!*\
  !*** ./src/app/pages/home/home-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 10678);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], HomePageRoutingModule);



/***/ }),

/***/ 57994:
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home-routing.module */ 96610);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page */ 10678);







let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_0__.HomePageRoutingModule
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_1__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 10678:
/*!*****************************************!*\
  !*** ./src/app/pages/home/home.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_home_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./home.page.html */ 99090);
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss */ 26613);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 54357);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 37556);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/message.service */ 42684);
/* harmony import */ var src_app_services_notification_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/notification.service */ 12013);









let HomePage = class HomePage {
    constructor(alertCtrl, storage, authService, message, notificationService) {
        this.alertCtrl = alertCtrl;
        this.storage = storage;
        this.authService = authService;
        this.message = message;
        this.notificationService = notificationService;
        this.coletas = [];
        this.user = {};
        this.notifications = [];
        this.nowBuild = '2.0.0';
        this.storage.create();
    }
    ngOnInit() {
        this.getUser();
    }
    getNomeAuditor() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                // header: 'Prompt!',
                message: 'Informe seu nome.',
                backdropDismiss: false,
                mode: 'ios',
                inputs: [
                    {
                        name: 'nome',
                        type: 'text',
                        // placeholder: 'Informe o código do QR Code.'
                    },
                ],
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary',
                        handler: () => {
                            // this.navCtrl.pop();
                            this.getNomeAuditor();
                        },
                    },
                    {
                        text: 'Confirmar',
                        handler: (data) => {
                            if (data.nome == '') {
                                this.getNomeAuditor();
                                return this.message.toastError('Informe seu NOME...');
                            }
                            // this.coleta.auditor = data.nome;
                            sessionStorage.setItem('nameAuditor', data.nome);
                            // this.storage.set('nameAuditor', data.nome);
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
    getUser() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const session = yield this.authService.getSession();
            this.user = session.user;
            if (this.user.tipo == 1) {
                const nameAuditor = sessionStorage.getItem('nameAuditor');
                // const nameAuditor = await this.storage.get('nameAuditor');
                if (!nameAuditor) {
                    this.getNomeAuditor();
                }
            }
            this.getNotifications({ portador_id: this.user.uuid });
        });
    }
    ionViewWillEnter() {
        console.log('ionViewWillEnter');
        this.getColetas();
    }
    getColetas() {
        this.storage
            .get('coletas')
            .then((res) => {
            console.log('coletas', res);
            if (res && res != null) {
                //temos coletas
                this.coletas = res;
            }
        })
            .catch((err) => {
            this.message.toastError('Falha ao verificar coletas no dispositivo.');
            console.log(err);
        });
    }
    getNotifications(dados) {
        this.notificationService.getListing(dados).then((res) => {
            this.notifications = res;
        });
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__.MessageService },
    { type: src_app_services_notification_service__WEBPACK_IMPORTED_MODULE_5__.NotificationService }
];
HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-home',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_home_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], HomePage);



/***/ }),

/***/ 99090:
/*!**********************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/home/home.page.html ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<!--<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n\n    <ion-title slot=\"end\">\n      <img src=\"assets/media/logo.png\">\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n-->\n<div class=\"header\" >\n  <ion-buttons slot=\"start\">\n    <ion-menu-button style=\"color:white;\" ></ion-menu-button>\n    <img src=\"assets/media/logo.png\" style=\"/* width: 150px; */margin-left: 9%;\">\n  </ion-buttons>\n \n</div>\n<ion-content color=\"primary\" class=\"ion-padding\" >\n  <div  class=\"ion-margsin-top\" style=\"margin-top: 5px;margin-left: 26px;\">\n    <div>\n      <strong style=\"color: rgb(224, 109, 14);font-size: initial;font-weight: 500;\" class=\"font-md\">Olá {{user.nome}}</strong>\n    </div>\n    <div>\n      <strong style=\"color: rgb(24, 23, 23);font-size: large;\" class=\"font-md\">O que deseja fazer?</strong>\n    </div>\n\n  </div>\n\n\n  <div class=\"ion-padding\" style=\"\n  margin-top: 0px;\n\">\n\n    <!--<div align=\"center\">\n      <strong class=\"font-md\">Informe o que precisa</strong>\n    </div>-->\n\n \n  \n    <ion-card  button color=\"tertiary\" class=\"ion-margin-top\" [routerLink]=\"[ '/coleta' ]\" *ngIf=\"user.tipo == 0\">\n\n      <div class=\"ion-padding\" align=\"center\">\n        <ion-icon name=\"archive-outline\" class=\"font-lg\"></ion-icon>\n        <div>\n          <strong class=\"\">Coleta</strong>\n        </div>\n      </div>\n\n    </ion-card>\n\n    <ion-card button color=\"tertiary\" class=\"ion-margin-top\" *ngIf=\"user.tipo == 0\" [routerLink]=\"[ '/malotes' ]\">\n\n      <div class=\"ion-padding\" align=\"center\">\n        <ion-icon name=\"archive-outline\" class=\"font-lg\"></ion-icon>\n        <div>\n          <strong class=\"\">Coleta Malote</strong>\n        </div>\n      </div>\n\n    </ion-card>\n\n    <ion-card button color=\"tertiary\" class=\"ion-margin-top\" *ngIf=\"user.tipo == 0\" [routerLink]=\"[ '/entregas' ]\">\n\n      <div class=\"ion-padding\" align=\"center\">\n        <ion-icon name=\"navigate-circle-outline\" class=\"font-lg\"></ion-icon>\n        <div>\n          <strong class=\"\">Entrega</strong>\n        </div>\n      </div>\n\n    </ion-card>\n\n    <ion-card button color=\"tertiary\" class=\"ion-margin-top\" [routerLink]=\"[ '/coletas-check' ]\" *ngIf=\"user.tipo == 1\">\n\n      <div class=\"ion-padding\" align=\"center\">\n        <ion-icon name=\"navigate-circle-outline\" class=\"font-lg\"></ion-icon>\n        <div>\n          <strong class=\"\">Coletas</strong>\n        </div>\n      </div>\n\n    </ion-card>\n  </div>\n\n  <div class=\"ion-padding\" *ngIf=\"notifications.length > 0 && user.tipo == 0\">\n    <ion-card button color=\"warning\" class=\"ion-margin-top\" [routerLink]=\"[ '/notifications' ]\">\n\n      <div class=\"ion-padding\" align=\"center\">\n        <!-- <ion-icon name=\"archive-outline\" class=\"font-lg\"></ion-icon> -->\n        <strong class=\"font-md\">{{notifications.length}}</strong>\n        <div>\n          <strong class=\"\">Ocorrências</strong>\n        </div>\n      </div>\n\n    </ion-card>\n  </div>\n\n  <div class=\"ion-padding\" *ngIf=\"coletas.length > 0 && user.tipo == 0\">\n    <ion-card button color=\"danger\" class=\"ion-margin-top\" [routerLink]=\"[ '/coletas-pending' ]\">\n\n      <div class=\"ion-padding\" align=\"center\">\n        <!-- <ion-icon name=\"archive-outline\" class=\"font-lg\"></ion-icon> -->\n        <strong class=\"font-md\">{{coletas.length}}</strong>\n        <div>\n          <strong class=\"\">Coletas Pendentes</strong>\n        </div>\n      </div>\n\n    </ion-card>\n  </div>\n\n  <div class=\"back2\"></div>\n  <div class=\"back\"></div>\n\n  <div align=\"center\">\n    versão: {{nowBuild}}\n  </div>\n \n</ion-content>\n");

/***/ }),

/***/ 26613:
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.page.scss ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "ion-card-header.ios {\n  display: flex;\n  flex-flow: column-reverse;\n  text-align-last: center;\n}\n\n.banner {\n  text-align-last: center;\n  padding: 26px;\n  background: #ff7b00;\n  margin: 5px;\n  top: 12px;\n  border-radius: 23px;\n}\n\n.back {\n  background-color: #eee5e500;\n  position: absolute;\n  width: 100%;\n  padding: 10px;\n  bottom: 0px;\n  left: 0;\n  height: 85%;\n  z-index: -20;\n  border-top-left-radius: 30px;\n  border-top-right-radius: 30px;\n  border-bottom-right-radius: 0;\n  border-bottom-left-radius: 0;\n}\n\n.back2 {\n  background-color: #ffffff;\n  position: absolute;\n  width: 100%;\n  padding: 10px;\n  bottom: 0px;\n  left: 0;\n  height: 99%;\n  z-index: -20;\n  border-top-left-radius: 30px;\n  border-top-right-radius: 30px;\n  border-bottom-right-radius: 0;\n  border-bottom-left-radius: 0;\n}\n\n.header {\n  color: white;\n  background-color: #ed740c;\n  padding: 10px;\n}\n\n.nomeuser {\n  text-align: center;\n  color: white;\n}\n\nion-card-header.ios {\n  display: flex;\n  flex-flow: column-reverse;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBQTtFQUNBLHlCQUFBO0VBQ0EsdUJBQUE7QUFDSjs7QUFFRTtFQUNFLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxtQkFBQTtBQUNKOztBQUVFO0VBQ0UsMkJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsV0FBQTtFQUNBLE9BQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLDRCQUFBO0VBQ0EsNkJBQUE7RUFDQSw2QkFBQTtFQUNBLDRCQUFBO0FBQ0o7O0FBRUU7RUFDRSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsNEJBQUE7RUFDQSw2QkFBQTtFQUNBLDZCQUFBO0VBQ0EsNEJBQUE7QUFDSjs7QUFFRTtFQUNFLFlBQUE7RUFDQSx5QkFBQTtFQUNBLGFBQUE7QUFDSjs7QUFHRTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtBQUFKOztBQUVBO0VBQ0ksYUFBQTtFQUNBLHlCQUFBO0FBQ0oiLCJmaWxlIjoiaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZC1oZWFkZXIuaW9zIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWZsb3c6IGNvbHVtbi1yZXZlcnNlO1xyXG4gICAgdGV4dC1hbGlnbi1sYXN0OiBjZW50ZXI7XHJcblxyXG4gIH1cclxuICAuYmFubmVyIHtcclxuICAgIHRleHQtYWxpZ24tbGFzdDogY2VudGVyO1xyXG4gICAgcGFkZGluZzogMjZweDtcclxuICAgIGJhY2tncm91bmQ6ICNmZjdiMDA7XHJcbiAgICBtYXJnaW46IDVweDtcclxuICAgIHRvcDogMTJweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDIzcHg7XHJcblxyXG4gIH1cclxuICAuYmFja3tcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZWU1ZTUwMDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIGJvdHRvbTogMHB4O1xyXG4gICAgbGVmdDogMDtcclxuICAgIGhlaWdodDogODUlO1xyXG4gICAgei1pbmRleDogLTIwO1xyXG4gICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMzBweDtcclxuICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAzMHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDA7XHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAwO1xyXG4gICAgXHJcbiAgfVxyXG4gIC5iYWNrMntcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBib3R0b206IDBweDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICBoZWlnaHQ6IDk5JTtcclxuICAgIHotaW5kZXg6IC0yMDtcclxuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDMwcHg7XHJcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMzBweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAwO1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMDtcclxuICAgIFxyXG4gIH1cclxuICAuaGVhZGVye1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VkNzQwYztcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBcclxuXHJcbiAgfVxyXG4gIC5ub21ldXNlcntcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjsgXHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbn1cclxuaW9uLWNhcmQtaGVhZGVyLmlvcyB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1mbG93OiBjb2x1bW4tcmV2ZXJzZTtcclxuICB9XHJcblxyXG5cclxuIl19 */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_home_module_ts.js.map