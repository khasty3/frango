"use strict";
(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["src_app_pages_solicitacoes_solicitacoes_module_ts"],{

/***/ 33723:
/*!*******************************************************************!*\
  !*** ./src/app/pages/solicitacoes/solicitacoes-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SolicitacoesPageRoutingModule": () => (/* binding */ SolicitacoesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _solicitacoes_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./solicitacoes.page */ 33465);




const routes = [
    {
        path: '',
        component: _solicitacoes_page__WEBPACK_IMPORTED_MODULE_0__.SolicitacoesPage
    },
    {
        path: ':id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_camera_service_ts"), __webpack_require__.e("src_app_pages_solicitacoes_solicitacao-form_solicitacao-form_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./solicitacao-form/solicitacao-form.module */ 89111)).then(m => m.SolicitacaoFormPageModule)
    }
];
let SolicitacoesPageRoutingModule = class SolicitacoesPageRoutingModule {
};
SolicitacoesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SolicitacoesPageRoutingModule);



/***/ }),

/***/ 25138:
/*!***********************************************************!*\
  !*** ./src/app/pages/solicitacoes/solicitacoes.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SolicitacoesPageModule": () => (/* binding */ SolicitacoesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _solicitacoes_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./solicitacoes-routing.module */ 33723);
/* harmony import */ var _solicitacoes_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./solicitacoes.page */ 33465);







let SolicitacoesPageModule = class SolicitacoesPageModule {
};
SolicitacoesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _solicitacoes_routing_module__WEBPACK_IMPORTED_MODULE_0__.SolicitacoesPageRoutingModule
        ],
        declarations: [_solicitacoes_page__WEBPACK_IMPORTED_MODULE_1__.SolicitacoesPage]
    })
], SolicitacoesPageModule);



/***/ }),

/***/ 33465:
/*!*********************************************************!*\
  !*** ./src/app/pages/solicitacoes/solicitacoes.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SolicitacoesPage": () => (/* binding */ SolicitacoesPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_solicitacoes_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./solicitacoes.page.html */ 74943);
/* harmony import */ var _solicitacoes_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./solicitacoes.page.scss */ 55728);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 37556);
/* harmony import */ var src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/coleta.service */ 35738);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/message.service */ 42684);








let SolicitacoesPage = class SolicitacoesPage {
    constructor(actionSheetController, alertCtrl, navCtrl, auth, service, message) {
        this.actionSheetController = actionSheetController;
        this.alertCtrl = alertCtrl;
        this.navCtrl = navCtrl;
        this.auth = auth;
        this.service = service;
        this.message = message;
        this.userCurrent = {};
        this.filters = { portador_accepted: 1 };
        this.solicitacoes = [];
    }
    ngOnInit() { }
    ionViewWillEnter() {
        this.getSolicitacoes();
    }
    getUser() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const session = yield this.auth.getSession();
            console.log('session', session);
            if (!session) {
                return;
            }
            this.userCurrent = session.user;
            this.filters.portador_id = this.userCurrent.uuid;
            // this.getSolicitacoes();
        });
    }
    getSolicitacoes() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            yield this.getUser();
            this.message.load_present();
            this.service
                .getSolicitacoes(this.filters)
                .then((res) => {
                this.solicitacoes = res;
            })
                .finally(() => this.message.load_dismiss());
        });
    }
    openSolicitacao(solicitacao) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            if (solicitacao.type == 'RETIRADA') {
                const actionSheet = yield this.actionSheetController.create({
                    header: `Retirada de Material`,
                    subHeader: 'Informe o código para iniciar a coleta.',
                    mode: 'ios',
                    // cssClass: 'my-custom-class',
                    buttons: [
                        {
                            text: 'Manual',
                            icon: 'create-outline',
                            handler: () => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                                // console.log('Delete clicked');
                                this.codeQRManual(solicitacao);
                            }),
                        },
                        {
                            text: 'Ler QR Code',
                            icon: 'qr-code-outline',
                            handler: () => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                                this.startQrCodeScan(solicitacao);
                            }),
                        },
                        {
                            text: 'Sem coleta',
                            icon: 'archive-outline',
                            handler: () => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                                this.semColeta(solicitacao);
                            }),
                        },
                    ],
                });
                yield actionSheet.present();
            }
            else {
                if (!solicitacao.portador_accepted &&
                    solicitacao.prioridade == 'URGENTE') {
                    this.message.openModalConfirme({ solicitacao: solicitacao });
                }
                else {
                    this.navCtrl.navigateForward(`/solicitacoes/${solicitacao.uuid}`);
                }
            }
        });
    }
    startQrCodeScan(solicitacao) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const code = yield this.message.readQRCode();
            if (code != false) {
                this.coletaForm(code, solicitacao);
            }
        });
    }
    semColeta(solicitacao) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                // header: 'Prompt!',
                message: 'Você tem certeza disso?',
                backdropDismiss: false,
                mode: 'ios',
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary',
                    },
                    {
                        text: 'Confirmar',
                        handler: () => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                            solicitacao.status = 'FINALIZADO';
                            this.service
                                .updateSolicitacao(solicitacao.uuid, solicitacao)
                                .then((res) => {
                                window.location.reload();
                            })
                                .finally(() => {
                                //window.location.reload();
                            });
                        }),
                    },
                ],
            });
            yield alert.present();
        });
    }
    codeQRManual(solicitacao) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                // header: 'Prompt!',
                message: 'Informe o código do QR Code manualmente.',
                backdropDismiss: false,
                mode: 'ios',
                inputs: [
                    {
                        name: 'code',
                        type: 'tel',
                        placeholder: 'Informe o código do QR Code.',
                    },
                ],
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary',
                    },
                    {
                        text: 'Confirmar',
                        handler: (data) => {
                            if (data.code == '') {
                                return this.message.toastError('Informe o código...');
                            }
                            this.coletaForm(data.code, solicitacao);
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
    coletaForm(code, solicitacao) {
        this.message.load_present();
        let dadosColeta = {
            code_qr: code,
            clinica_id: solicitacao.clinica.uuid,
            solicitacao_id: solicitacao.uuid,
        };
        this.service
            .createColeta(dadosColeta)
            .then((res) => {
            this.navCtrl.navigateForward(`/coleta-form/${res.data.uuid}`, {
                queryParams: { solicitacao_id: solicitacao.uuid },
            });
        })
            .finally(() => this.message.load_dismiss());
        // this.service.checkColetaCode(code).then(() => {
        //   this.navCtrl.navigateForward(`/coleta-form/${solicitacao.clinica.uuid}/${code}`, {
        //     queryParams: { solicitacao_id: solicitacao.uuid }
        //   });
        // }).finally(() => this.message.load_dismiss());
    }
};
SolicitacoesPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ActionSheetController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_3__.ColetaService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__.MessageService }
];
SolicitacoesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-solicitacoes',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_solicitacoes_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_solicitacoes_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], SolicitacoesPage);



/***/ }),

/***/ 74943:
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/solicitacoes/solicitacoes.page.html ***!
  \**************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"primary\"></ion-back-button>\n    </ion-buttons>\n\n    <ion-title color=\"primary\">\n      Solicitações\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n\n  <ion-list>\n\n    <ion-item button lines=\"full\" *ngFor=\"let item of solicitacoes\" (click)=\"openSolicitacao(item)\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2># <strong>{{ item.id }}</strong></h2>\n        <h2>Endereço: <strong>{{ item.clinica.full_address }}</strong></h2>\n        <h2>Médico: <strong>{{ item.medico.nome | titlecase }}</strong></h2>\n        \n        <h2 *ngIf=\"item.descricao\" style=\"\n        border: solid 1px #b3b3b3;\n        border-radius: 12px;\n        padding: 12px;\n    \" >Obs: <strong>{{ item.descricao | titlecase }}</strong></h2>\n        <ion-row>\n          <ion-col size=\"6\">\n            <ion-badge color=\"medium\">{{item.status}}</ion-badge>\n          </ion-col>\n\n          <ion-col size=\"6\" class=\"text-right\">\n            <p>{{ item.agendamento | date: 'dd/MM/yyyy' }}</p>\n          </ion-col>\n\n          <ion-col size=\"6\">\n            <p>{{item.type == 'ENTREGA' ? 'Entrega de Kit' : 'Coleta de Material'}}</p>\n          </ion-col>\n\n          <ion-col size=\"6\" class=\"text-right\">\n            <ion-badge color=\"secondary\" *ngIf=\"item.prioridade == 'ROTINA'\">{{item.prioridade}}</ion-badge>\n            <ion-badge color=\"primary\" *ngIf=\"item.prioridade == 'URGENTE'\">{{item.prioridade}}</ion-badge>\n          </ion-col>\n          <ion-col size=\"6\" class=\"text-right\" *ngIf=\"!item.portador_accepted && item.prioridade == 'URGENTE'\">\n            <ion-badge color=\"secondary\">Pendente de confirmação</ion-badge>\n          </ion-col>\n\n        </ion-row>\n      </ion-label>\n    </ion-item>\n\n  </ion-list>\n\n</ion-content>\n");

/***/ }),

/***/ 55728:
/*!***********************************************************!*\
  !*** ./src/app/pages/solicitacoes/solicitacoes.page.scss ***!
  \***********************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzb2xpY2l0YWNvZXMucGFnZS5zY3NzIn0= */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_solicitacoes_solicitacoes_module_ts.js.map