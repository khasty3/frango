"use strict";
(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["src_app_pages_coletas-pending_coletas-pending_module_ts"],{

/***/ 68123:
/*!*************************************************************************!*\
  !*** ./src/app/pages/coletas-pending/coletas-pending-routing.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetasPendingPageRoutingModule": () => (/* binding */ ColetasPendingPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _coletas_pending_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./coletas-pending.page */ 56299);




const routes = [
    {
        path: '',
        component: _coletas_pending_page__WEBPACK_IMPORTED_MODULE_0__.ColetasPendingPage
    }
];
let ColetasPendingPageRoutingModule = class ColetasPendingPageRoutingModule {
};
ColetasPendingPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ColetasPendingPageRoutingModule);



/***/ }),

/***/ 71878:
/*!*****************************************************************!*\
  !*** ./src/app/pages/coletas-pending/coletas-pending.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetasPendingPageModule": () => (/* binding */ ColetasPendingPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _coletas_pending_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./coletas-pending-routing.module */ 68123);
/* harmony import */ var _coletas_pending_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./coletas-pending.page */ 56299);







let ColetasPendingPageModule = class ColetasPendingPageModule {
};
ColetasPendingPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _coletas_pending_routing_module__WEBPACK_IMPORTED_MODULE_0__.ColetasPendingPageRoutingModule
        ],
        declarations: [_coletas_pending_page__WEBPACK_IMPORTED_MODULE_1__.ColetasPendingPage]
    })
], ColetasPendingPageModule);



/***/ }),

/***/ 56299:
/*!***************************************************************!*\
  !*** ./src/app/pages/coletas-pending/coletas-pending.page.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetasPendingPage": () => (/* binding */ ColetasPendingPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_coletas_pending_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./coletas-pending.page.html */ 54537);
/* harmony import */ var _coletas_pending_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./coletas-pending.page.scss */ 61074);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 54357);
/* harmony import */ var src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/coleta.service */ 35738);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/message.service */ 42684);







let ColetasPendingPage = class ColetasPendingPage {
    constructor(storage, service, message) {
        this.storage = storage;
        this.service = service;
        this.message = message;
        this.coletas = [];
        this.storage.create();
    }
    ngOnInit() {
        this.getColeta();
    }
    getColeta() {
        this.storage.get('coletas').then(res => {
            if (res && res != null) {
                console.log(res);
                this.coletas = res;
            }
        });
    }
    sendColeta(dados, i) {
        console.log(dados);
        this.message.load_present();
        this.service.createColeta(dados).then(() => {
            // this.navCtrl.navigateRoot('/home');
            this.processColeta(i);
        }).catch(err => {
            // this.storageColeta();
        }).finally(() => this.message.load_dismiss());
    }
    processColeta(index) {
        this.coletas.splice(index, 1);
        this.storage.set('coletas', this.coletas).then(() => {
            this.getColeta();
        }).catch(err => {
            this.message.toastError('Falha ao atualizar coleta no dispositivo.');
            console.log(err);
        });
    }
};
ColetasPendingPage.ctorParameters = () => [
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_3__.ColetaService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__.MessageService }
];
ColetasPendingPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-coletas-pending',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_coletas_pending_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_coletas_pending_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ColetasPendingPage);



/***/ }),

/***/ 54537:
/*!********************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coletas-pending/coletas-pending.page.html ***!
  \********************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n\n    <ion-title>\n      Coletas Pendentes\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-list>\n\n    <ion-item line=\"full\" *ngFor=\"let item of coletas; let i = index;\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2>{{ item.clinica | titlecase }}</h2>\n      </ion-label>\n      <ion-button slot=\"end\" fill=\"clear\" (click)=\"sendColeta(item, i)\">\n        <ion-icon name=\"send-outline\" color=\"tertiary\"></ion-icon>\n      </ion-button>\n    </ion-item>\n\n  </ion-list>\n\n  <div class=\"ion-padding\" align=\"center\" *ngIf=\"coletas.length == 0\">\n    Nenhuma coleta pendente\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ 61074:
/*!*****************************************************************!*\
  !*** ./src/app/pages/coletas-pending/coletas-pending.page.scss ***!
  \*****************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjb2xldGFzLXBlbmRpbmcucGFnZS5zY3NzIn0= */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_coletas-pending_coletas-pending_module_ts.js.map