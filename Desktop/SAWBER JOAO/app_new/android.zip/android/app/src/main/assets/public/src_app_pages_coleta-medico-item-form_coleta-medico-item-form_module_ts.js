"use strict";
(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["src_app_pages_coleta-medico-item-form_coleta-medico-item-form_module_ts"],{

/***/ 90600:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/coleta-medico-item-form/coleta-medico-item-form-routing.module.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetaMedicoItemFormPageRoutingModule": () => (/* binding */ ColetaMedicoItemFormPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _coleta_medico_item_form_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./coleta-medico-item-form.page */ 24140);




const routes = [
    {
        path: '',
        component: _coleta_medico_item_form_page__WEBPACK_IMPORTED_MODULE_0__.ColetaMedicoItemFormPage
    }
];
let ColetaMedicoItemFormPageRoutingModule = class ColetaMedicoItemFormPageRoutingModule {
};
ColetaMedicoItemFormPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ColetaMedicoItemFormPageRoutingModule);



/***/ }),

/***/ 47442:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/coleta-medico-item-form/coleta-medico-item-form.module.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetaMedicoItemFormPageModule": () => (/* binding */ ColetaMedicoItemFormPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _coleta_medico_item_form_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./coleta-medico-item-form-routing.module */ 90600);
/* harmony import */ var _coleta_medico_item_form_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./coleta-medico-item-form.page */ 24140);







let ColetaMedicoItemFormPageModule = class ColetaMedicoItemFormPageModule {
};
ColetaMedicoItemFormPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _coleta_medico_item_form_routing_module__WEBPACK_IMPORTED_MODULE_0__.ColetaMedicoItemFormPageRoutingModule
        ],
        declarations: [_coleta_medico_item_form_page__WEBPACK_IMPORTED_MODULE_1__.ColetaMedicoItemFormPage]
    })
], ColetaMedicoItemFormPageModule);



/***/ }),

/***/ 24140:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/coleta-medico-item-form/coleta-medico-item-form.page.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ColetaMedicoItemFormPage": () => (/* binding */ ColetaMedicoItemFormPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_coleta_medico_item_form_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./coleta-medico-item-form.page.html */ 88606);
/* harmony import */ var _coleta_medico_item_form_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./coleta-medico-item-form.page.scss */ 47893);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_app_services_camera_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/camera.service */ 53942);
/* harmony import */ var src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/coleta.service */ 35738);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/message.service */ 42684);








// import {
//   Camera, CameraResultType, CameraSource, CameraDirection
// } from '@capacitor/camera';
// import { BackgroundMode } from '@awesome-cordova-plugins/background-mode/ngx';
let ColetaMedicoItemFormPage = class ColetaMedicoItemFormPage {
    constructor(alertCtrl, modalCtrl, service, message, cameraService
    // private backgroundMode: BackgroundMode,
    // private camera: Camera
    ) {
        this.alertCtrl = alertCtrl;
        this.modalCtrl = modalCtrl;
        this.service = service;
        this.message = message;
        this.cameraService = cameraService;
        this.dados = {};
        this.warning = false;
        this.types = [];
    }
    ngOnInit() {
        console.log('medico item form', this.medico);
        if (this.medico) {
            this.dados.medico_id = this.medico.uuid;
            this.dados.coleta_id = this.coleta_id;
            if (this.dados.medico_id) {
                this.getTipos();
            }
            else {
                this.warning = true;
            }
        }
    }
    close(params = undefined) {
        this.modalCtrl.dismiss(params);
    }
    getTipos() {
        this.message.load_present();
        this.service.getExameTypes().then(res => {
            this.types = res;
        }).finally(() => this.message.load_dismiss());
    }
    changeTipo(event) {
        // console.log(uuid);
        const uuid = event.value;
        this.dados.tipo_id = uuid;
        this.dados.tipo = this.types.find(tipo => tipo.uuid == uuid);
    }
    addTipo() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                header: 'Cadastrar Tipo',
                message: 'Informe o novo tipo de exame.',
                mode: 'ios',
                inputs: [
                    {
                        name: 'nome',
                        type: 'text',
                        placeholder: 'Informe o nome'
                    }
                ],
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary'
                    }, {
                        text: 'Confirmar',
                        handler: (data) => {
                            if (!data.nome || data.nome == "") {
                                return this.message.toastError('Informe o nome!');
                            }
                            this.message.load_present();
                            this.service.setExameTypes(data).then(() => {
                                this.message.load_dismiss();
                                this.getTipos();
                            }).catch(() => this.message.load_dismiss());
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    confirmItem() {
        if (!this.dados.foto) {
            return this.message.toastError('Tire uma foto do exame coletado.');
        }
        if (!this.dados.tipo_id && !this.warning) {
            return this.message.toastError('Informe o tipo do exame coletado.');
        }
        if (!this.dados.description && this.warning) {
            return this.message.toastError('Informe o motivo da ocorrência.');
        }
        this.message.load_present();
        this.service.createItemColeta(this.dados).then(res => {
            // this.types = res;
            this.close(res.data);
        }).finally(() => this.message.load_dismiss());
    }
    takePhoto() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            console.log('takePhoto');
            let image = yield this.cameraService.takePhoto();
            if (image.base64String) {
                this.dados.foto = `data:image/jpeg;base64,${image.base64String}`;
            }
            // const options: CameraOptions = {
            //   quality: 50,
            //   destinationType: this.camera.DestinationType.DATA_URL,
            //   encodingType: this.camera.EncodingType.JPEG,
            //   mediaType: this.camera.MediaType.PICTURE
            // }
            // // this.backgroundMode.enable();
            // // if (this.backgroundMode.isActive()) {
            // this.camera.getPicture(options).then(imageData => {
            //   console.log('imageDta', imageData);
            //   this.dados.foto = `data:image/jpeg;base64,${imageData}`;
            // }).finally(() => {
            //   // this.backgroundMode.disable();
            // });
            // }
        });
    }
};
ColetaMedicoItemFormPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_3__.ColetaService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__.MessageService },
    { type: src_app_services_camera_service__WEBPACK_IMPORTED_MODULE_2__.CameraService }
];
ColetaMedicoItemFormPage.propDecorators = {
    medico: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.Input }],
    coleta_id: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.Input }]
};
ColetaMedicoItemFormPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-coleta-medico-item-form',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_coleta_medico_item_form_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_coleta_medico_item_form_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ColetaMedicoItemFormPage);



/***/ }),

/***/ 88606:
/*!************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/coleta-medico-item-form/coleta-medico-item-form.page.html ***!
  \************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"close()\">\n        <ion-icon name=\"arrow-back-outline\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-title>Adicionar item</ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n\n  <div class=\"ion-margin-top\" align=\"center\">\n    <img [src]=\"dados.foto ? dados.foto : 'assets/media/no-image.png'\" class=\"img-card\" (click)=\"takePhoto()\">\n  </div>\n\n  <ion-row class=\"ion-margin-top\">\n\n    <ion-col size=\"12\" *ngIf=\"!warning\">\n      <ion-item>\n        <ion-label position=\"floating\">Tipo do Exame:</ion-label>\n        <ion-select (ionChange)=\"changeTipo($event.target)\" okText=\"Confirmar\" cancelText=\"Voltar\" mode=\"ios\">\n          <!-- <ion-select-option value=\"\">Selecione o tipo</ion-select-option> -->\n          <ion-select-option *ngFor=\"let tipo of types\" [value]=\"tipo.uuid\">{{tipo.nome | titlecase}}\n          </ion-select-option>\n        </ion-select>\n      </ion-item>\n    </ion-col>\n\n    <!-- <ion-col size=\"2\">\n      <div align=\"center\" button (click)=\"addTipo()\">\n        <ion-icon name=\"add-circle\" color=\"primary\" style=\"font-size: 2.5rem;\"></ion-icon>\n      </div>\n    </ion-col> -->\n\n\n    <ion-col size=\"12\" *ngIf=\"warning\">\n      <ion-item>\n        <!-- <ion-label position=\"stacked\">Motivo da ocorrência</ion-label> -->\n        <ion-textarea mode=\"ios\" rows=\"6\" placeholder=\"Motivo da ocorrência:\" [(ngModel)]=\"dados.description\">\n        </ion-textarea>\n      </ion-item>   \n    </ion-col>\n \n  </ion-row>\n\n  <div class=\"ion-margin-top\">\n    <ion-button expand=\"block\" color=\"tertiary\" (click)=\"confirmItem()\">\n      Adicionar\n    </ion-button>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ 47893:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/coleta-medico-item-form/coleta-medico-item-form.page.scss ***!
  \*********************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjb2xldGEtbWVkaWNvLWl0ZW0tZm9ybS5wYWdlLnNjc3MifQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_coleta-medico-item-form_coleta-medico-item-form_module_ts.js.map