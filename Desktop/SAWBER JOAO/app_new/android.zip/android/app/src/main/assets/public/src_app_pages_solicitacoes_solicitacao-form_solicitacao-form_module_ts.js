"use strict";
(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["src_app_pages_solicitacoes_solicitacao-form_solicitacao-form_module_ts"],{

/***/ 1361:
/*!****************************************************************************************!*\
  !*** ./src/app/pages/solicitacoes/solicitacao-form/solicitacao-form-routing.module.ts ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SolicitacaoFormPageRoutingModule": () => (/* binding */ SolicitacaoFormPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _solicitacao_form_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./solicitacao-form.page */ 17567);




const routes = [
    {
        path: '',
        component: _solicitacao_form_page__WEBPACK_IMPORTED_MODULE_0__.SolicitacaoFormPage
    }
];
let SolicitacaoFormPageRoutingModule = class SolicitacaoFormPageRoutingModule {
};
SolicitacaoFormPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SolicitacaoFormPageRoutingModule);



/***/ }),

/***/ 89111:
/*!********************************************************************************!*\
  !*** ./src/app/pages/solicitacoes/solicitacao-form/solicitacao-form.module.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SolicitacaoFormPageModule": () => (/* binding */ SolicitacaoFormPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _solicitacao_form_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./solicitacao-form-routing.module */ 1361);
/* harmony import */ var _solicitacao_form_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./solicitacao-form.page */ 17567);







let SolicitacaoFormPageModule = class SolicitacaoFormPageModule {
};
SolicitacaoFormPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _solicitacao_form_routing_module__WEBPACK_IMPORTED_MODULE_0__.SolicitacaoFormPageRoutingModule
        ],
        declarations: [_solicitacao_form_page__WEBPACK_IMPORTED_MODULE_1__.SolicitacaoFormPage]
    })
], SolicitacaoFormPageModule);



/***/ }),

/***/ 17567:
/*!******************************************************************************!*\
  !*** ./src/app/pages/solicitacoes/solicitacao-form/solicitacao-form.page.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SolicitacaoFormPage": () => (/* binding */ SolicitacaoFormPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_solicitacao_form_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./solicitacao-form.page.html */ 20379);
/* harmony import */ var _solicitacao_form_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./solicitacao-form.page.scss */ 56034);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_app_services_camera_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/camera.service */ 53942);
/* harmony import */ var src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/coleta.service */ 35738);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/message.service */ 42684);









let SolicitacaoFormPage = class SolicitacaoFormPage {
    constructor(navCtrl, actionSheetController, alertController, route, service, message, cameraService
    // private camera: Camera
    ) {
        this.navCtrl = navCtrl;
        this.actionSheetController = actionSheetController;
        this.alertController = alertController;
        this.route = route;
        this.service = service;
        this.message = message;
        this.cameraService = cameraService;
        this.userCurrent = {};
        this.filters = {};
        this.dados = { itens: [] };
        this.dia = {
            status: 1,
            medico_id: {},
            clinica_id: {},
            portador_id: {},
            itens: [],
            force: 0,
            teste: null
        };
    }
    ngOnInit() {
        this.route.params.subscribe(res => {
            if (res.id) {
                this.getDados(res.id);
            }
        }).unsubscribe();
    }
    getDados(id) {
        this.message.load_present();
        this.service.getSolicitacao(id).then(res => {
            this.dados = res;
        }).finally(() => this.message.load_dismiss());
    }
    openOptions(item, i) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                header: `${item.material}`,
                mode: 'ios',
                // cssClass: 'my-custom-class',
                buttons: [
                    {
                        text: 'Ocorrência',
                        icon: 'warning-outline',
                        handler: () => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                            // console.log('Delete clicked');
                            let result = yield this.presentAlertPrompt();
                            console.log('result', result);
                            if (!result.role && result.data.values.description) {
                                this.dados.itens[i].description = result.data.values.description;
                            }
                            console.log(this.dados);
                        })
                    }, {
                        text: 'Foto',
                        icon: 'camera-outline',
                        handler: () => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                            let foto = yield this.getPhoto();
                            if (foto) {
                                this.dados.itens[i].foto = foto;
                            }
                        })
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    presentAlertPrompt() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                mode: 'ios',
                header: 'Dados da ocorrência',
                inputs: [
                    {
                        name: 'description',
                        type: 'textarea',
                        attributes: {
                            rows: 5,
                        },
                        placeholder: 'Informe o motivo da ocorrência:'
                    }
                ],
                buttons: [
                    {
                        text: 'Voltar',
                        role: 'cancel',
                        cssClass: 'secondary'
                    }, {
                        text: 'Confirmar',
                        handler: (res) => {
                            if (!res.description) {
                                this.message.toastError('Informe o motivo.');
                            }
                        }
                    }
                ]
            });
            yield alert.present();
            return yield alert.onDidDismiss();
        });
    }
    getPhoto() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            let image = yield this.cameraService.takePhoto();
            if (image.base64String) {
                return `data:image/jpeg;base64,${image.base64String}`;
            }
            return false;
            // // const capturedPhoto = await Camera.getPhoto({
            // //   resultType: CameraResultType.Base64,
            // //   allowEditing: false,
            // //   source: CameraSource.Camera,
            // //   direction: CameraDirection.Rear,
            // //   quality: 60
            // // });
            // // if (capturedPhoto.base64String) {
            // //   return `data:image/jpeg;base64,${capturedPhoto.base64String}`;
            // // }
            // // Take a photo
            // const options: CameraOptions = {
            //   quality: 50,
            //   destinationType: this.camera.DestinationType.DATA_URL,
            //   encodingType: this.camera.EncodingType.JPEG,
            //   mediaType: this.camera.MediaType.PICTURE
            // }
            // // if (this.backgroundMode.isActive()) {
            // let captured = await this.camera.getPicture(options)
            //   .finally(() => {
            //     // this.backgroundMode.disable()
            //   });
            // if (captured) {
            //   return `data:image/jpeg;base64,${captured}`;
            // }
            // return false;
        });
    }
    checkRotinaPortador() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            // if (!this.dados.portador_id) {
            //   return this.message.toastError('A Clinica não está em nenhum roteiro.');
            // }
            const teste = yield this.service
                .getCustom("app/motoboy/available", this.dia);
            return teste.date;
        });
    }
    naoEntregue() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            this.dia.portador_id = this.dados.portador.uuid;
            this.dia.clinica_id = this.dados.clinica_id;
            this.dia.medico_id = this.dados.medico.uuid;
            const teste = yield this.checkRotinaPortador();
            const alert = yield this.alertController.create({
                mode: 'ios',
                header: 'Qual foi o motivo ?',
                inputs: [
                    {
                        name: 'motivo',
                        type: 'text',
                        placeholder: 'Digite o motivo:',
                    },
                    {
                        type: 'text',
                        value: 'Será Reagendado para:',
                        disabled: true,
                        cssClass: 'naoentregue',
                    },
                    {
                        name: 'agendamento',
                        type: 'text',
                        disabled: true,
                        //value: '8', 
                        //  min: moment(this.dados.agendamento).format('YYYY-MM-DD') ,
                        value: teste,
                        cssClass: 'naoentregue',
                        //placeholder: 'Digite o motivo:'
                    }
                ],
                buttons: [
                    {
                        text: 'Voltar',
                        role: 'cancel',
                        cssClass: 'secondary'
                    },
                    {
                        text: 'Confirmar',
                        handler: (res) => {
                            if (!res.motivo) {
                                return this.message.toastError('Por favor nos diga qual foi o motivo.');
                            }
                            //this.dados.status = 'FINALIZADO';
                            this.dados.motivo = res.motivo;
                            this.dados.reagendado = 1;
                            this.dados.aceito = 0;
                            this.dados.agendamento = res.agendamento;
                            this.message.load_present();
                            this.service.updateSolicitacao(this.dados.uuid, this.dados).then(res => {
                                this.navCtrl.back();
                            }).finally(() => this.message.load_dismiss());
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    finish() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                mode: 'ios',
                header: 'Quem está recebendo ?',
                inputs: [
                    {
                        name: 'recebedor',
                        type: 'text',
                        placeholder: 'Informe o nome do atendente:'
                    }
                ],
                buttons: [
                    {
                        text: 'Voltar',
                        role: 'cancel',
                        cssClass: 'secondary'
                    }, {
                        text: 'Confirmar',
                        handler: (res) => {
                            if (!res.recebedor) {
                                return this.message.toastError('Informe quem recebeu.');
                            }
                            this.dados.status = 'FINALIZADO';
                            this.dados.recebedor = res.recebedor;
                            this.message.load_present();
                            this.service.updateSolicitacao(this.dados.uuid, this.dados).then(res => {
                                this.navCtrl.back();
                            }).finally(() => this.message.load_dismiss());
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
SolicitacaoFormPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ActionSheetController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute },
    { type: src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_3__.ColetaService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__.MessageService },
    { type: src_app_services_camera_service__WEBPACK_IMPORTED_MODULE_2__.CameraService }
];
SolicitacaoFormPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-solicitacao-form',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_solicitacao_form_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_solicitacao_form_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], SolicitacaoFormPage);



/***/ }),

/***/ 20379:
/*!***********************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/solicitacoes/solicitacao-form/solicitacao-form.page.html ***!
  \***********************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"primary\"></ion-back-button>\n    </ion-buttons>\n\n    <ion-title color=\"primary\">\n      Entrega de Kit\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-card mode=\"ios\">\n    <ion-item lines=\"none\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2>Clínica: <strong *ngIf=\"dados.clinica\">{{dados.clinica.full_address}}</strong></h2>\n      </ion-label>\n    </ion-item>\n  </ion-card>\n\n  <ion-card mode=\"ios\">\n    <ion-item lines=\"none\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2>Médico: <strong *ngIf=\"dados.medico\">{{dados.medico.nome}}</strong></h2>\n      </ion-label>\n    </ion-item>\n  </ion-card>\n\n  <ion-list>\n    <ion-list-header color=\"primary\">Itens</ion-list-header>\n    <ion-item lines=\"full\" *ngFor=\"let item of dados.itens; let i = index\" (click)=\"openOptions(item, i)\">\n      <ion-label class=\"ion-text-wrap\">\n        {{item.material}} - {{item.quantidade | number}}\n      </ion-label>\n      <div slot=\"end\" class=\"text-rigth\">\n        <ion-icon *ngIf=\"item.description\" name=\"warning-outline\" color=\"primary\"></ion-icon>\n        <ion-icon *ngIf=\"item.foto\" name=\"camera-outline\" color=\"primary\"></ion-icon>\n      </div>\n    </ion-item>\n  </ion-list>\n\n  <div class=\"ion-padding\">\n    <ion-button color=\"tertiary\" expand=\"block\" (click)=\"finish()\">\n      Confirmar Entrega\n    </ion-button>\n  </div>\n  <div class=\"ion-padding\">\n    <ion-button color=\"danger\" expand=\"block\" (click)=\"naoEntregue()\">\n      Não Entregue\n    </ion-button>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ 56034:
/*!********************************************************************************!*\
  !*** ./src/app/pages/solicitacoes/solicitacao-form/solicitacao-form.page.scss ***!
  \********************************************************************************/
/***/ ((module) => {

module.exports = ".lala {\n  color: red !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNvbGljaXRhY2FvLWZvcm0ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0EscUJBQUE7QUFDQSIsImZpbGUiOiJzb2xpY2l0YWNhby1mb3JtLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sYWxhIHtcclxuY29sb3I6cmdiKDI1NSwgMCwgMCkhaW1wb3J0YW50O1xyXG59Il19 */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_solicitacoes_solicitacao-form_solicitacao-form_module_ts.js.map