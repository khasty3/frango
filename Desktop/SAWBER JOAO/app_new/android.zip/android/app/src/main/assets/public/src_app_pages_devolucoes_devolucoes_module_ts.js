"use strict";
(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["src_app_pages_devolucoes_devolucoes_module_ts"],{

/***/ 27280:
/*!***************************************************************!*\
  !*** ./src/app/pages/devolucoes/devolucoes-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DevolucoesPageRoutingModule": () => (/* binding */ DevolucoesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _devolucoes_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./devolucoes.page */ 26973);




const routes = [
    {
        path: '',
        component: _devolucoes_page__WEBPACK_IMPORTED_MODULE_0__.DevolucoesPage
    },
    {
        path: ':id',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_camera_service_ts"), __webpack_require__.e("src_app_pages_devolucoes_devolucao-form_devolucao-form_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./devolucao-form/devolucao-form.module */ 12516)).then(m => m.DevolucaoFormPageModule)
    }
];
let DevolucoesPageRoutingModule = class DevolucoesPageRoutingModule {
};
DevolucoesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DevolucoesPageRoutingModule);



/***/ }),

/***/ 58489:
/*!*******************************************************!*\
  !*** ./src/app/pages/devolucoes/devolucoes.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DevolucoesPageModule": () => (/* binding */ DevolucoesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _devolucoes_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./devolucoes-routing.module */ 27280);
/* harmony import */ var _devolucoes_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./devolucoes.page */ 26973);







let DevolucoesPageModule = class DevolucoesPageModule {
};
DevolucoesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _devolucoes_routing_module__WEBPACK_IMPORTED_MODULE_0__.DevolucoesPageRoutingModule
        ],
        declarations: [_devolucoes_page__WEBPACK_IMPORTED_MODULE_1__.DevolucoesPage]
    })
], DevolucoesPageModule);



/***/ }),

/***/ 26973:
/*!*****************************************************!*\
  !*** ./src/app/pages/devolucoes/devolucoes.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DevolucoesPage": () => (/* binding */ DevolucoesPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_devolucoes_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./devolucoes.page.html */ 63871);
/* harmony import */ var _devolucoes_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./devolucoes.page.scss */ 66065);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 37556);
/* harmony import */ var src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/coleta.service */ 35738);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/message.service */ 42684);








let DevolucoesPage = class DevolucoesPage {
    constructor(nav, auth, service, message) {
        this.nav = nav;
        this.auth = auth;
        this.service = service;
        this.message = message;
        this.userCurrent = {};
        this.filters = {};
        this.devolucoes = [];
    }
    ngOnInit() { }
    ionViewWillEnter() {
        this.getDevolucoes();
    }
    getUser() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const session = yield this.auth.getSession();
            if (!session) {
                return;
            }
            this.userCurrent = session.user;
            this.filters.portador_id = this.userCurrent.uuid;
            // this.getDevolucoes();
        });
    }
    getDevolucoes() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            yield this.getUser();
            this.message.load_present();
            this.service
                .getDevolucoes(this.filters)
                .then((res) => {
                this.devolucoes = res;
            })
                .finally(() => this.message.load_dismiss());
        });
    }
    openForm(item) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            if (!item.portador_accepted && item.prioridade == 'URGENTE') {
                const response = yield this.message.openModalConfirme({
                    devolucao: item,
                });
                if (response) {
                    this.getDevolucoes();
                }
            }
            else {
                this.nav.navigateForward(`/devolucoes/${item.uuid}`);
            }
        });
    }
};
DevolucoesPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: src_app_services_coleta_service__WEBPACK_IMPORTED_MODULE_3__.ColetaService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__.MessageService }
];
DevolucoesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-devolucoes',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_devolucoes_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_devolucoes_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], DevolucoesPage);



/***/ }),

/***/ 63871:
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/devolucoes/devolucoes.page.html ***!
  \**********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"primary\"></ion-back-button>\n    </ion-buttons>\n\n    <ion-title color=\"primary\">\n      Devoluções\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n\n  <ion-list>\n\n    <ion-item button lines=\"full\" *ngFor=\"let item of devolucoes\" (click)=\"openForm(item)\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2># <strong>{{ item.id }}</strong></h2>\n        <h2>Endereço: <strong>{{ item.clinica.full_address | titlecase }}</strong></h2>\n        <h2>Médico: <strong>{{ item.medico.nome | titlecase }}</strong></h2>\n        <ion-row>\n          <ion-col size=\"6\">\n            <ion-badge color=\"dark\">{{item.status}}</ion-badge>\n          </ion-col>\n\n          <ion-col size=\"6\" class=\"text-right\">\n            <p>{{ item.agendamento | date: 'dd/MM/yyyy' }}</p>\n          </ion-col>\n\n          <ion-col size=\"6\">\n            <ion-badge color=\"secondary\" *ngIf=\"item.prioridade == 'ROTINA'\">{{item.prioridade}}</ion-badge>\n            <ion-badge color=\"primary\" *ngIf=\"item.prioridade == 'URGENTE'\">{{item.prioridade}}</ion-badge>\n          </ion-col>\n\n          <ion-col size=\"6\" class=\"text-right\" *ngIf=\"!item.portador_accepted && item.prioridade == 'URGENTE'\">\n            <ion-badge color=\"medium\">Pendente de confirmação</ion-badge>\n          </ion-col>\n\n        </ion-row>\n      </ion-label>\n    </ion-item>\n\n  </ion-list>\n\n</ion-content>\n");

/***/ }),

/***/ 66065:
/*!*******************************************************!*\
  !*** ./src/app/pages/devolucoes/devolucoes.page.scss ***!
  \*******************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZXZvbHVjb2VzLnBhZ2Uuc2NzcyJ9 */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_devolucoes_devolucoes_module_ts.js.map