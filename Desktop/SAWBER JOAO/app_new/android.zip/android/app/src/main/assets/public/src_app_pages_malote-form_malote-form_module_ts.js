"use strict";
(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["src_app_pages_malote-form_malote-form_module_ts"],{

/***/ 51131:
/*!*****************************************************************!*\
  !*** ./src/app/pages/malote-form/malote-form-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MaloteFormPageRoutingModule": () => (/* binding */ MaloteFormPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _malote_form_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./malote-form.page */ 60175);




const routes = [
    {
        path: '',
        component: _malote_form_page__WEBPACK_IMPORTED_MODULE_0__.MaloteFormPage
    }
];
let MaloteFormPageRoutingModule = class MaloteFormPageRoutingModule {
};
MaloteFormPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MaloteFormPageRoutingModule);



/***/ }),

/***/ 24862:
/*!*********************************************************!*\
  !*** ./src/app/pages/malote-form/malote-form.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MaloteFormPageModule": () => (/* binding */ MaloteFormPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _malote_form_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./malote-form-routing.module */ 51131);
/* harmony import */ var _malote_form_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./malote-form.page */ 60175);
/* harmony import */ var _malote_setor_malote_setor_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./malote-setor/malote-setor.component */ 33055);
/* harmony import */ var _malote_item_malote_item_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./malote-item/malote-item.component */ 89579);









let MaloteFormPageModule = class MaloteFormPageModule {
};
MaloteFormPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _malote_form_routing_module__WEBPACK_IMPORTED_MODULE_0__.MaloteFormPageRoutingModule
        ],
        declarations: [
            _malote_form_page__WEBPACK_IMPORTED_MODULE_1__.MaloteFormPage,
            _malote_setor_malote_setor_component__WEBPACK_IMPORTED_MODULE_2__.MaloteSetorComponent,
            _malote_item_malote_item_component__WEBPACK_IMPORTED_MODULE_3__.MaloteItemComponent
        ]
    })
], MaloteFormPageModule);



/***/ }),

/***/ 60175:
/*!*******************************************************!*\
  !*** ./src/app/pages/malote-form/malote-form.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MaloteFormPage": () => (/* binding */ MaloteFormPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_malote_form_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./malote-form.page.html */ 71232);
/* harmony import */ var _malote_form_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./malote-form.page.scss */ 17851);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 54357);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 37556);
/* harmony import */ var src_app_services_malote_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/malote.service */ 3429);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/message.service */ 42684);
/* harmony import */ var _malote_setor_malote_setor_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./malote-setor/malote-setor.component */ 33055);











let MaloteFormPage = class MaloteFormPage {
    constructor(navCtrl, routerActive, alertCtrl, modalCtrl, storage, 
    // private medicoService: MedicoService,
    authService, service, message) {
        this.navCtrl = navCtrl;
        this.routerActive = routerActive;
        this.alertCtrl = alertCtrl;
        this.modalCtrl = modalCtrl;
        this.storage = storage;
        this.authService = authService;
        this.service = service;
        this.message = message;
        this.clinica = {};
        this.dados = { setores: [] };
        this.setores = [
            { key: 1, titulo: 'Faturamento' },
            { key: 2, titulo: 'Financeiro' },
            { key: 3, titulo: 'Patologia' },
            { key: 4, titulo: 'Laudos' },
        ];
        this.user = {};
        this.storage.create();
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const session = yield this.authService.getSession();
            this.user = session.user;
            this.dados.portador_id = this.user.uuid;
            this.routerActive.params.subscribe(params => {
                console.log(params);
                if (params.clinica_id && params.code_qr) {
                    this.dados.code_qr = params.code_qr;
                    this.dados.clinica_id = params.clinica_id;
                    this.getDados(params.clinica_id);
                }
            }).unsubscribe();
        });
    }
    getDados(id) {
        this.message.load_present();
        this.service.getClinica(id).then(res => {
            this.clinica = res;
            this.dados.clinica = res.description;
            // this.getColeta(id);
        }).finally(() => this.message.load_dismiss());
    }
    usedItem(select) {
        let show = true;
        for (let item of this.dados.setores) {
            // console.log('item', item);
            if (item.key == select.key) {
                show = false;
            }
        }
        return show;
    }
    open(setor, i = undefined) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _malote_setor_malote_setor_component__WEBPACK_IMPORTED_MODULE_6__.MaloteSetorComponent,
                componentProps: {
                    'data': setor,
                }
            });
            yield modal.present();
            modal.onDidDismiss().then(res => {
                console.log(res);
                if (res.data) {
                    if (i >= 0) {
                        console.log('index open', i);
                        this.dados.setores[i] = res.data;
                    }
                    else {
                        this.dados.setores.push(res.data);
                    }
                    console.log('dados setores', this.dados.setores);
                }
            });
        });
    }
    save() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                header: 'Atenção!',
                mode: 'ios',
                message: `Finalizar malote ?`,
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary'
                    }, {
                        text: 'Confirmar',
                        handler: () => {
                            if (this.checkEmpty() == false) {
                                return this.message.toastError('Sem itens coletados..');
                            }
                            this.send();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    checkEmpty() {
        if (this.dados.setores.length == 0) {
            return false;
        }
        let retorno = true;
        for (let setor of this.dados.setores) {
            console.log(setor);
            if (setor.itens.length == 0) {
                retorno = false;
            }
        }
        return retorno;
    }
    send() {
        this.message.load_present();
        this.service.createColeta(this.dados).then(() => {
            this.navCtrl.navigateRoot('/home');
        }).catch(err => {
            this.storageMalote();
        }).finally(() => this.message.load_dismiss());
    }
    storageMalote() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                header: 'Aviso!',
                mode: 'ios',
                message: 'Seu malote foi armazenada no dispositivo por falta de internet... \n Será enviado quando a mesma for restaurada.',
                buttons: ['OK']
            });
            yield alert.present();
            this.storage.get('malotes').then(res => {
                if (res && res != null) { //temos coletas
                    let malotes = res;
                    malotes.push(this.dados);
                    this.setMalotes(malotes);
                }
                else { //sem malotes
                    let malotes = [];
                    malotes.push(this.dados);
                    this.setMalotes(malotes);
                }
            }).catch(err => {
                this.message.toastError('Falha ao verificar coletas no dispositivo.');
                console.log(err);
            });
        });
    }
    setMalotes(coletas) {
        this.storage.set('coletas', coletas).then(() => {
            this.navCtrl.navigateRoot('/home');
        }).catch(err => {
            this.message.toastError('Falha ao salvar coleta no dispositivo.');
            console.log(err);
        });
    }
    confirmRemove(item, i) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                header: 'Atenção!',
                mode: 'ios',
                message: `Deseja remover o molete do: <b>${item.titulo}</b> ?`,
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary'
                    }, {
                        text: 'Confirmar',
                        handler: () => {
                            this.dados.setores.splice(i, 1);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
MaloteFormPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: src_app_services_malote_service__WEBPACK_IMPORTED_MODULE_4__.MaloteService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_5__.MessageService }
];
MaloteFormPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-malote-form',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_malote_form_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_malote_form_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], MaloteFormPage);



/***/ }),

/***/ 89579:
/*!************************************************************************!*\
  !*** ./src/app/pages/malote-form/malote-item/malote-item.component.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MaloteItemComponent": () => (/* binding */ MaloteItemComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_malote_item_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./malote-item.component.html */ 69618);
/* harmony import */ var _malote_item_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./malote-item.component.scss */ 10989);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_app_services_camera_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/camera.service */ 53942);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/message.service */ 42684);







let MaloteItemComponent = class MaloteItemComponent {
    // types = [];
    constructor(alertCtrl, modalCtrl, 
    // private service: ColetaService,
    message, cameraService) {
        this.alertCtrl = alertCtrl;
        this.modalCtrl = modalCtrl;
        this.message = message;
        this.cameraService = cameraService;
        this.dados = {};
    }
    ngOnInit() {
        // this.getTipos();
    }
    close(params = undefined) {
        this.modalCtrl.dismiss(params);
    }
    // getTipos() {
    //   this.message.load_present();
    //   this.service.getExameTypes().then(res => {
    //     this.types = res;
    //   }).finally(() => this.message.load_dismiss());
    // }
    // changeTipo(event) {
    //   // console.log(uuid);
    //   const uuid = event.value;
    //   this.dados.tipo_id = uuid;
    //   this.dados.tipo = this.types.find(tipo => tipo.uuid == uuid);
    // }
    confirmItem() {
        if (!this.dados.foto) {
            return this.message.toastError('Tire uma foto do exame coletado.');
        }
        this.close(this.dados);
    }
    takePhoto() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            // Take a photo
            // const capturedPhoto = await Camera.getPhoto({
            //   resultType: CameraResultType.Base64,
            //   allowEditing: false,
            //   source: CameraSource.Camera,
            //   direction: CameraDirection.Rear,
            //   quality: 70
            // });
            // const options: CameraOptions = {
            //   quality: 50,
            //   destinationType: this.camera.DestinationType.DATA_URL,
            //   encodingType: this.camera.EncodingType.JPEG,
            //   mediaType: this.camera.MediaType.PICTURE
            // }
            // // if (this.backgroundMode.isActive()) {
            // let capturedPhoto = await this.camera.getPicture(options)
            //   .finally(() => {
            //     // this.backgroundMode.disable()
            //   });
            let image = yield this.cameraService.takePhoto();
            if (image.base64String) {
                this.dados.foto = `data:image/jpeg;base64,${image.base64String}`;
            }
            // console.log(capturedPhoto);
            // this.dados.foto = `data:image/jpeg;base64,${capturedPhoto}`;
        });
    }
};
MaloteItemComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_3__.MessageService },
    { type: src_app_services_camera_service__WEBPACK_IMPORTED_MODULE_2__.CameraService }
];
MaloteItemComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-malote-item',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_malote_item_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_malote_item_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], MaloteItemComponent);



/***/ }),

/***/ 33055:
/*!**************************************************************************!*\
  !*** ./src/app/pages/malote-form/malote-setor/malote-setor.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MaloteSetorComponent": () => (/* binding */ MaloteSetorComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_malote_setor_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./malote-setor.component.html */ 53455);
/* harmony import */ var _malote_setor_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./malote-setor.component.scss */ 12230);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _malote_item_malote_item_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../malote-item/malote-item.component */ 89579);






let MaloteSetorComponent = class MaloteSetorComponent {
    constructor(alertCtrl, modalCtrl) {
        this.alertCtrl = alertCtrl;
        this.modalCtrl = modalCtrl;
        this.dados = { itens: [] };
    }
    ngOnInit() {
        console.log(this.data);
        if (this.data) {
            this.dados = this.data;
            this.dados.itens = this.data.itens ? this.data.itens : [];
        }
    }
    close(params = undefined) {
        if (this.dados.itens.length > 0) {
            return this.alertVoltar();
        }
        this.modalCtrl.dismiss(params);
    }
    save(params) {
        this.modalCtrl.dismiss(params);
    }
    alertVoltar() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            // const alert = await this.alertCtrl.create({
            //   cssClass: 'my-custom-class',
            //   header: 'Atenção!',
            //   mode: 'ios',
            //   message: 'Se você sair pode perder toda a coleta do médico.',
            //   buttons: [
            //     {
            //       text: 'Voltar',
            //       cssClass: 'secondary'
            //     }, {
            //       text: 'Confirmar',
            //       handler: () => {
            this.modalCtrl.dismiss(undefined);
            //       }
            //     }
            //   ]
            // });
            // await alert.present();
        });
    }
    addItem() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _malote_item_malote_item_component__WEBPACK_IMPORTED_MODULE_2__.MaloteItemComponent
            });
            yield modal.present();
            modal.onDidDismiss().then(res => {
                console.log(res);
                if (res.data) {
                    this.dados.itens.push(res.data);
                }
            });
        });
    }
    confirmRemove(item, i) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                header: 'Atenção!',
                mode: 'ios',
                message: `Deseja remover o item ?`,
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary'
                    }, {
                        text: 'Confirmar',
                        handler: () => {
                            this.dados.itens.splice(i, 1);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
MaloteSetorComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController }
];
MaloteSetorComponent.propDecorators = {
    data: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input }]
};
MaloteSetorComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-malote-setor',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_malote_setor_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_malote_setor_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], MaloteSetorComponent);



/***/ }),

/***/ 71232:
/*!************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/malote-form/malote-form.page.html ***!
  \************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n\n    <ion-title>Malote Nº: {{dados.code_qr}}</ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-card mode=\"ios\">\n    <ion-item lines=\"none\">\n      <ion-label class=\"ion-text-wrap\">\n        <strong>{{ clinica.description | titlecase }}</strong>\n        <p>{{clinica.logradouro}}, Nº {{clinica.numero}}, {{clinica.complemento}}, {{clinica.bairro}},\n          {{clinica.cidade}}</p>\n      </ion-label>\n    </ion-item>\n  </ion-card>\n\n  <ion-list>\n    <ion-list-header color=\"primary\">\n      <ion-label>Setores</ion-label>\n      <!-- <ion-button color=\"dark\">Clear</ion-button> -->\n      <!-- <ion-button (click)=\"openMedicoSearch()\">\n        <ion-icon name=\"add-circle-outline\" color=\"light\" slot=\"icon-only\"></ion-icon>\n      </ion-button> -->\n    </ion-list-header>\n\n    <div *ngFor=\"let item of setores\">\n      <ion-item lines=\"full\" (click)=\"open(item)\" *ngIf=\"usedItem(item)\">\n        <ion-label>\n          <h2>{{ item.titulo | titlecase }}</h2>\n          <!-- <p>CRM: {{medico.crm}}</p> -->\n        </ion-label>\n      </ion-item>\n    </div>\n  </ion-list>\n\n  <ion-list *ngIf=\"dados.setores.length > 0\">\n    <ion-list-header color=\"primary\">\n      <ion-label>Malotes</ion-label>\n    </ion-list-header>\n\n    <ion-item lines=\"full\" *ngFor=\"let malote of dados.setores; let i = index\">\n      <ion-label (click)=\"open(malote, i)\">\n        <h2>{{ malote.titulo | titlecase }}</h2>\n        <!-- <p>CRM: {{malote.crm}}</p> -->\n        <p>Itens no malotes: {{malote.itens.length}}</p>\n      </ion-label>\n      <ion-button slot=\"end\" fill=\"clear\" (click)=\"confirmRemove(malote, i)\">\n        <ion-icon name=\"trash\" color=\"danger\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-item>\n  </ion-list>\n\n  <div class=\"ion-padding\">\n    <ion-button expand=\"block\" color=\"tertiary\" (click)=\"save()\">\n      Finalizar Malote\n    </ion-button>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ 69618:
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/malote-form/malote-item/malote-item.component.html ***!
  \*****************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"close()\">\n        <ion-icon name=\"arrow-back-outline\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-title>Adicionar item</ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n\n  <div class=\"ion-margin-top\" align=\"center\">\n    <img [src]=\"dados.foto ? dados.foto : 'assets/media/no-image.png'\" class=\"img-card\" (click)=\"takePhoto()\">\n  </div>\n\n\n  <div class=\"ion-margin-top\">\n    <ion-button expand=\"block\" color=\"tertiary\" (click)=\"confirmItem()\">\n      Adicionar\n    </ion-button>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ 53455:
/*!*******************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/malote-form/malote-setor/malote-setor.component.html ***!
  \*******************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"close()\">\n        <ion-icon name=\"arrow-back-outline\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-title>Itens do Setor</ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-card mode=\"ios\">\n    <ion-item lines=\"none\">\n      <ion-label class=\"ion-text-wrap\">\n        <h2>Setor:</h2>\n        <p>{{ dados.titulo | titlecase }}</p>\n      </ion-label>\n    </ion-item>\n  </ion-card>\n\n  <ion-list>\n    <ion-list-header color=\"primary\">\n      <ion-label>Itens</ion-label>\n    </ion-list-header>\n\n    <ion-item lines=\"full\" *ngFor=\"let item of dados.itens; let i = index\">\n      <ion-thumbnail slot=\"start\">\n        <img [src]=\"item.foto\" alt=\"\">\n      </ion-thumbnail>\n      <ion-label>\n        <!-- <h2>{{ medico.nome | titlecase }}</h2> -->\n        <!-- <p>{{item.tipo.nome}}</p> -->\n      </ion-label>\n      <ion-button slot=\"end\" fill=\"clear\" (click)=\"confirmRemove(item, i)\">\n        <ion-icon name=\"trash\" color=\"danger\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-item>\n  </ion-list>\n\n  <div class=\"ion-padding\" *ngIf=\"dados.itens.length > 0\">\n    <ion-button expand=\"block\" color=\"tertiary\" (click)=\"save(dados)\">\n      Confirmar\n    </ion-button>\n  </div>\n\n\n  <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\" (click)=\"addItem()\">\n    <ion-fab-button color=\"primary\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n</ion-content>\n");

/***/ }),

/***/ 17851:
/*!*********************************************************!*\
  !*** ./src/app/pages/malote-form/malote-form.page.scss ***!
  \*********************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtYWxvdGUtZm9ybS5wYWdlLnNjc3MifQ== */";

/***/ }),

/***/ 10989:
/*!**************************************************************************!*\
  !*** ./src/app/pages/malote-form/malote-item/malote-item.component.scss ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtYWxvdGUtaXRlbS5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 12230:
/*!****************************************************************************!*\
  !*** ./src/app/pages/malote-form/malote-setor/malote-setor.component.scss ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtYWxvdGUtc2V0b3IuY29tcG9uZW50LnNjc3MifQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_malote-form_malote-form_module_ts.js.map