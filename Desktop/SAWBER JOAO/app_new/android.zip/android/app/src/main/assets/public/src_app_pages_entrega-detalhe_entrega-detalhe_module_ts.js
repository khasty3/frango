"use strict";
(self["webpackChunkapp_new"] = self["webpackChunkapp_new"] || []).push([["src_app_pages_entrega-detalhe_entrega-detalhe_module_ts"],{

/***/ 92524:
/*!*************************************************************************!*\
  !*** ./src/app/pages/entrega-detalhe/entrega-detalhe-routing.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EntregaDetalhePageRoutingModule": () => (/* binding */ EntregaDetalhePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _entrega_detalhe_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./entrega-detalhe.page */ 21616);




const routes = [
    {
        path: '',
        component: _entrega_detalhe_page__WEBPACK_IMPORTED_MODULE_0__.EntregaDetalhePage
    }
];
let EntregaDetalhePageRoutingModule = class EntregaDetalhePageRoutingModule {
};
EntregaDetalhePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], EntregaDetalhePageRoutingModule);



/***/ }),

/***/ 54593:
/*!*****************************************************************!*\
  !*** ./src/app/pages/entrega-detalhe/entrega-detalhe.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EntregaDetalhePageModule": () => (/* binding */ EntregaDetalhePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 54364);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var _entrega_detalhe_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./entrega-detalhe-routing.module */ 92524);
/* harmony import */ var _entrega_detalhe_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./entrega-detalhe.page */ 21616);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/shared.module */ 40950);








let EntregaDetalhePageModule = class EntregaDetalhePageModule {
};
EntregaDetalhePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _entrega_detalhe_routing_module__WEBPACK_IMPORTED_MODULE_0__.EntregaDetalhePageRoutingModule,
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule
        ],
        declarations: [_entrega_detalhe_page__WEBPACK_IMPORTED_MODULE_1__.EntregaDetalhePage]
    })
], EntregaDetalhePageModule);



/***/ }),

/***/ 21616:
/*!***************************************************************!*\
  !*** ./src/app/pages/entrega-detalhe/entrega-detalhe.page.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EntregaDetalhePage": () => (/* binding */ EntregaDetalhePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_entrega_detalhe_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./entrega-detalhe.page.html */ 53949);
/* harmony import */ var _entrega_detalhe_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./entrega-detalhe.page.scss */ 62718);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 71258);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 81864);
/* harmony import */ var src_app_services_camera_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/camera.service */ 53942);
/* harmony import */ var src_app_services_entrega_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/entrega.service */ 96932);
/* harmony import */ var src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/message.service */ 42684);
/* harmony import */ var _shared_modal_signature_modal_signature_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared/modal-signature/modal-signature.component */ 2891);










let EntregaDetalhePage = class EntregaDetalhePage {
    constructor(modalCtrl, navCtrl, alertCtrl, routerActive, service, message, cameraService) {
        this.modalCtrl = modalCtrl;
        this.navCtrl = navCtrl;
        this.alertCtrl = alertCtrl;
        this.routerActive = routerActive;
        this.service = service;
        this.message = message;
        this.cameraService = cameraService;
        this.dados = { exame: {}, pendencias: [] };
        this.reportData = {};
    }
    ngOnInit() {
        this.routerActive.params.subscribe(params => {
            console.log(params);
            if (params.entrega_id) {
                this.dados.entrega_id = params.entrega_id;
                this.getDados(params.entrega_id);
            }
        }).unsubscribe();
    }
    doRefresh(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            yield this.getDados(this.dados.uuid);
            event.target.complete();
        });
    }
    getDados(id) {
        this.message.load_present();
        this.service.getById(id).then((res) => {
            this.dados = res;
        }).finally(() => this.message.load_dismiss());
    }
    getAddress() {
        let label = '';
        if (this.dados.exame) {
            const exame = this.dados.exame;
            // label = `${exame.exame_endereco}, ${exame.exame_complemento}, ${exame.exame_bairro} - ${exame.exame_cidade}/${exame.exame_estado}`;
            label = `${exame.logradouro}, ${exame.complemento}, ${exame.bairro} - ${exame.cidade}/${exame.uf}`;
        }
        return label;
    }
    getPhoto() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            let image = yield this.cameraService.takePhoto();
            if (image.base64String) {
                this.dados.foto = `data:image/jpeg;base64,${image.base64String}`;
                // this.confirm();
            }
        });
    }
    getSignature() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _shared_modal_signature_modal_signature_component__WEBPACK_IMPORTED_MODULE_5__.ModalSignatureComponent
            });
            yield modal.present();
            modal.onDidDismiss().then(res => {
                console.log(res);
                if (res.data) {
                    this.dados.signature = res.data;
                    // this.medico.itens.push(res.data);
                }
            });
        });
    }
    getInfo() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-class',
                // header: 'Prompt!',
                message: 'Informe os dados da entrega.',
                backdropDismiss: false,
                mode: 'ios',
                inputs: [
                    {
                        name: 'recptor',
                        type: 'text',
                        placeholder: 'Nome de quem recebeu.'
                    },
                    {
                        name: 'doc',
                        type: 'text',
                        placeholder: 'Documento de quem recebeu.'
                    }
                ],
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary'
                    }, {
                        text: 'Confirmar',
                        handler: (data) => {
                            if (data.recptor == "") {
                                return this.message.toastError('Informe o Nome...');
                            }
                            this.dados.recptor = data.recptor;
                            if (data.doc == "") {
                                return this.message.toastError('Informe o Documento...');
                            }
                            this.dados.doc = data.doc;
                            // this.getPhoto();
                            this.getSignature();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    confirm() {
        if (!this.dados.recptor || !this.dados.doc) {
            return this.getInfo();
        }
        // if (!this.dados.foto) {
        //   this.getPhoto();
        //   return;
        // }
        if (!this.dados.signature) {
            this.getSignature();
            return;
        }
        this.message.load_present();
        this.service.update(this.dados.uuid, this.dados).then(() => {
            // this.getDados(this.dados.uuid);
            this.navCtrl.pop();
        }).finally(() => this.message.load_dismiss());
    }
    openReport() {
        var _a;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'my-custom-alert-full',
                // header: 'Prompt!',
                message: 'Informe o motivo da ocorrência.',
                backdropDismiss: false,
                mode: 'ios',
                inputs: [
                    {
                        name: 'description',
                        type: 'textarea',
                        placeholder: 'Descreva o motivo.',
                        value: `${(_a = this.reportData.description) !== null && _a !== void 0 ? _a : ''}`,
                        attributes: {
                            rows: 6
                        }
                    }
                ],
                buttons: [
                    {
                        text: 'Voltar',
                        cssClass: 'secondary'
                    },
                    {
                        text: 'Sem Foto',
                        handler: (data) => {
                            if (data.description == "") {
                                return this.message.toastError('Informe a descrição...');
                            }
                            this.reportData.entrega_id = this.dados.uuid;
                            this.reportData.portador_id = this.dados.portador_id;
                            this.reportData.description = data.description;
                            this.reporte();
                        }
                    },
                    {
                        text: 'Com Foto',
                        handler: (data) => (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
                            if (data.description == "") {
                                return this.message.toastError('Informe a descrição...');
                            }
                            this.reportData.entrega_id = this.dados.uuid;
                            this.reportData.portador_id = this.dados.portador_id;
                            this.reportData.description = data.description;
                            let image = yield this.cameraService.takePhoto();
                            if (image.base64String) {
                                this.reportData.foto = `data:image/jpeg;base64,${image.base64String}`;
                                this.reporte();
                            }
                        })
                    }
                ]
            });
            yield alert.present();
        });
    }
    reporte() {
        this.message.load_present();
        this.service.createReport(this.reportData).then(() => {
            // this.getDados(this.dados.uuid);
            this.navCtrl.pop();
        }).finally(() => this.message.load_dismiss());
    }
};
EntregaDetalhePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute },
    { type: src_app_services_entrega_service__WEBPACK_IMPORTED_MODULE_3__.EntregaService },
    { type: src_app_services_message_service__WEBPACK_IMPORTED_MODULE_4__.MessageService },
    { type: src_app_services_camera_service__WEBPACK_IMPORTED_MODULE_2__.CameraService }
];
EntregaDetalhePage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-entrega-detalhe',
        template: _C_Users_Administrator_Desktop_SAWBER_JO_O_app_new_node_modules_ngtools_webpack_src_loaders_direct_resource_js_entrega_detalhe_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_entrega_detalhe_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], EntregaDetalhePage);



/***/ }),

/***/ 53949:
/*!********************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/entrega-detalhe/entrega-detalhe.page.html ***!
  \********************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n\n    <ion-title>Detalhes da Entrega</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <ion-card mode=\"ios\">\n\n    <ion-card-header>\n      <ion-card-subtitle>Exame:</ion-card-subtitle>\n      <ion-card-title>{{dados.exame_id}}</ion-card-title>\n    </ion-card-header>\n\n    <ion-card-content>\n      <ion-row>\n\n        <ion-col size=\"12\">\n          Nome:<strong> {{dados.exame.nome}}</strong>\n        </ion-col>\n\n        <ion-col size=\"12\">\n          Endereço:<strong> {{getAddress()}}</strong>\n        </ion-col>\n\n        <ion-col size=\"12\">\n          Observações:<strong> {{dados.exame.obs}}</strong>\n        </ion-col>\n\n        <ion-col size=\"12\">\n          Contato:\n          <br>\n          <strong *ngIf=\"dados.exame.telefone\"><a href=\"tel:{{dados.exame.telefone}}\"> {{dados.exame.telefone}}</a></strong>\n          <br>\n          <strong *ngIf=\"dados.exame.telefone_secondary\"><a href=\"tel:{{dados.exame.telefone_secondary}}\">\n              {{dados.exame.telefone_secondary}}</a></strong>\n        </ion-col>\n\n        <ion-col size=\"12\" *ngIf=\"dados.exame.tipo_pagamento == 2\">\n          À Receber:<strong class=\"text-danger\"> {{ dados.exame.valor | currency: 'R$' }}</strong>\n        </ion-col>\n\n        <ion-col size=\"12\" *ngIf=\"dados.status == 10\">\n          Data da Entrega:<strong> {{ dados.updated_at | date: 'dd/MM/yyy HH:mm' }}</strong>\n        </ion-col>\n\n\n      </ion-row>\n    </ion-card-content>\n  </ion-card>\n\n  <!-- <ion-list mode=\"md\">\n    <ion-list-header color=\"primary\">\n      <ion-label>Pendências da entrega</ion-label>\n    </ion-list-header>\n\n    <ion-item *ngFor=\"let pend of dados.pendencias\">\n      <ion-label>\n        <h2>Motivo: <strong> {{pend.description}}</strong></h2>\n\n        <p>Data da Ocorrência: {{ pend.data_tentativa | date: 'dd/MM/yyyy HH:mm' }}</p>\n      </ion-label>\n    </ion-item>\n  </ion-list> -->\n\n\n  <div class=\"ion-margin-top\" align=\"center\">\n    <img [src]=\"dados.foto\" class=\"img-card\" *ngIf=\"dados.foto\" (click)=\"getPhoto()\">\n    <img [src]=\"dados.signature\" class=\"img-card\" *ngIf=\"dados.signature\" (click)=\"getSignature()\">\n  </div>\n  <div class=\"ion-margin-top\" align=\"center\" *ngIf=\"dados.recptor\">\n    <strong>Recebedor: {{dados.recptor}}</strong>\n  </div>\n\n  <div class=\"ion-padding\" align=\"center\">\n\n    <ion-badge color=\"medium\" *ngIf=\"dados.status == 1\">Pendente</ion-badge>\n    <!-- <ion-badge color=\"warning\" *ngIf=\"dados.status == 5\">Ocorrência</ion-badge> -->\n    <ion-badge color=\"success\" *ngIf=\"dados.status == 10\">Entregue</ion-badge>\n\n    <ion-button class=\"ion-margin-top\" expand=\"block\" color=\"tertiary\" (click)=\"confirm()\" *ngIf=\"dados.status != 10\">\n      Entregar\n    </ion-button>\n\n    <ion-button class=\"ion-margin-top\" expand=\"block\" color=\"warning\" (click)=\"openReport()\" *ngIf=\"dados.status != 10\">\n      Gerar Ocorrência\n    </ion-button>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ 62718:
/*!*****************************************************************!*\
  !*** ./src/app/pages/entrega-detalhe/entrega-detalhe.page.scss ***!
  \*****************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlbnRyZWdhLWRldGFsaGUucGFnZS5zY3NzIn0= */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_entrega-detalhe_entrega-detalhe_module_ts.js.map